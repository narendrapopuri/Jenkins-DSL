if ($env:SYSTEM_STAGEDISPLAYNAME -like "*Development*") {
write-output "Deployment is to Development, therefore deployment does not have to be from master branch."
} elseif ($env:BUILD_SOURCEBRANCHNAME -ne "master") {
write-output "##vso[task.LogIssue type=error;]Deployment to $env:SYSTEM_STAGEDISPLAYNAME must only be from the master branch."
exit 1
} else {
write-output "Deployment is from master."
}
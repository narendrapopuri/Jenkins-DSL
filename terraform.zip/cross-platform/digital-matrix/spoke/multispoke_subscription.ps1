Param(
[Parameter(Mandatory)]$subscription_id,
[Parameter(Mandatory)]$subscription_name,
[Parameter(Mandatory)]$wp_baseline_vnet_address_space,
[Parameter(Mandatory)]$dm_spoke_fw_vnet_address_space,
[Parameter(Mandatory)]$subnet_address_space_dmpe,
[Parameter(Mandatory)]$subnet_address_space_fw,
[Parameter(Mandatory)]$tfLog,
[Parameter(Mandatory)]$deploymentEnv)
$subName = $subscription_name
$counter = $subName.LastIndexOf("-")
if($deploymentEnv -ne "CAT" -and $deploymentEnv -ne "Dev") {
  if($counter -gt 15) {
      $counter = $counter+1
      $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
      Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
} elseif($deploymentEnv -eq "CAT") {
    if($counter -gt 15 -and $subname -ne "qa-spoke-digitalmatrix-cat-1") {
        $counter = $counter+1
        $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
        Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
        $Project = "iac-acc-dm-spoke-cat$(SubscriptionCount)"
        Write-Host "##vso[task.setvariable variable=Project]$Project"
        $TerraformPlanFileName = "plan_$(Stage_cat)_$(SubscriptionCount)_$(Build.DefinitionName)_$(Build.BuildNumber).tfplan"
        Write-Host "##vso[task.setvariable variable=TerraformPlanFileName]$TerraformPlanFileName"
    }
}  elseif($deploymentEnv -eq "Dev") {
    if($counter -gt 15 -and $subname -ne "dev-spoke-digitalmatrix-local-1") {
        $counter = $counter+1
        $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
        Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
    if($subName -eq "dev-spoke-digitalmatrix-local-1") {
     $Project = "iac-acc-dm-spoke-local-1"
     Write-Host "##vso[task.setvariable variable=Project]$Project"
     $TerraformPlanFileName = 'plan_local_$(Stage)_$(Build.DefinitionName)_$(Build.BuildNumber).tfplan'
     Write-Host "##vso[task.setvariable variable=TerraformPlanFileName]$TerraformPlanFileName"
     $TerraformPlanArgumentsDev = 'terraform plan -input=false -var-file="variables_local_dev.tfvars" -var-file="parameters.tfvars" -var="client_secret=$(digitalmatrix-client-secret-dev)" -out $(TerraformPlanPath) -no-color'
     Write-Host "##vso[task.setvariable variable=TerraformPlanArgumentsDev]$TerraformPlanArgumentsDev"
}
}

Write-Host "##vso[task.setvariable variable=SubscriptionId]$subscription_id"
Write-Host "##vso[task.setvariable variable=SpokeVnetAddressSpace]$wp_baseline_vnet_address_space"
Write-Host "##vso[task.setvariable variable=SpokeFirewallVnetAddressSpace]$dm_spoke_fw_vnet_address_space"
Write-Host "##vso[task.setvariable variable=SpokeSubnetAddressSpace]$subnet_address_space_dmpe"
Write-Host "##vso[task.setvariable variable=SpokeFirewallSubnetAddressSpace]$subnet_address_space_fw"
Write-Host "##vso[task.setvariable variable=TF_LOG;]$tfLog"

Param(
[Parameter(Mandatory)]$subscriptions,
[Parameter(Mandatory)]$JobName,
[Parameter(Mandatory)]$deploymentEnv)
$json = "$subscriptions" | ConvertFrom-Json
$json.PSObject.Properties | ForEach-Object {
$next = $_
$name = $_.name
$value = $_.value
if ($name -eq "$JobName" -and $name -like "*$deploymentEnv*") {
    $sub_id = $value.subscription_id
    $sub_name = "$JobName"
    $wp_baseline_vnet_address = $value.wp_baseline_vnet_address_space
    $dm_spoke_fw_vnet_address = $value.dm_spoke_fw_vnet_address_space                
    $subnet_address_dmpe = $value.subnet_address_space_dmpe
    $subnet_address_fw = $value.subnet_address_space_fw
    $sub_name+"-"+$sub_id+"-"+$wp_baseline_vnet_address+"-"+$dm_spoke_fw_vnet_address+"-"+$subnet_address_dmpe+"-"+$subnet_address_fw
    Write-Host "##vso[task.setvariable variable=subscription_id_vso]$sub_id"
    Write-Host "##vso[task.setvariable variable=subscription_name_vso]$sub_name"
    Write-Host "##vso[task.setvariable variable=wp_baseline_vnet_address_space_vso]$wp_baseline_vnet_address"
    Write-Host "##vso[task.setvariable variable=dm_spoke_fw_vnet_address_space_vso]$dm_spoke_fw_vnet_address"
    Write-Host "##vso[task.setvariable variable=subnet_address_space_dmpe_vso]$subnet_address_dmpe"
    Write-Host "##vso[task.setvariable variable=subnet_address_space_fw_vso]$subnet_address_fw"
}
}
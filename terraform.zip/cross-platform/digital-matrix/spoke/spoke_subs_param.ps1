Param(
[Parameter(Mandatory)]$envname,
[Parameter(Mandatory)]$Builddefinitionname,
[Parameter(Mandatory)]$Buildnum)
$json = Get-Content ./cross-platform/digital-matrix/spoke/multispoke_sub_param.json | ConvertFrom-Json
foreach ($jsonobj in $json.PSObject.Properties) {
if ($jsonobj.Name -eq $envname) {
$temp = $jsonobj.Value
$param = "{'"
foreach ($subs in $temp.PSObject.properties) {
    if($param.IndexOf("}") -gt 0) {
    $param = $param+",'"
    }
$subvaluestring = $subs.Value|ConvertTo-Json
$param = $param+$subs.Name+"': $subvaluestring"
}
}
}
$param = $param+"}"
$param = $param.Replace("""","'").Replace("`r`n","")
Write-Host "##vso[task.setvariable variable=JsonContent;isOutput=true]$param"

$subsjson = $param| ConvertFrom-Json
$allcount = ""
foreach($currentsub in $subsjson.PSObject.Properties.name) {
$SubscriptionCount = ""
$subName = $currentsub
$counter = $subName.LastIndexOf("-")
if($envname -ne "CAT" -and $envname -ne "Dev") {
  if($counter -gt 15) {
      $counter = $counter+1
      $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
      Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
} elseif($envname -eq "CAT") {
    if($counter -gt 15 -and $subname -ne "qa-spoke-digitalmatrix-cat-1") {
        $counter = $counter+1
        $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
        Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
}  elseif($envname -eq "Dev") {
    if($counter -gt 15 -and $subname -ne "dev-spoke-digitalmatrix-local-1") {

        $counter = $counter+1
        $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
        Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
}
if($subname -like "*$envname*") {
  if($subName -eq "dev-spoke-digitalmatrix-local-1") {
     $TerraformPlanFileName = "plan_local_"+$env:Stage+"_"+$Builddefinitionname+"_"+$Buildnum+".tfplan"
  } else {
     if($subname -like "*-cat-*"){
       $TerraformPlanFileName = "plan_"+$env:Stage_cat+"_"+$SubscriptionCount.ToString()+"_"+$Builddefinitionname+"_"+$Buildnum+".tfplan"
     } else {
        $TerraformPlanFileName = "plan_"+$env:Stage+"_"+$SubscriptionCount.ToString()+"_"+$Builddefinitionname+"_"+$Buildnum+".tfplan"
     }
  }

$allcount = $allcount+$TerraformPlanFileName+","
}
}
$allcount = $allcount.trim(",")
$allcount
Write-Host "##vso[task.setvariable variable=Allsubcount]$allcount"





Param(
[Parameter(Mandatory)]$Allcountsub,
[Parameter(Mandatory)]$envname)
$user = ""
$token = "bddt4qw36glfwjovfycqxu3imdnw3ffddcybajncuoirtam55uxq"

$Allcountsub

$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $user,$token)))

$restApiRunBuild = "https://dev.azure.com/CO-AzureCore/b9556493-b521-4cc6-aa21-4adb3000d9c2/_apis/build/builds?api-version=6.1-preview.6"
$Body = '{"definition":{"id":"1784"},"templateParameters": {"param_subcount":"'+$Allcountsub+'","envname":"'+$envname+'"},"sourceBranch":"'+$env:BUILD_SOURCEBRANCHNAME+'"}'
$Body   
    Invoke-RestMethod -Uri $restApiRunBuild -Method Post -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}  -Body $Body
$Allcountsub
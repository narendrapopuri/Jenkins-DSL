Param(
[Parameter(Mandatory)]$blueprintParameters,
[Parameter(Mandatory)]$Project)
$parsedValuesparameters = "$blueprintParameters" | ConvertFrom-Json
$parsedValues = $parsedValuesparameters | ConvertFrom-Json
$pcId = $parsedValues.ProductComponentId       
$statefilename="digital-matrix/PC-$pcId.$env:Stage.tfstate"
$statefilename
$trycount=1
$exception=1
for(;$trycount -lt 3;$trycount++)
{
  if($exception -eq 1) {
     try{
        $storageaccount=Get-AzStorageAccount -ResourceGroupName $env:TerraformStateResourceGroup -name $env:terraform_state_storage_account
        $storageaccount
        $blob=Get-AzStorageBlob -Container $env:TerraformStateContainerName -Context $storageaccount.Context -Blob $statefilename -ErrorAction SilentlyContinue
        $exception=0
     }
     catch{
        Write-Host "trynumber $trycount"
        $_
     }
  }
}
if($exception -eq 1) {
    throw
}
if ($blob -eq $null) {
    "state file doesn't exist no action required"
} else {
    $leasestatus=$blob.BlobProperties.LeaseStatus
    if ($leasestatus -eq "Locked") {
        $blob.ICloudBlob.BreakLease()
        "state file unlocked"
    } else {
        "state file in unlocked status no action required"
    }
}
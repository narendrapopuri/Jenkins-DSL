Param(
[Parameter(Mandatory)]$blueprintParameters,
[Parameter(Mandatory)]$tfLog,
[Parameter(Mandatory)]$deploymentEnv)
$parsedValuesparameters = "$blueprintParameters" | ConvertFrom-Json
$parsedValues = $parsedValuesparameters | ConvertFrom-Json
$subName = (Get-AzSubscription -SubscriptionId $parsedValues.SubscriptionId).Name
$counter = $subName.LastIndexOf("-")
Write-Host "$subName"
Write-Host $parsedValues.SubscriptionId

if($deploymentEnv -ne "cat-commercial" -and $deploymentEnv -ne "dev-commercial" -and $deploymentEnv -ne "local") {
  if($counter -gt 15) {
      $counter = $counter+1
      $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
      Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
} elseif($deploymentEnv -eq "cat-commercial") {
    if($counter -gt 15 -and $subname -ne "qa-spoke-digitalmatrix-cat-1") {
        $counter = $counter+1
        $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
        Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
}  elseif($deploymentEnv -eq "dev-commercial") {
    if($counter -gt 15 -and $subname -ne "dev-spoke-digitalmatrix-local-1") {
        $counter = $counter+1
        $SubscriptionCount = $subName.Substring($counter,$subName.Length - $counter)
        Write-Host "##vso[task.setvariable variable=SubscriptionCount]$SubscriptionCount"
    }
    if($subName -eq "dev-spoke-digitalmatrix-local-1") {
        $TerraformPlanArgumentsResourcesAdd = '$(tflatestVersion) plan -input=false -var-file="variables-dev-local.tfvars" -var-file="parameters.tfvars" -var="client_secret=$(client_secret)" -var="vm_admin_password=$(vm-admin-password)" -out "$(System.DefaultWorkingDirectory)/cross-platform/digital-matrix/resource-collection-templates/template-01/plan_dv_rc_$(Build.BuildNumber).tfplan" -no-color'    
        Write-Host "##vso[task.setvariable variable=TerraformPlanArgumentsResourcesAdd]$TerraformPlanArgumentsResourcesAdd"
        $TerraformPlanArgumentsResourcesRemove = '$(tflatestVersion) plan -input=false -var-file="variables-dev-local.tfvars" -var-file="parameters.tfvars" -var="client_secret=$(client_secret)" -out "$(System.DefaultWorkingDirectory)/cross-platform/digital-matrix/resource-collection-templates/template-01/plan_dv_rc_$(Build.BuildNumber).tfplan" -no-color -destroy'   
        Write-Host "##vso[task.setvariable variable=TerraformPlanArgumentsResourcesRemove]$TerraformPlanArgumentsResourcesRemove"
        $TerraformDestroyArgumentsResourcesRemove = '$(tflatestVersion) destroy -input=false -var-file="variables-dev-local.tfvars" -var-file="parameters.tfvars" -var="client_secret=$(client_secret)" -auto-approve -no-color'   
        Write-Host "##vso[task.setvariable variable=TerraformDestroyArgumentsResourcesRemove]$TerraformDestroyArgumentsResourcesRemove"     
    }
}
Write-Host "##vso[task.setvariable variable=TF_LOG;]$tfLog"
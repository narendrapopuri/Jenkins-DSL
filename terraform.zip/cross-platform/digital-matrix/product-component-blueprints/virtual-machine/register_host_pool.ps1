Stop-Service "RdAgent"
Stop-Service "Remote Desktop Agent Loader"

Connect-AzAccount -Identity
$hostPool = Get-AzWvdHostPool
$registrationToken = $hostPool.RegistrationInfoToken
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\RDInfraAgent" -Name "RegistrationToken" -Value $registrationToken


Start-Service "RdAgent"
Start-Service "Remote Desktop Agent Loader"
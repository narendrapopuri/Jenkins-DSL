## REGISTER HOST POOL ##

Stop-Service "RdAgent"
Stop-Service "Remote Desktop Agent Loader"

Connect-AzAccount -Identity
$hostPool = Get-AzWvdHostPool
$registrationToken = $hostPool.RegistrationInfoToken
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\RDInfraAgent" -Name "RegistrationToken" -Value $registrationToken


Start-Service "RdAgent"
Start-Service "Remote Desktop Agent Loader"

## INITIALIZE DATA DISKS ##

$disks = Get-Disk | Where partitionstyle -eq 'raw' | sort number

$letters = 70..89 | ForEach-Object { [char]$_ }
$count = 0
$labels = "data1","data2"

foreach ($disk in $disks)
{
    $driveLetter = $letters[$count].ToString()
    $disk | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -UseMaximumSize -DriveLetter $driveLetter |         Format-Volume -FileSystem NTFS -NewFileSystemLabel $labels[$count] -Confirm:$false -Force
    $count++
}
Param(
[Parameter(Mandatory)] $resourceCollectionParameters)

$parsedValuesparameters = "$resourceCollectionParameters" | ConvertFrom-Json
$parsedValues = $parsedValuesparameters | ConvertFrom-Json

echo "##vso[rcid --$($parsedValues.ResourceCollectionId)"   
echo "##vso[parsedvalue --$($parsedValues)"   

$datadiskCount = $parsedValues.dataDiskCount

az account set --subscription $parsedValues.SubscriptionId

if($parsedValues.DeploymentEnv -like '*dev*')
{
    $env = "dv"
}
elseif($parsedValues.DeploymentEnv -like '*qa*')
{
    $env = "qa"
}
elseif($parsedValues.DeploymentEnv -like '*cat*')
{
    $env = "cat"
}
elseif($parsedValues.DeploymentEnv -like '*uat*')
{
    $env = "uat"
}
elseif($parsedValues.DeploymentEnv -like '*pd*')
{
    $env = "pd"
}
$rg = "RGP-USE-"+$parsedValues.ResourceCollectionId+"-"+$env.ToUpper()
$vm = az vm list --query "[?contains(name, 'UEMC$($parsedValues.ResourceCollectionId)')].[name]" --output tsv


$vmArray =$vm.Split(" ")

echo $vmArray.length

echo "##vso[rg name --$($rg)" 
echo "##vso[vm --$($vm)"
echo "##vso[vmArray --$($vmArray)"

for($i = 0; $i -lt $vmArray.length; $i++)
{ 
   #Retry 

    $retrycount = 0
    $completed = $false
    $retries = 20
    $secondsDelay = 180

    while (-not $completed) {
        try {
            $vmState = az vm list --resource-group "$($rg)" --query "[?name=='$($vmArray[$i])'].{provisioningState:provisioningState}" --output tsv
            echo $vmState

            $nic = (az vm nic show -g "$($rg)" --vm-name "$($vmArray[$i])" --nic "$($vmArray[$i])-nic") | ConvertFrom-Json
            $nicState = $nic.provisioningState
            echo $nicState

            $disk = (az disk list -g "$($rg)") | ConvertFrom-Json
            $diskState = $disk.provisioningState.Get(0)
            echo $diskState

            if($vmState.ToUpper() -eq "SUCCEEDED" -and $nicState.ToUpper() -eq "SUCCEEDED" -and $diskState.ToUpper() -eq "SUCCEEDED")
            {
                echo ("Provisioning Succeeded")
                $completed = $true
            }
            else
            {
                throw
            }
        } 
        catch {
            if ($retrycount -ge $retries) {
                echo ("Provisioning failed the maximum number of {0} times." -f $retrycount)
                throw
            } else {
                echo ("Provisioning failed. Retrying in {0} seconds." -f $secondsDelay)
                Start-Sleep $secondsDelay
                $retrycount++
            }
        }
    }

    $j=0
    for(;$j -le ($datadiskCount-1);$j++)
    {
    az resource update --resource-group $rg --name $vmArray[$i] --resource-type virtualMachines --namespace Microsoft.Compute --set properties.storageProfile.dataDisks[$j].deleteOption=delete
    }
}
if ( Test-Path -Path errored.tfstate ) {
    Write-Host "errored.tfstate exist"
    terraform state push errored.tfstate
} else {
    Write-Host "errored.tfstate does not exist no action required"
}
Param(
[Parameter(Mandatory)]$resourceCollectionParameters,
[Parameter(Mandatory)]$deploymentEnv)
$parsedValuesparameters = "$resourceCollectionParameters" | ConvertFrom-Json
$parsedValues = $parsedValuesparameters | ConvertFrom-Json
$RCId = $parsedValues.ResourceCollectionId
$subName = (Get-AzSubscription -SubscriptionId $parsedValues.SubscriptionId).Name
if($subName -ne "dev-spoke-digitalmatrix-local-1"){
   $environmentData = @{
    "dev-commercial" = @{
        APIHostName                   = "digitalmatrix-dev"
        CoreKeyVaultSecretReaderGroup = "a504caaa-7bec-4249-a9c9-cf470403f641"
        EnvironmentSuffix             = "DV"
    }
    "qa-commercial" = @{
        APIHostName                   = "digitalmatrix-qa"
        CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12"
        EnvironmentSuffix             = "QA"
    }
    "cat-commercial" = @{
        APIHostName                   = "digitalmatrix-cat"
        CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12" #kvl-use-common-5ce45d57-secret-readers
        EnvironmentSuffix             = "CAT"
    }
    "uat-commercial" = @{
        APIHostName                   = "digitalmatrix-uat"
        CoreKeyVaultSecretReaderGroup = "002cdeea-4a62-4fb5-a0b3-697aef9346b8"
        EnvironmentSuffix             = "UAT"
    }
    "pd-commercial" = @{
        APIHostName                   = "digitalmatrix"
        CoreKeyVaultSecretReaderGroup = "4d557ea2-9bd2-4ffc-9662-f99c28da2bb6"
        EnvironmentSuffix             = "PD"
    }            
   }
} else {
   $environmentData = @{
    "dev-commercial" = @{
        APIHostName                   = "digitalmatrix-dev"
        CoreKeyVaultSecretReaderGroup = "a504caaa-7bec-4249-a9c9-cf470403f641"
        EnvironmentSuffix             = "LC"
    }
    "qa-commercial" = @{
        APIHostName                   = "digitalmatrix-qa"
        CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12"
        EnvironmentSuffix             = "QA"
    }
    "cat-commercial" = @{
        APIHostName                   = "digitalmatrix-cat"
        CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12" #kvl-use-common-5ce45d57-secret-readers
        EnvironmentSuffix             = "CAT"
    }
    "uat-commercial" = @{
        APIHostName                   = "digitalmatrix-uat"
        CoreKeyVaultSecretReaderGroup = "002cdeea-4a62-4fb5-a0b3-697aef9346b8"
        EnvironmentSuffix             = "UAT"
    }
    "pd-commercial" = @{
        APIHostName                   = "digitalmatrix"
        CoreKeyVaultSecretReaderGroup = "4d557ea2-9bd2-4ffc-9662-f99c28da2bb6"
        EnvironmentSuffix             = "PD"
    }            
   }
}    

$currentEnvironmentData = $environmentData[$deploymentEnv]
$currentEnvironmentData.EnvironmentSuffix
function Retrieve-WorkspaceProvisioningGroupId($requestParameters) {
    try {
            Write-Host "Retrieving workspace provisioning group id to check if group $($groupName) already exists..."
            $response = Invoke-RestMethod @requestParameters

            Write-Host $response

            Write-Host "Retrieving workspace provisioning group complete."

            $groupId = $response.id
            Write-Host "Workspace provisioning group id is $($groupId) "
        }
    catch {
        if ($_.Exception.Response.StatusCode.value__ -eq 404) {
            $groupId = $null
        } 
    } 
    return $groupId
}
$groupName = "dm-rc-$RCId-provisioning-$($currentEnvironmentData.EnvironmentSuffix)"
$wsgroupId = $null
$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
$aadToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.windows.net").AccessToken
$requestParameters = @{
    Method = 'GET'
    Uri    = "https://$($currentEnvironmentData.APIHostName).kpmgcloudops.com/ad/api/v1/group/$($groupName)"
    Headers = @{
        "Authorization" = "Bearer $($aadToken)"
    }                        
}
$wsgroupId = Retrieve-WorkspaceProvisioningGroupId $requestParameters
Write-Host "Group id is $($wsgroupId)"
if ( $wsgroupId -eq $null -or $wsgroupId -eq "" ) {
    Write-Host "AAD Group doesn't exist to delete" 
} else {      
$requestParameters = @{
    Method = 'DELETE'
    Uri    = "https://$($currentEnvironmentData.APIHostName).kpmgcloudops.com/ad/api/v1/group/$($wsgroupId)"
    Headers = @{
        "Authorization" = "Bearer $($aadToken)"
    }                        
}
Write-Host "Deleting AD group assigned to RC"
try { 
    $response = Invoke-RestMethod @requestParameters
    Write-Host $response
    Write-Host "Groupd Id $($wsgroupId) is successfully deleted"
    }
catch {
    Write-Host "Group Id deletion failed"
    Write-Host $_ 
    }
}
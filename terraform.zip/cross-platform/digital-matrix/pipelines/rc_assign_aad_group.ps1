Param(
[Parameter(Mandatory)]$resourceCollectionParameters,
[Parameter(Mandatory)]$deploymentEnv)
$parsedValuesparameters = "$resourceCollectionParameters" | ConvertFrom-Json
$parsedValues = $parsedValuesparameters | ConvertFrom-Json
$RCId = $parsedValues.ResourceCollectionId
$SubscriptionId = $parsedValues.SubscriptionId
$subName = (Get-AzSubscription -SubscriptionId $parsedValues.SubscriptionId).Name
if($subName -ne "dev-spoke-digitalmatrix-local-1"){
    $environmentData = @{
      "dev-commercial" = @{
          APIHostName                   = "digitalmatrix-dev"
          CoreKeyVaultSecretReaderGroup = "a504caaa-7bec-4249-a9c9-cf470403f641"
          EnvironmentSuffix             = "DV"
      }
      "qa-commercial" = @{
          APIHostName                   = "digitalmatrix-qa"
          CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12"
          EnvironmentSuffix             = "QA"
      }
      "cat-commercial" = @{
          APIHostName                   = "digitalmatrix-cat"
          CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12" #kvl-use-common-5ce45d57-secret-readers
          EnvironmentSuffix             = "CAT"
      }
      "uat-commercial" = @{
          APIHostName                   = "digitalmatrix-uat"
          CoreKeyVaultSecretReaderGroup = "002cdeea-4a62-4fb5-a0b3-697aef9346b8"
          EnvironmentSuffix             = "UAT"
      }
      "pd-commercial" = @{
          APIHostName                   = "digitalmatrix"
          CoreKeyVaultSecretReaderGroup = "4d557ea2-9bd2-4ffc-9662-f99c28da2bb6"
          EnvironmentSuffix             = "PD"
      }            
    }
} else {
    $environmentData = @{
      "dev-commercial" = @{
          APIHostName                   = "digitalmatrix-dev"
          CoreKeyVaultSecretReaderGroup = "a504caaa-7bec-4249-a9c9-cf470403f641"
          EnvironmentSuffix             = "LC"
      }
      "qa-commercial" = @{
          APIHostName                   = "digitalmatrix-qa"
          CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12"
          EnvironmentSuffix             = "QA"
      }
      "cat-commercial" = @{
          APIHostName                   = "digitalmatrix-cat"
          CoreKeyVaultSecretReaderGroup = "f7872f54-0eaf-4198-ab6d-c0765ea48e12" #kvl-use-common-5ce45d57-secret-readers
          EnvironmentSuffix             = "CAT"
      }
      "uat-commercial" = @{
          APIHostName                   = "digitalmatrix-uat"
          CoreKeyVaultSecretReaderGroup = "002cdeea-4a62-4fb5-a0b3-697aef9346b8"
          EnvironmentSuffix             = "UAT"
      }
      "pd-commercial" = @{
          APIHostName                   = "digitalmatrix"
          CoreKeyVaultSecretReaderGroup = "4d557ea2-9bd2-4ffc-9662-f99c28da2bb6"
          EnvironmentSuffix             = "PD"
      }            
    }
}    

$currentEnvironmentData = $environmentData[$deploymentEnv]

Write-Host "Using digital matrix endpoint" $currentEnvironmentData.APIHostName
Write-Host "Using key vault secret reader group" $currentEnvironmentData.CoreKeyVaultSecretReaderGroup

function Invoke-New-AzRoleAssignment($groupId, $scopeId, $retryCount) {
  if($retryCount -gt 0) {
     Write-Host "Attempting to assign RBAC..."
     try {
        New-AzRoleAssignment  `
          -ObjectId $groupId `
          -RoleDefinitionName "Virtual Machine Contributor" `
          -Scope $scopeId
      }
     catch {
       # There's a replication delay, so we need to retry
       # https://docs.microsoft.com/en-us/azure/role-based-access-control/role-assignments-rest#new-service-principal
       Start-Sleep -Seconds 5
       $retryCount = $retryCount - 1
       Invoke-New-AzRoleAssignment $groupId $scopeId $retryCount
     }
   } else {
     Write-Host "Failed to assign RBAC."
   }
}

function Add-AADGroupMember($requestParameters, $retryCount) {
  if($retryCount -gt 0) {
     Write-Host "Attempting to add AAD group member..."
      try {
        Write-Host "Adding managed identity to provisioning group..."
        Invoke-RestMethod @requestParameters
       }
       catch [System.Net.WebException] {
         if ($_.Exception.Response.StatusCode.value__ -eq 400) {   
            # https://docs.microsoft.com/en-us/graph/api/group-post-members?view=graph-rest-1.0&tabs=http#response
            Write-Host "Received Bad Request (400) response.  This is likely because the object is already a member of the group. See https://docs.microsoft.com/en-us/graph/api/group-post-members?view=graph-rest-1.0&tabs=http#response"
         } else {       
            Start-Sleep -Seconds 5
            $retryCount = $retryCount - 1
            Add-AADGroupMember $requestParameters $retryCount
         }
       }
       catch {
         Start-Sleep -Seconds 5
         $retryCount = $retryCount - 1
         Add-AADGroupMember $requestParameters $retryCount
       } 
    } else {
      Write-Host "Failed to add AAD group member."
      throw
    }
}

$context = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile.DefaultContext
$graphToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.microsoft.com").AccessToken
$aadToken = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate($context.Account, $context.Environment, $context.Tenant.Id.ToString(), $null, [Microsoft.Azure.Commands.Common.Authentication.ShowDialog]::Never, $null, "https://graph.windows.net").AccessToken
Write-Output "Hi I'm $($context.Account.Id)"
#Connect-AzureAD -AadAccessToken $aadToken -AccountId $context.Account.Id -TenantId $context.tenant.id -MsAccessToken $graphToken

# All of the actions that require a sub id below happen within the digitial matrix sub, which is passed in as part of the pipeline parameters          
Set-AzContext -Subscription "$SubscriptionId"

# Assign variables
$rcId = $RCId
function Get-BackgroundStatus ($taskId) {
  Write-Host "Polling background task $($taskId)..."
  # Let's give the request some time to start
  Start-Sleep -Seconds 5
  # This request returns a token.  To see current status and eventually results, we'll need to poll
  $statusParams = @{
      Method = 'GET'
      Uri    = "https://$($currentEnvironmentData.APIHostName).kpmgcloudops.com/ad/api/v1/backgroundtask/$($taskId)"
      Headers = @{
         "Authorization" = "Bearer $($aadToken)"
         }
  }
  $inprogressStates = @("Running", "Pending", "ContinuedAsNew")
  $status = "Running"
  while($inprogressStates -contains $status) {
     $response = Invoke-RestMethod @statusParams
     $status = $response.status
     Write-Host ($response | ConvertTo-Json -Depth 10 -Compress)
     if($response.status -eq "Running") {
        Start-Sleep -Seconds 15
     }
  }
  Write-Host "Background task has reached final state of $($response.status)."  
  return $response
} 

$groupName = "dm-rc-$rcId-provisioning-$($currentEnvironmentData.EnvironmentSuffix)"
$wsgroupId = $null
# Get group id for workspace provisioning group if already exist

function Retrieve-WorkspaceProvisioningGroupId($requestParameters) {
  try {
    Write-Host "Retrieving workspace provisioning group id to check if group $($groupName) already exists..."
    $response = Invoke-RestMethod @requestParameters
    Write-Host $response
    Write-Host "Retrieving workspace provisioning group complete."
    $groupId = $response.id
    Write-Host "Workspace provisioning group id is $($groupId) "
  }
  catch {
    if ($_.Exception.Response.StatusCode.value__ -eq 404) {
       $groupId = $null
    } 
  } 
  return $groupId
}

$requestParameters = @{
  Method = 'GET'
  Uri    = "https://$($currentEnvironmentData.APIHostName).kpmgcloudops.com/ad/api/v1/group/$($groupName)"
  Headers = @{
     "Authorization" = "Bearer $($aadToken)"
     }                        
}
$wsgroupId = Retrieve-WorkspaceProvisioningGroupId $requestParameters
Write-Host "Group id is $($wsgroupId)"

if($wsgroupId -eq $null) {
   # Create workspace provisioning group
   Write-Host "Creating workspace provisioning group..."
   $requestParameters = @{
   Method = 'POST'
   Uri    = "https://$($currentEnvironmentData.APIHostName).kpmgcloudops.com/ad/api/v1/group"
   Headers = @{
     "Authorization" = "Bearer $($aadToken)"
     "Content-Type"  = "application/json"
     "Accept"        = "application/json"
    }                        
   Body = @{
    "displayName"  = "dm-rc-$rcId-provisioning-$($currentEnvironmentData.EnvironmentSuffix)"
    "description"  = "Member of this group are able to perform any subsequent provisioning actions, which could include reading from the core key vault."
    "mailNickname" = "dm-rc-$rcId-provisioning-$($currentEnvironmentData.EnvironmentSuffix)"
    } | ConvertTo-Json
   }

   $response = Invoke-RestMethod @requestParameters
   $wsgroupId = $response.taskOutput.groupId

   #check background status until group is created
   Write-Host "group creation in progress"
   $groupStatus = Get-BackgroundStatus $response.taskId
   $wsgroupId = $groupStatus.taskOutput.groupId
   if ($wsgroupId -eq $null) {
      throw "Error creating workspace provisioning group"
    }
    Write-Host "Created workspace provisioning group."
    Write-Host "Workspace provisioning group id is $($wsgroupId) "
}

# Assign workspace provisioning group to key vault reader group

Write-Host "Assigning provisioning group to key vault reader group..."
$requestParameters = @{
   Method = 'POST'
   Uri    = "https://$($currentEnvironmentData.APIHostName).kpmgcloudops.com/ad/api/v1/groupmembership/members"
   Headers = @{
     "Authorization" = "Bearer $($aadToken)"
     "Content-Type"  = "application/json"
     "Accept"        = "application/json"
   }                        
   Body = @{
     "memberId"   = "$($wsgroupId)"
     "groupId"    = "$($currentEnvironmentData.CoreKeyVaultSecretReaderGroup)" # core key vault secret reader group
     "memberType" = "Group"
   } | ConvertTo-Json
}

function Assigning-ProvisioningGroup($requestParameters, $retryCount) {
   if($retryCount -gt 0) {
      Write-Host "Attempting to assign provisioning group..."
      try {
        Write-Host "Assigning provisioning group..."
        $response = Invoke-RestMethod @requestParameters
       }
      catch {
        Write-Host $_.Exception.Response.StatusCode.value__
        if ($_.Exception.Response.StatusCode.value__ -eq 400) {                    
           # https://docs.microsoft.com/en-us/graph/api/group-post-members?view=graph-rest-1.0&tabs=http#response
           Write-Host "Received Bad Request (400) response.  This is likely because the object is null. See https://docs.microsoft.com/en-us/graph/api/group-post-members?view=graph-rest-1.0&tabs=http#response"
        } else {
            Start-Sleep -Seconds 5
            $retryCount = $retryCount - 1
            Assigning-ProvisioningGroup $requestParameters $retryCount
        }
      } 
   } else {
       Write-Host "Failed to assign provisioning group."
       throw
   }
   return $response
}

$response = Assigning-ProvisioningGroup $requestParameters 5
if($response.status -eq "Failed") {
   $response
   Write-Host "Failed to assign provisioning group"
   throw
 } else {                  
   Write-Host $response
   Write-Host "Assignment finished."
 }

# Add all managed identities to provisioning group

$vms = Get-AzVM -ResourceGroupName "RGP-USE-$rcId-$($currentEnvironmentData.EnvironmentSuffix)"
foreach($vm in $vms) {
   # Assign RBAC to provisioning group at the vm scope
   Write-Host "Assigning RBAC..."
   Invoke-New-AzRoleAssignment $wsgroupId $vm.Id 36
   if($vm.Identity) {
      if($vm.Identity.PrincipalId) {
          $requestParameters = @{
             Method = 'POST'
             Uri    = "https://graph.microsoft.com/v1.0/groups/$($wsgroupId)/members/`$ref"
             Headers = @{
               "Authorization" = "Bearer $($graphToken)"
               "Content-Type"  = "application/json"
               "Accept"        = "application/json"
             }                        
             Body = @{
               "@odata.id" = "https://graph.microsoft.com/v1.0/servicePrincipals/$($vm.Identity.PrincipalId)"       
             } | ConvertTo-Json
          }
          Write-Host "Adding managed identity to provisioning group..."                      
          Add-AADGroupMember $requestParameters 30

          # Now add the cloud init extension
          # Make sure double quotes are used in the command to execute, single quotes won't work - that was fun to debug
          # https://stackoverflow.com/questions/49131353/powershell-script-is-not-executing-when-using-azurerm-virtual-machine-extension
          Write-Host "Adding cloud init extension..."
          $protectedSettings = @{"commandToExecute" = "powershell -ExecutionPolicy Unrestricted -command `"`$taskName = 'cloud-init';`$ts = New-TimeSpan -Seconds 30;`$date = (Get-Date) + `$ts;`$trigger = New-ScheduledTaskTrigger -Once -At `$date;`$principal = New-ScheduledTaskPrincipal -UserId SYSTEM -LogonType ServiceAccount -RunLevel Highest;`$initCommand = 'cp c:\azuredata\customdata.bin c:\azuredata\cloud-init.ps1; c:\azuredata\cloud-init.ps1 > c:\azuredata\cloud-init.log';`$arguments = '-NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass -Command `' + `"`$(`$initCommand)`";`$executable='PowerShell.exe';`$action = New-ScheduledTaskAction -Execute `$executable -Argument `$arguments;Register-ScheduledTask -TaskName `$taskName -Action `$action -Trigger `$trigger -Principal `$principal;`""};

          Set-AzVMExtension -ResourceGroupName $vm.ResourceGroupName `
             -Location $vm.Location `
             -VMName $vm.Name `
             -Name "cloud-init" `
             -Publisher "Microsoft.Compute" `
             -ExtensionType "CustomScriptExtension" `
             -TypeHandlerVersion "1.10" `
             -ProtectedSettings $protectedSettings
          Write-Host "Extension added."
        }
    } 
}
Write-Host "Finished."
Param(
[Parameter(Mandatory)]$workspaceParameters,
[Parameter(Mandatory)]$deploymentEnv)
$ErrorActionPreference = "SilentlyContinue"
$parsedValuesparameters = "$workspaceParameters" | ConvertFrom-Json
$parsedValues = $parsedValuesparameters | ConvertFrom-Json
$env = $deploymentEnv
$sub = $parsedValues.SubscriptionId
$subName = (Get-AzSubscription -SubscriptionId $sub).Name
if ($env -eq "dev-commercial") {
   if($subName -ne "dev-spoke-digitalmatrix-local-1"){
     $env = "dv"
   } else {
     $env = "lc"
   }
}
if ($env -eq "qa-commercial") {
$env = "qa"
}
if ($env -eq "cat-commercial") {
$env = "cat"
}
if ($env -eq "uat-commercial") {
$env = "uat"
}
if ($env -eq "pd-commercial") {
$env = "pd"
}
$workspaceId = $parsedValues.WorkspaceId
$RecoveryServiceVaultName = "rsv-use-$workspaceId-$env"
$ResourceGroupName = "RGP-USE-WS-$workspaceId-$env"
Set-AzContext -Subscription $sub
$vault = Get-AzRecoveryServicesVault -Name $RecoveryServiceVaultName
Set-AzRecoveryServicesVaultProperty -VaultId $vault.ID -SoftDeleteFeatureState Disable

#Get all containers in the vault
#$Conts = Get-AzRecoveryServicesBackupContainer -ContainerType AzureVM -BackupManagementType AzureVM -VaultId $vault.ID 

#Stop protection and delete data for all backup-protected items
$Cont = Get-AzRecoveryServicesBackupItem -BackupManagementType AzureVM -WorkloadType AzureVM -VaultId $vault.ID | Where-Object {$_.DeleteState -eq "NotDeleted"}
foreach ($item in $Cont) {
Write-Host "Remove VM Backup"
Undo-AzRecoveryServicesBackupItemDeletion -Item $item -VaultId $vault.ID -Force
Disable-AzRecoveryServicesBackupProtection -Item $item -VaultId $vault.ID -RemoveRecoveryPoints -Force -Verbose
}
Write-Host ($writeEmptyLine + "# Deleted backup data for all cloud protected items in Recovery Services vault " + $vault.Name)
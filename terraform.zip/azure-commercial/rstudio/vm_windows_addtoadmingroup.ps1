# Add Members To Administrator

Get-LocalGroupMember -Group "Administrators"

Add-LocalGroupMember -Group "Administrators" -Member "CO-RSTUDIOUsers"

Add-LocalGroupMember -Group "Administrators" -Member "CO-RSTUDIOServerAdmin"

Add-LocalGroupMember -Group "Administrators" -Member "CO-RSTUDIOAdmin"

Get-LocalGroupMember -Group "Administrators"


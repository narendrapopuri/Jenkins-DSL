//Todo

This module makes a hostpool with a desktop and remote application group.
Remote application group gets an azure group assigned.
The host pool is configured by null resource.


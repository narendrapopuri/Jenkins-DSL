This module provides the below functionalities

1. Option to select an Azure Hardened Image ID, or select Azure Defalt MarketPlace Image, based on flags.
2. Option to enforce new naming convention, and also utilse  old naming convention by setting the flag "enforce_vm_naming_convention=false".
3. Achieves the granularity of OS and Data Disk Configuration, for disk type and size.
4. Terraform 12 code compatible.

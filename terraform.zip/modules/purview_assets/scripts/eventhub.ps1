$getName = az eventhubs namespace list -g managed-purview-rg --subscription $args[0] --query [].name -o json | convertfrom-json
$eh = ('{"event_hub":"' + $getName + '" }')
write-output $eh
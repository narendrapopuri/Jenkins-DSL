$getName = az storage account list -g managed-purview-rg --subscription $args[0] --query [].name -o json | convertfrom-json
$sa = ('{"storage_account":"' + $getName + '" }')
write-output $sa
az extention add --name purview
$getName = az purview account add-root-collection-admin --account-name $args[1] --resource-group $args[2] --object-id $args[0] --debug
$item = ('{"object_id":"' + $args[0] + '", "account_name":"'+ $args[1]+'", "rg":"'+$args[2]+'", "status": "'+$getName+'" }')
write-output $item


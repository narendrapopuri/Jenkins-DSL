Pre-requisites for using this module:

1. Use the above syntax to fully utilise this module
2. If the SQL Database is required to be created separately, use the count to 0, and define a separate configuration for SQL-Database.
3. Your must be on or above Azure provider 2.35.0 (TF- Version 12), to be able to utilise this module.
4. The SPN (spn-devops-*****) performing the deployment, must have User Access Administrator/Owner RBAC, on the storage account, over which the SQL auditing policy is being setup.
5. Below is a sample code to be used for this module

module "sql_server_test" {
    source                              = "../../modules12/mssql_server"
    mssql_server_name                   = "mssqlsrv-${var.location_acronym}-${lower(var.application_acronym)}-${lower(var.environment_acronym)}"
    resource_group_name                 = module.applicationrg.resource_group_name
    resource_group_location             = module.applicationrg.resource_group_location
    administrator_login_username        = "${lower(var.application_acronym)}admin01"
    administrator_login_password        = var.sql_server_admin_password
    tags                                = var.tags
    mssql_ad_group_name                 = azuread_group.sql_server_admins.name
    mssql_ad_group_object_name          = azuread_group.sql_server_admins.object_id
    audit_log_storage_account_id        = module.storage_account.id
    auditlog_storage_account_endpoint   = module.storage_account.primary_blob_endpoint
    mssql_database_name                 = "sql-${var.location_acronym}-${var.application_acronym}-${var.environment_acronym}"
    sql_database_count                  = 1
    sqlTostorage_assignment_name_guiid  = "006db005-c6f4-49c8-abc3-179e9333157d"  #Should be a unique guiid
}
param (
    [string]$keyVaultName,
    [string]$secretName,
    [string]$pathToSavePfx,
    [string]$subjectName,
    [array]$subjectAlternativeName,
    [bool]$isProd
)

# Check for existing cert
Write-Host "Getting Secret..."

$cert = Get-AzKeyVaultSecret -VaultName $keyVaultName -Name $secretName
if($cert -eq $null) # if we did not find a cert
{
    Write-Host "No cert was found"
    if($isProd)
    {
        throw "You need to request a production certificate for $secretName - exiting";
    }
    else
    {
        Write-Host "Making a new cert"

        $policy = New-AzKeyVaultCertificatePolicy -SecretContentType "application/x-pkcs12" -SubjectName "$subjectName" -IssuerName "Self" -ValidityInMonths 24 -ReuseKeyOnRenewal -DnsName $subjectAlternativeName
        Add-AzKeyVaultCertificate -VaultName "$KeyVaultName" -Name "$secretName" -CertificatePolicy $policy
        Write-Host "Waiting for certificate to be generated"
        do
        {
            $progress = (Get-AzKeyVaultCertificateOperation -VaultName "$keyVaultName" -Name "$secretName").Status
            Write-Host "Certificate creation: $progress..."
            Start-Sleep -Seconds 3
        }until($progress -eq "completed")

        $cert = Get-AzKeyVaultSecret -VaultName "$keyVaultName" -Name "$secretName"

    }
}

Write-Host "I have the Secret"

Write-Host "I am converting it to Base64..."
$certBytes = [System.Convert]::FromBase64String($cert.SecretValueText)
Write-Host "It has been converted to Base64"

if($secretName -notmatch "-pfx$")
    {
        $secretName = "$secretName-pfx"
    }

$name = $secretName.Replace('-','.')
[System.IO.File]::WriteAllBytes("$pathToSavePfx\$name", $certBytes)
Write-Host "The cert has been Downloaded"

Write-Host "Operations Complete for pfx"

Write-Host "I am creating a certCollection only for converting pfx to cer..."
$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
Write-Host "certCollection created"

Write-Host "I am importing the pfx for creating cer"
$certCollection.Import($certBytes,$null,[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
Write-Host "Importing the pfx cert complete"

Write-Host "Exporting the pfx cert without privatekey as cer"
$certificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert)
$cerName = $name.Replace('pfx','cer')
[System.IO.File]::WriteAllBytes("$pathToSavePfx\$cerName", $certificateBytes)
Write-Host "Cer created from Pfx and copied to local directory"

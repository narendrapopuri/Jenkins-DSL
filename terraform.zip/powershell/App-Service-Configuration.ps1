﻿param (
    [string]$ResourceGroupName, 
    [string]$webAppName,    
    [string]$location,
    [string]$appServicePlan,
    [string]$appBackupStorageAccountName,
    [string]$appBackupStorageAccountContainerName,
    [string]$client_ID,
    [string]$tenant_ID,
    [string]$client_Secret,
    [string]$subscription_ID
)

try {
	Get-AzApplicationInsights -Name $webAppName -ResourceGroupName $ResourceGroupName -ErrorAction Stop | Out-Null
	Write-Host "App-Insights already exists with name: $($webAppName)"
}

catch {

    New-AzApplicationInsights -ResourceGroupName $ResourceGroupName -Name $webAppName -location $location
}


try {
	Get-AzWebApp -Name $webAppName -ResourceGroupName $ResourceGroupName -ErrorAction Stop | Out-Null
	Write-Host "WebApp already exists with name: $webAppName"
}
catch
{
	Write-Host "WebApp doesn't exists, hence, creating new: $webAppName"
	New-AzWebApp -Name $webAppName -ResourceGroupName $ResourceGroupName -AppServicePlan $appServicePlan -Location $location
	Write-Host "WebApp creation Successful"

	Write-host "Turning On System Identity"
	try {
                Set-AzWebApp -AssignIdentity $true -Name $webAppName -ResourceGroupName $ResourceGroupName
                Write-host "System Identity turned on successfully"
        }
        catch {
                Write-Host "System Identity turned on failed"
        }    


	Write-Host "Configuring Backup for App."
	try {
		$key = (Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -AccountName $appBackupStorageAccountName).Value[0]
		$ctx = New-AzureStorageContext -StorageAccountName $appBackupStorageAccountName -StorageAccountKey $key
		$sastoken = New-AzureStorageContainerSASToken -Name $appBackupStorageAccountContainerName -Permission rwdl -Context $ctx
		$sasurl = "https://" + $appBackupStorageAccountName + ".blob.core.windows.net/" + $appBackupStorageAccountContainerName + $sastoken
		New-AzWebAppBackup -ResourceGroupName $ResourceGroupName -Name $webAppName -StorageAccountUrl $sasurl
                Edit-AzWebAppBackupConfiguration -ResourceGroupName $ResourceGroupName -Name $webAppName -StorageAccountUrl $sasurl -FrequencyInterval 1 -FrequencyUnit Day -KeepAtLeastOneBackup -StartTime (Get-Date).AddHours(1) -RetentionPeriodInDays 10
		Write-Host "Backup Configuration Succeeded."
	}
	catch {
		Write-Host "Backup Configuration Failed."
	}

    try {#Get instrumentation key from ENV application insights resource
    az login --service-principal -u $client_ID -p $client_Secret --tenant $tenant_ID
    az account set -s $subscription_ID
            $key = az resource show -g $ResourceGroupName -n $webAppName --resource-type "Microsoft.Insights/components" --query properties.InstrumentationKey
            az webapp config appsettings set -g $ResourceGroupName -n $webAppName --settings "APPINSIGHTS_INSTRUMENTATIONKEY = $key"

        }
    catch {
    Write-Host "App Insights Linking failed"
    }

}
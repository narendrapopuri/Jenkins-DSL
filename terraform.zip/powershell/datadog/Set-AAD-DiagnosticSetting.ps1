param (
  $ClientId,
  $TenantId,
  $ClientSecret,  
  $SubscriptionId,
  $ResourceGroupName,
  $EventhubNamespace,
  $EventhubName,
  $DiagnosticSettingName,
  $AuthorizationRuleName
)

#Import-Module Az
#Login-AzAccount
#Set-AzContext -SubscriptionName "dev-core"
#Set-AzContext -SubscriptionId $SubscriptionId

az login --service-principal -u $ClientId -p $ClientSecret --tenant $TenantId
az account set -s $SubscriptionId

#$evhnsid = (Get-AzEventHubNamespace -ResourceGroupName $ResourceGroupName -NamespaceName $EventhubNamespace ).Id
#Write-Host $evhnsid

#$evhid = (Get-AzEventHub -ResourceGroupName $ResourceGroupName -NamespaceName $EventhubNamespace -Name $EventhubName).Id
#Write-Host $evhid

$evhRuleid = (Get-AzEventHubAuthorizationRule -ResourceGroupName $ResourceGroupName -NamespaceName $EventhubNamespace -Name "$AuthorizationRuleName").Id
#Write-Host $evhRuleid

function Get-AzCachedAccessToken()
{
    $ErrorActionPreference = 'Stop'

    $azureRmProfileModuleVersion = (Get-Module Az.Profile).Version
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    if(-not $azureRmProfile.Accounts.Count) {
        Write-Error "Ensure you have logged in before calling this function."    
    }
  
    $currentAzureContext = Get-AzContext
    $profileClient = New-Object Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient($azureRmProfile)
    Write-Debug ("Getting access token for tenant" + $currentAzureContext.Tenant.TenantId)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Tenant.TenantId)
    $token.AccessToken
}
$token = Get-AzCachedAccessToken
Write-Host $token



#setup diag settings
$uri = "https://management.azure.com/providers/microsoft.aadiam/diagnosticSettings/{0}?api-version=2017-04-01-preview" -f $DiagnosticSettingName
$body = @"
{
    "id": "providers/microsoft.aadiam/providers/microsoft.insights/diagnosticSettings/$DiagnosticSettingName",
    "type": null,
    "name": "$DiagnosticSettingName",
    "location": null,
    "kind": null,
    "tags": null,
    "properties": {
      "eventHubAuthorizationRuleId": "$evhRuleid",
      "eventHubName": "$EventhubName",
      "metrics": [],
      "logs": [
        {
          "category": "AuditLogs",
          "enabled": true,
          "retentionPolicy": { "enabled": false, "days": 0 }
        },
        {
          "category": "SignInLogs",
          "enabled": true,
          "retentionPolicy": { "enabled": false, "days": 0 }
        }
      ]
    },
    "identity": null
  }
"@

$headers = @{
    "Authorization" = "Bearer $token"
    "Content-Type"  = "application/json"
}
$response = Invoke-WebRequest -Method Put -Uri $uri -Body $body -Headers $headers

if ($response.StatusCode -ne 200) {
    throw "an error occured: $($response | out-string)"

}


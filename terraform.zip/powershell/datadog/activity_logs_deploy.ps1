param (
    $SubscriptionId,
    $ResourceGroupName,
    $ResourceGroupLocation,
    $EventhubNamespace,
    $EventhubName,
    $DiagnosticSettingName
)

Set-AzContext -SubscriptionId $SubscriptionId

try {
New-AzDeployment `
    -TemplateFile  "./activity_log_diagnostic_settings.json" `
    -eventHubNamespace $EventhubNamespace `
    -eventHubName $EventhubName `
    -settingName $DiagnosticSettingName `
    -resourceGroup $ResourceGroupName `
    -Location $ResourceGroupLocation `
    -Verbose `
    -ErrorAction Stop
} catch {
    Write-Error $_
    Throw $_
}
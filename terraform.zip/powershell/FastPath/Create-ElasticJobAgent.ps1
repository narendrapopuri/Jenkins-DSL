param (
    [string]$ElasticJobAgentName, 
    [string]$ResourceGroupName,    
    [string]$ServerName,
    [string]$ElasticPoolName,
    [string]$sqlAdminUser,
    [string]$KeyVaultName,
    [string]$sqlpwdSecret
    
)
 
# Create the job database
Write-Output "Creating a blank SQL database to be used as the Job Database..." 
$JobDatabase = New-AzSqlDatabase -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName  $ElasticJobAgentName -ElasticPoolName $ElasticPoolName
$JobDatabase
 
Register-AzProviderFeature -FeatureName sqldb-JobAccounts -ProviderNamespace Microsoft.Sql
Write-Output "Creating job agent..."
$JobAgent = $JobDatabase | New-AzSqlElasticJobAgent -Name $ElasticJobAgentName
$JobAgent
 
# Create job credential in Job database for master user
Write-Output "Creating job credentials..."
$KeyVaultPassword = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $sqlpwdSecret 
$LoginPasswordSecure = (ConvertTo-SecureString -String $KeyVaultPassword.SecretValueText -AsPlainText -Force)
$MasterCred = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $sqlAdminUser, $LoginPasswordSecure
$MasterCred = $JobAgent | New-AzSqlElasticJobCredential -Name "mymastercred" -Credential $MasterCred
$JobCred = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $sqlAdminUser, $LoginPasswordSecure
$JobCred = $JobAgent | New-AzSqlElasticJobCredential -Name "myjobcred" -Credential $JobCred
 
Write-Output "Creating test target groups..."
# Create ServerGroup target group
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'ALL'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'Assure'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureActiveDirectory'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureAcumatica'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureAX'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureAX5'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureAX7'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureAzureActiveDirectory'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureCDS'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureCoupa'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureD365Bc'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureD365S'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureGP'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureIntacct'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureJDEdwards'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureNAV'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureNetSuite'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureOracle'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureOracleFC'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssurePeoplesoft'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureSalesforce'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureSAP'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureSAPB1'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureSL'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AssureWorkday'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrail'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailAX'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailAX5'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailAX7'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailGP'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailNAV'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailNetSuite'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailOracle'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailOracleFC'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailSAP'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'AuditTrailSL'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManager'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerAX'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerAX7'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerD365S'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerGP'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerNAV'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerNetSuite'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerOracle'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerOracleFC'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'IdentityManagerSAP'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'SecurityDesigner'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'SecurityDesignerAX7'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'SecurityDesignerAX'
$ServerGroup = $JobAgent | New-AzSqlElasticJobTargetGroup -Name 'Universal'
 
Write-Output "Creating a new job and job steps"
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AdHoc' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'ALL' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'Assure' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'Assure' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureActiveDirectory' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureActiveDirectory' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureAcumatica' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureAcumatica' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureAX' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureAX' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureAX5' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureAX5' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureAX7' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureAX7' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureAzureActiveDirectory' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureAzureActiveDirectory' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureCDS' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureCDS' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureCoupa' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureCoupa' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureD365Bc' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureD365Bc' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureD365S' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureD365S' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureGP' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureGP' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureIntacct' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureIntacct' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureJDEdwards' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureJDEdwards' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureNAV' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureNAV' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureNetSuite' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureNetSuite' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureOracle' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureOracle' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureOracleFC' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureOracleFC' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssurePeoplesoft' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssurePeoplesoft' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureSalesforce' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureSalesforce' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureSAP' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureSAP' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureSAPB1' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureSAPB1' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureSL' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureSL' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AssureWorkday' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AssureWorkday' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrail' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrail' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailAX' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailAX' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailAX5' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailAX5' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailAX7' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailAX7' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailGP' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailGP' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailNAV' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailNAV' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailNetSuite' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailNetSuite' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailOracle' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailOracle' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailOracleFC' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailOracleFC' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailSAP' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailSAP' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'AuditTrailSL' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'AuditTrailSL' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'Certifications' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'Assure' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'Cleanup' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'ALL' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'Core' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'ALL' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManager' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManager' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerAX' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerAX' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerAX7' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerAX7' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerD365S' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerD365S' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerGP' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerGP' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerNAV' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerNAV' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerNetSuite' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerNetSuite' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerOracle' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerOracle' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerOracleFC' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerOracleFC' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'IdentityManagerSAP' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'IdentityManagerSAP' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'SecurityDesigner' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'SecurityDesigner' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'SecurityDesignerAX7' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'SecurityDesignerAX7' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'SecurityDesignerAX' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'SecurityDesignerAX' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
$Job = $JobAgent | New-AzSqlElasticJob -Name 'Universal' -RunOnce
$Job | Add-AzSqlElasticJobStep -Name 'step1' -TargetGroupName 'ALL' -CredentialName $JobCred.CredentialName -CommandText 'select 1' -RetryAttempts 3
#Runbook Name: UpdateUsersInEngagementRunbook
#Runbook Type: Powershell
#Runbook Description: This runbook updates the user in Engagement

param(
    [parameter(Mandatory=$false)]
    [Object] $WebhookData
)

$ConnectionName = "AzureRunAsConnection"
$IsLoginToAzureSuccessful = $True
$IsLocal = $false
$ToEmailAddress = ""
$FromEmailAddress = ""
$SendEmail = $True
#$KARTSmtpServer = "smtpout.us.kworld.kpmg.com"



try
{

	Write-Output 'Connecting to Azure'
	# Get the connection "AzureRunAsConnection "
    connect-azaccount -identity
    $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 
    $content = $response.Content | ConvertFrom-Json
    $AccessToken = $content.access_token 
    $WebHookBody = $WebhookData.RequestBody | ConvertFrom-Json 
    $UserList =  $WebHookBody.KartUserIds
    $ServerName = $WebHookBody.ServerName
	$ToEmailAddress = $WebHookBody.ToEmailAddress
	$FromEmailAddress = $WebHookBody.FromEmailAddress
	$SMTPPortServer = $WebHookBody.SMTPPort
	$KARTSmtpServer = $WebHookBody.SMTPServer

	Write-Output 'Connected to Azure'
 }
catch {
    "Error occured"
    
}



$Bool = "bool"

function GetValue{param($value,$type)

$ret = $value

    switch ($type) 
        {
             $Bool
             {
                if($value -eq $True)
                {                
                 $ret = 1
                }
                elseif($value -eq $False)
                {               
                $ret = 0
                }
                else
                {
                  $ret = 'null'
                }
               
                break;
                
             }
        }

return $ret

}

#Getting DB Connection String
function GetDBConnectionString{param($dbNameVar)

    $SqlConnectionStr  = New-Object System.Data.SqlClient.SqlConnection 
    $SqlConnectionStr.AccessToken = $AccessToken
    $SqlConnectionStr.ConnectionString = "Data Source="+$ServerName+".database.windows.net;initial catalog="+$dbNameVar+";"

    return $SqlConnectionStr
}

function GetDataFromDB{param($sqlquery)

$SQLDataTable = New-Object System.Data.DataTable
$SqlConnection  =   GetDBConnectionString -dbNameVar "KART_CENTRAL"
$SqlConnection.Open()
 
# Create Sql Command
$SqlCommand = New-Object System.Data.SqlClient.SqlCommand
$SqlCommand.CommandText = $sqlquery
$SqlCommand.Connection = $SqlConnection

$rdr=$SqlCommand.ExecuteReader()
$dt=new-object System.Data.DataTable
$dt.Load($rdr)
$SqlConnection.Close() 



return ,$dt

}


#Updating Users
function UpdateUsersInEngagement
{
    

    Write-Output "`r`nUpdating User Operation started"

    $sqlQueryForEngagment = "SELECT EngagementName, DatabaseName FROM app.Engagement WHERE ISNULL(IsArchived,0) <> 1 AND EngagementName <> 'KART MASTER' "   

    $sqlQueryForUser = "SELECT [UserName],[FirstName],[LastName],[IsActive],[IsInternal],[IsUserInCloud],[HasPowerBIAccess],[HasRDPAccess],
                        [PhoneNumber],[CountryCode],[Domain] FROM scrty.aspnetusers WHERE KARTUserID in ("+$UserList+")"

    Write-Output "`r`nFetching All Active Engagements"
    $engagmentDT = GetDataFromDB $sqlQueryForEngagment

    Write-Output "Fetching User which needs to be updated"
   

    $userDT = GetDataFromDB $sqlQueryForUser

    "Following users will be updated`r`n"

    "=============================================================="
    foreach($userInfo in  $userDT.Rows)
    {
        " "+$userInfo["UserName"]
        $UpdateUserList.Add($userInfo["UserName"])
    }
    
    "=============================================================="

    foreach($Engagement in  $engagmentDT.Rows)
     { 
       "`r`nUpdating Users in Engagement <b>" + $Engagement["EngagementName"] + "</b>"
         UpdateUserinDB -dt $userDT -databaseName $Engagement["DatabaseName"]
       #"Updating Users in Engagement <b>" + $Engagement["EngagementName"] + "</b> completed"
     }

     

       
   Write-Output "`r`nUpdating User Operation Completed"
     

 }

 # Updating Users in DB
 function UpdateUserinDB { param($dt,$databaseName)

   try
   {


   $connstr  =  GetDBConnectionString -dbNameVar $databaseName
   $connstr.Open()

  
   $cmd = New-Object System.Data.SqlClient.SqlCommand   
   $cmd.CommandType = [System.Data.CommandType]::StoredProcedure
   $cmd.CommandText = "[scrty].[InsertUpdateUsers]"
   $cmd.Connection = $connstr

   $IdParam = New-Object System.Data.SqlClient.SqlParameter

   $IdParam.ParameterName = "Dimensions"
   $IdParam.SqlDbType = [System.Data.SqlDbType]::Structured
   $IdParam.Direction = [System.Data.ParameterDirection]::Input
   $IdParam.value = $userDT
   $addParam = $cmd.parameters.add($IdParam);  
   $var1 = $cmd.executeNonQuery();
   $connstr.Close()

   }
   catch
   {
        Write-Error -Message $_.Exception.Message        
        $SqlConnectionEng.Close()
       
   }

 }

 # Sending Email
 function SendEmail
 {
  try
  {
    'Sending Email to: ' + $ToEmailAddress

    $currenDate = (Get-Date -Format "MM/dd/yyyy HH:mm")

    $Subject = "KART - UpdatedEngagementUser Runbook Log - $((Get-Date -Format "MM/dd/yyyy HH:mm"))"
    $output   = $output  -replace "`r`n", "<br/>" 
    $Body =  $output 
    
    $SMTPServer = $KARTSmtpServer
    $SMTPPort = $SMTPPortServer

	[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { return $true }
    Send-MailMessage -From $FromEmailAddress -to $ToEmailAddress  -Subject $Subject -Body $Body -BodyAsHtml -UseSsl   -SmtpServer $SMTPServer -port $SMTPPort  –DeliveryNotificationOption OnSuccess

    'Email sent'
  }
  catch
  {
    'Email failed'
     Write-Error -Message $_.Exception.Message    
  }

 }

 'Operation Started.. Output will be displayed on completion'
 $output = UpdateUsersInEngagement | out-string
 Write-Output $output
 
 if($SendEmail -eq $True)
 {
  SendEmail
 }

 





# Runbook Name: KARTDeleteEngagementCubes
# Functionality: For every row in the app.CurrentlyArchived table, deletes the Engagement Cube and its Version Cube, if they exist.
# Called by: Once daily schedule.

param
(
	[parameter(Mandatory=$False)]
    [string] $ResourceGroupName,

    [parameter(Mandatory=$False)]
    [string] $KeyVaultName,

    [parameter(Mandatory=$False)]
    [string] $SqlServerName

)

#Write-Log - To insert the log in the [app].[log] table
function Write-Log {param($messages, $con)
    try
    {
        $cmd = New-Object System.Data.SqlClient.SqlCommand
        $cmd.CommandText = "App.WriteLog"
        $cmd.CommandType = [System.Data.CommandType]::StoredProcedure
        $cmd.Connection = $con 
        $cmd.Parameters.Add("@EventID", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@EventID"].Value = 0
        $cmd.Parameters.Add("@Priority", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@Priority"].Value = 0
        $cmd.Parameters.Add("@Severity", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@Severity"].Value = "Info"
        $cmd.Parameters.Add("@Title", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@Title"].Value = "Delete Engagement & Version Cubes"
        $cmd.Parameters.Add("@Timestamp", [System.Data.SqlDbType]::DateTime) | Out-Null
        $cmd.Parameters["@Timestamp"].Value = [DBNull]::Value
        $cmd.Parameters.Add("@MachineName", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@MachineName"].Value = [System.Net.Dns]::GetHostName()
        $cmd.Parameters.Add("@AppDomainName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@AppDomainName"].Value = ""
        $cmd.Parameters.Add("@ProcessID", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@ProcessID"].Value = "0"
        $cmd.Parameters.Add("@ProcessName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ProcessName"].Value = "KARTDeleteEngagementCubes"
        $cmd.Parameters.Add("@ThreadName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ThreadName"].Value = ""
        $cmd.Parameters.Add("@Win32ThreadId", [System.Data.SqlDbType]::NVarChar, 128) | Out-Null
        $cmd.Parameters["@Win32ThreadId"].Value = ""
        $cmd.Parameters.Add("@Message", [System.Data.SqlDbType]::NVarChar, 1500) | Out-Null
        $cmd.Parameters["@Message"].Value = $messages
        $cmd.Parameters.Add("@FormattedMessage", [System.Data.SqlDbType]::NText) | Out-Null
        $cmd.Parameters["@FormattedMessage"].Value = ""
        $cmd.Parameters.Add("@LogId", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@LogId"].Value = 0
        $con.Open()
        $cmd.ExecuteNonQuery()
        $con.Close()
    }
    catch
    {
        $con.Close()
        Write-Error -Message $_.Exception
    }
}

function DropCubesIfTheyExist
{
    param
    (
        [Parameter(Mandatory=$True)]
        [string] $DatabaseName,

        [Parameter(Mandatory = $False)]
        [string] $KeyVaultName = "kvl-use-krt-dv",

        [Parameter(Mandatory = $False)]
        [string] $SqlServerName = "codeveuskrtsqlserver1"
    )
    try
    {

        $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 
        $content = $response.Content | ConvertFrom-Json
        $AccessToken = $content.access_token
        #"AccessToken: " + $AccessToken



        #if ($SqlServerName -NotContains ".database.windows.net")
        #{
        #    $SqlServerName = $SqlServerName + ".database.windows.net"
        #}
        #"SqlServerName2: "
        #$SqlServerName

        $SqlConnection  = New-Object System.Data.SqlClient.SqlConnection
        $SqlConnection.ConnectionString = "Data Source = " + $SqlServerName + "; initial catalog = KART_CENTRAL;"
        #"Connection string: " + $SqlConnection.ConnectionString
        $SqlConnection.AccessToken = $AccessToken
    

        $Output = $True

        Add-AzureRmAccount -identity

        $SSASServerName = (Get-AzureKeyVaultSecret �VaultName $KeyVaultName -Name "SSASServerName").SecretValueText


        #"SSASServerName: " + $SSASServerName

        $ConnectionName = "AzureRunAsConnection"

        $servicePrincipalConnection = Get-AutomationConnection -Name $ConnectionName

        #$servicePrincipalConnection.GetEnumerator() | % { $_.Key, $_.Value }

        $TenantId = $servicePrincipalConnection.TenantId

        $ApplicationId = $servicePrincipalConnection.ApplicationId

        $CertificateThumbprint = $servicePrincipalConnection.CertificateThumbprint


        $QueryCubeExists = "SELECT [CATALOG_NAME] FROM " + "$" + "SYSTEM.DBSCHEMA_CATALOGS WHERE [CATALOG_NAME] = '" + $DatabaseName + "'"
        #"QueryCubeExists: " + $QueryCubeExists

        $QueryVersionCubeExists = "SELECT [CATALOG_NAME] FROM " + "$" + "SYSTEM.DBSCHEMA_CATALOGS WHERE [CATALOG_NAME] = '" + $DatabaseName + "_Version'"
        #"QueryVersionCubeExists: " + $QueryVersionCubeExists


#region "Delete Engagement Cube"

        $ResultQueryCubeExists = Invoke-ASCmd -Server $SSASServerName -ServicePrincipal -TenantId $TenantId -ApplicationId $ApplicationId -CertificateThumbprint $CertificateThumbprint -Query $QueryCubeExists -OutVariable QueryResult 

        $ResultQueryCubeExists = "<xml>" + $ResultQueryCubeExists + "</xml>"

        #"ResultQueryCubeExists: " + $ResultQueryCubeExists

        $XmlDoc1 = New-Object -TypeName System.Xml.XmlDocument

        $XmlDoc1.LoadXml($ResultQueryCubeExists)

        $XmlResult1 = $XmlDoc1.xml.return.root.row.CATALOG_NAME

        #"XmlResult1.Count: " + $XmlResult1.Count
        #"XmlResult1: " + $XmlResult1

        

        If ($XmlResult1.Count -ne 0 -And $XmlResult1 -eq $DatabaseName)
        {
            "Found cube for delete: " + $DatabaseName

            $QueryCubeDelete = "<Delete xmlns='http://schemas.microsoft.com/analysisservices/2003/engine'><Object><DatabaseID>" + $DatabaseName + "</DatabaseID></Object></Delete>"
            $ResultQueryCubeDelete = Invoke-ASCmd -Server $SSASServerName -ServicePrincipal -TenantId $TenantId -ApplicationId $ApplicationId -CertificateThumbprint $CertificateThumbprint -Query $QueryCubeDelete -OutVariable QueryResult 
            If ($ResultQueryCubeDelete -Contains "<Exception" -Or $ResultQueryCubeDelete -Contains "<Error")
            {
                $message = "Exception encountered while trying to delete Cube: " + $DatabaseName
                Write-Log -messages $message -con $SqlConnection
                If ($Output -eq $True)
                {
                    $Output = $False
                }
			}
            else
            {
                $message = "Cube: " + $DatabaseName + " successfully deleted."
                Write-Log -messages $message -con $SqlConnection     
			}
        }
        else 
        {
            If ($XmlResult1.Count -eq 0)
            {
                $message = "Cube for database: " + $DatabaseName + " does not exist."
                Write-Log -messages $message -con $SqlConnection
            }
        }

#endregion "Delete Engagement Cube"

#region "Delete Version Cube"
        $ResultQueryVersionCubeExists = Invoke-ASCmd -Server $SSASServerName -ServicePrincipal -TenantId $TenantId -ApplicationId $ApplicationId -CertificateThumbprint $CertificateThumbprint -Query $QueryVersionCubeExists -OutVariable QueryResult 
        $ResultQueryVersionCubeExists = "<xml>" + $ResultQueryVersionCubeExists + "</xml>"
        "ResultQueryVersionCubeExists: " + $ResultQueryVersionCubeExists

        $XmlDoc2 = New-Object -TypeName System.Xml.XmlDocument
        $XmlDoc2.LoadXml($ResultQueryVersionCubeExists)
        $XmlResult2 = $XmlDoc2.xml.return.root.row.CATALOG_NAME
        "XmlResult2.Count: " + $XmlResult2.Count

        If ($XmlResult2.Count -ne 0 -And $XmlResult2 -eq ($DatabaseName + "_Version"))
        {
            $QueryVersionCubeDelete = "<Delete xmlns='http://schemas.microsoft.com/analysisservices/2003/engine'><Object><DatabaseID>" + $DatabaseName + "_Version</DatabaseID></Object></Delete>"
            $ResultVersionQueryCubeDelete = Invoke-ASCmd -Server $SSASServerName -ServicePrincipal -TenantId $TenantId -ApplicationId $ApplicationId -CertificateThumbprint $CertificateThumbprint -Query $QueryVersionCubeDelete -OutVariable QueryResult 
            If ($ResultVersionQueryCubeDelete -Contains "<Exception" -Or $ResultVersionQueryCubeDelete -Contains "<Error")
            {
                $message = "Exception encountered while trying to delete Version Cube: " + $DatabaseName + "_Version"
                Write-Log -messages $message -con $SqlConnection
                If ($Output -eq $True)
                {
                    $Output = $False
                }
			}
            else
            {
                $message = "Version Cube: " + $DatabaseName + "_Version successfully deleted."
                Write-Log -messages $message -con $SqlConnection     
			}
        }
        else 
        {
            If ($XmlResult2.Count -eq 0)
            {
                $message = "Version Cube for database: " + $DatabaseName + " does not exist."
                Write-Log -messages $message -con $SqlConnection
            }
        }

#endregion "Delete Version Cube"

    }
    catch
    {
        Write-Error -Message $_.Exception
    }
    return $Output
}


#main
try
{


    $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 
    $content = $response.Content | ConvertFrom-Json
    $AccessToken = $content.access_token
    #"AccessToken: " + $AccessToken

    $SqlConnection  = New-Object System.Data.SqlClient.SqlConnection
    $SqlConnection.ConnectionString = "Data Source = " + $SqlServerName + "; initial catalog = KART_CENTRAL;"
    #"Connection string: " + $SqlConnection.ConnectionString
    $SqlConnection.AccessToken = $AccessToken

    $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
    $SqlCommand.CommandText = "SELECT DatabaseName FROM app.CurrentlyArchived"
    $SqlCommand.Connection = $SqlConnection

    # Create Sql Adapter
    $SqlDataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
    $SqlDataAdapter.SelectCommand = $SqlCommand

    #"Read Engagement Data"
    $DT_Databases = New-Object System.Data.DataTable
    $SqlDataAdapter.Fill($DT_Databases)

    #"Iterate through DB's"
    If ($DT_Databases.Rows.Count -ne 0)
    {
        foreach ($DTRow in $DT_Databases.Rows)
        {
            $DBName = $DTRow["DatabaseName"]

            "--------------------------------------------------------------Call DropCubes: " + $DBName
            DropCubesIfTheyExist -DatabaseName $DBName -SqlServerName $SqlServerName
            

	    }
	}

}
catch
{
    Write-Error -Message $_.Exception
}

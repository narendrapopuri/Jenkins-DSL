#Runbook Name: EngagementRebuildCubesTemplate
#Runbook Type: Powershell
#Runbook Description: Project Runbook Template for Cube Processing

param(
    [parameter(Mandatory=$True)]
    [string] $EngagementDatabaseName,

    [parameter(Mandatory=$True)]
    [string] $SqlServerName,

    [parameter(Mandatory=$True)]
    [string] $SqlAccessToken,

    [parameter(Mandatory=$True)]
    [string] $SSASServerName,

    [parameter(Mandatory=$True)]
    [string] $TenantId,

    [parameter(Mandatory=$True)]
    [string] $ApplicationId,

    [parameter(Mandatory=$True)]
    [string] $CertificateThumbprint
    
)

write-output $EngagementDatabaseName
write-output $SqlAccessToken
write-output $TenantId
write-output $ApplicationId
write-output $CertificateThumbprint


#Write-Log - To insert the log in the [app].[log] table
function Write-Log {param($messages,$title,$con,$procName,$severity)
    try
    {
        $cmd = New-Object System.Data.SqlClient.SqlCommand
        $cmd.CommandText = "App.WriteLog"
        $cmd.CommandType = [System.Data.CommandType]::StoredProcedure
        $cmd.Connection = $con 
        $cmd.Parameters.Add("@EventID", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@EventID"].Value = 0
        $cmd.Parameters.Add("@Priority", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@Priority"].Value = 0
        $cmd.Parameters.Add("@Severity", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@Severity"].Value = $severity
        $cmd.Parameters.Add("@Title", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@Title"].Value = $title
        $cmd.Parameters.Add("@Timestamp", [System.Data.SqlDbType]::DateTime) | Out-Null
        $cmd.Parameters["@Timestamp"].Value = [DBNull]::Value
        $cmd.Parameters.Add("@MachineName", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@MachineName"].Value = [System.Net.Dns]::GetHostName()
        $cmd.Parameters.Add("@AppDomainName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@AppDomainName"].Value = ""
        $cmd.Parameters.Add("@ProcessID", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@ProcessID"].Value = "0"
        $cmd.Parameters.Add("@ProcessName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ProcessName"].Value = $procName
        $cmd.Parameters.Add("@ThreadName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ThreadName"].Value = ""
        $cmd.Parameters.Add("@Win32ThreadId", [System.Data.SqlDbType]::NVarChar, 128) | Out-Null
        $cmd.Parameters["@Win32ThreadId"].Value = ""
        $cmd.Parameters.Add("@Message", [System.Data.SqlDbType]::NVarChar, 1500) | Out-Null
        $cmd.Parameters["@Message"].Value = $messages
        $cmd.Parameters.Add("@FormattedMessage", [System.Data.SqlDbType]::NText) | Out-Null
        $cmd.Parameters["@FormattedMessage"].Value = ""
        $cmd.Parameters.Add("@LogId", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@LogId"].Value = 0
        $con.Open()
        $cmd.ExecuteNonQuery()
        $con.Close()
    }
    catch
    {
        $con.Close()
    }
}

#UpdateIsJobQueuedFlag - to update the IsJobQueued flag in KART_CENTRAL database
function UpdateIsJobQueuedFlag{param($connection)
    try
    { 
        write-output "start UpdateIsJobQueuedFlag"
        $SqlCommand2 = New-Object System.Data.SqlClient.SqlCommand
        $SqlCommand2.CommandText = "SELECT COUNT(1) AS JobsCount FROM app.Job WHERE StartTime IS NULL"
        $SqlCommand2.Connection = $connection

        $connection.Open()
        $Ds=New-Object system.Data.DataSet 
        $Da=New-Object system.Data.SqlClient.SqlDataAdapter($SqlCommand2) 
        [void]$Da.fill($Ds) 
        $rowCount = $Da.Fill($Ds)
        $connection.Close()
        $JobsCount=$Ds.Tables.JobsCount

        write-output "job count" 

        write-output $JobsCount

        if($JobsCount -eq 0)
        {
            write-output "Updating IsJobQueued flag"

            $query = "UPDATE app.Engagement SET IsJobQueued=0 WHERE DatabaseName='"+$EngagementDatabaseName+"';"
            $SqlConnection  = New-Object System.Data.SqlClient.SqlConnection
            $SqlConnection.ConnectionString = "Data Source="+$SqlServerName+";initial catalog=KART_CENTRAL;"
            $SqlConnection.AccessToken = $SqlAccessToken

            $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
            $SqlCommand.Connection = $SqlConnection
            $SqlCommand.CommandText = $query
            $SqlConnection.Open()
            $SqlCommand.ExecuteNonQuery()
            $SqlConnection.Close()     
            write-output "end UpdateIsJobQueuedFlag"
        }
    }
    catch
    {
        write-output $_.Exception.Message
    }
}

#UpdateJob - updating the job status
function UpdateJob {param($JobStatusID,$JobId,$connection)
    try
    {
        write-output "start UpdateJob"
        $command = New-Object System.Data.SqlClient.SqlCommand
        $command.CommandText = "UPDATE [app].[Job] SET JobStatusID = "+$JobStatusID+",IsActive = 0,EndTime = CONVERT(TIME, GETDATE(), 100),ModifiedBy = CreatedBy,ModifiedDate = GETDATE() WHERE JobID ="+$JobId
        $command.Connection = $connection
        $connection.Open()
        $command.ExecuteNonQuery()
        $connection.Close()
        write-output "end UpdateJob"
    }
    catch
    {
        write-output $_.Exception.Message
        $connection.Close()
    }
}

#UpdateIsModifiedFlag - updating the job status
function UpdateIsModifiedFlag {param($IsModified,$ProcessName,$connection)
    try
    {
        write-output " start UpdateIsModifiedFlag"
        $command = New-Object System.Data.SqlClient.SqlCommand
        $command.CommandText = "UPDATE [app].[ProcessStatus] SET IsModified = "+$IsModified+", ModifiedDate = GETDATE() WHERE ProcessName = '"+$ProcessName+"' AND IsActive = 1"
        $command.Connection = $connection
        $connection.Open()
        $command.ExecuteNonQuery()
        $connection.Close()
        write-output " end UpdateIsModifiedFlag"
    }
    catch
    {
        write-output $_.Exception.Message
        $connection.Close()
    }
}

#UpdateSubJobStatus - to update the status in [app].[SubJobStatus] table
function UpdateSubJobStatus{param($JobId,$JobTitle,$JobStatusId,$StartTime,$EndTime,$connection)
    try{
        write-output " start UpdateSubJobStatus"
        $command = New-Object System.Data.SqlClient.SqlCommand
        $command.CommandText = "app.UpdateSubJobStatus"
        $command.CommandType = [System.Data.CommandType]::StoredProcedure
        $command.Connection = $connection

        $command.Parameters.Add("@JobId", [System.Data.SqlDbType]::int) | Out-Null
        $command.Parameters["@JobId"].Value = $JobId
        $command.Parameters.Add("@JobTitle", [System.Data.SqlDbType]::NVarChar, 1000) | Out-Null
        $command.Parameters["@JobTitle"].Value = $JobTitle
        $command.Parameters.Add("@JobStatusId", [System.Data.SqlDbType]::int) | Out-Null
        $command.Parameters["@JobStatusId"].Value = $JobStatusId
        $command.Parameters.Add("@IsStartTime", [System.Data.SqlDbType]::int) | Out-Null
        $command.Parameters["@IsStartTime"].Value = $StartTime
        $command.Parameters.Add("@IsEndTime", [System.Data.SqlDbType]::int) | Out-Null
        $command.Parameters["@IsEndTime"].Value = $EndTime

        $connection.Open()          
        $command.ExecuteNonQuery()
        $connection.Close()
        write-output " end UpdateSubJobStatus"
    }
    catch
    {
        write-output $_.Exception.Message
        $connection.Close()
    }
}

#ProcessEngagementCube - to process the Engagement cube
function ProcessEngagementCube {param($jobID,$connection,[ref]$result)

    $jobTitle = 'ProcessEngagementCube'
    $runningStatus = 3
	$completeStatus = 1
	$failStatus = 4
    $title="Cube Processing"
    
    try {
        write-output "start ProcessEngagementCube"
        #Log Write, Processing Start
        Write-Log -messages "Processing - Start" -title $title -con $connection -procName $jobTitle -severity "0"

        #Calling the UpdateSubJobStatus to update the Running Status
        $timeStart = 1
        UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $runningStatus -StartTime $timeStart -EndTime 0 -connection $connection

        #creating the cube
        $CubeName = $EngagementDatabaseName
        $Query =  "{
            `"refresh`": {
                `"type`": `"full`",
                `"objects`": [
                {
                    `"database`": `""+$CubeName+"`"
                }
                ]
             }
            }"

        $queryExecutionResult = ""
        ProcessCube -query $Query -result ([ref]$queryExecutionResult)
 write-output $queryExecutionResult
 
        if($queryExecutionResult.ToLower().Contains("errorcode")) 
        {   
              #Calling the UpdateSubJobStatus to update the failed Status
             $result.Value = $true
             $currentTime = 1
             UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $failStatus -StartTime 0 -EndTime $currentTime -connection $connection       

             #Log the error
             Write-Log -messages $queryExecutionResult -title $title -con $connection -procName $jobTitle -severity "Error"
        }
        else 
        {
             $result.Value = $false
            #Calling the UpdateSubJobStatus to update the complete Status
            $endTime = 1
            UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $completeStatus -StartTime 0 -EndTime $endTime -connection $connection
       
            #Log Write, Processing End
            Write-Log -messages "Processing - End" -title $title -con $connection -procName $jobTitle -severity "0"
        }      
     
        write-output "end ProcessEngagementCube"
       
    }
    catch 
    {
        write-output $_.Exception.Message
        $message ="Runbook error in ProcessEngagementCube" + $_.Exception.Message

        #Log the error
        Write-Log -messages $message -title $title -con $connection -procName $jobTitle -severity "Error"
    }
}

#ProcessEngagementVersionCube - to process the Engagement version cube
function ProcessEngagementVersionCube {param($jobID,$connection,[ref]$result)    
    $jobTitle = 'ProcessEngagementVersionCube'
    $runningStatus = 3
	$completeStatus = 1
	$failStatus = 4
    $title="Cube Processing"

    try {
        write-output "start ProcessEngagementVersionCube"
        #Log Write, Processing Start
        Write-Log -messages "Processing - Start" -title $title -con $connection -procName $jobTitle -severity "0"

        #Calling the UpdateSubJobStatus to update the Running Status
        $timeStart = 1
        UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $runningStatus -StartTime $timeStart -EndTime 0 -connection $connection

        #creating the cube
         $CubeName = $EngagementDatabaseName + "_Version"
         $Query =  "{
            `"refresh`": {
                `"type`": `"full`",
                `"objects`": [
                {
                    `"database`": `""+$CubeName+"`"
                }
                ]
             }
            }"

         $queryExecutionResult = ""
        ProcessCube -query $Query -result ([ref]$queryExecutionResult)
 write-output $queryExecutionResult

        if($queryExecutionResult.ToLower().Contains("errorcode")) 
        {   
              #Calling the UpdateSubJobStatus to update the failed Status
             $result.Value = $true
             $currentTime = 1           
       
            " start write fail"
             UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $failStatus -StartTime 0 -EndTime $currentTime -connection $connection       
" end write fail"
             #Log the error
             Write-Log -messages $queryExecutionResult -title $title -con $connection -procName $jobTitle -severity "Error"
        }
        else 
        {
             $result.Value = $false
            #Calling the UpdateSubJobStatus to update the complete Status
            $endTime = 1             
            UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $completeStatus -StartTime 0 -EndTime $endTime -connection $connection
       
            #Log Write, Processing End
            Write-Log -messages "Processing - End" -title $title -con $connection -procName $jobTitle -severity "0"
        }  
     
        #Log Write, Processing End
        write-output "end ProcessEngagementVersionCube"       
    }
    catch 
    {
        write-output $_.Exception.Message
        $message ="Runbook error in ProcessEngagementCube" + $_.Exception.Message
       
        #Log the error
        Write-Log -messages $message -title $title -con $connection -procName $jobTitle -severity "Error"      
    }
}

#ProcessPartialCube - to process the cube
function ProcessPartialCube {param($jobID,$query,$connection,[ref]$result)
 write-output "start ProcessPartialCube"  
    $jobTitle = 'ProcessPartialCube'
    $runningStatus = 3
	$completeStatus = 1
	$failStatus = 4
    $title="Cube Processing"

    try {
        write-output "start ProcessPartialCube"
        #Log Write, Processing Start
        Write-Log -messages "Processing - Start" -title $title -con $connection -procName $jobTitle -severity "0"

        #Calling the UpdateSubJobStatus to update the Running Status
        $timeStart = 1
        UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $runningStatus -StartTime $timeStart -EndTime 0 -connection $connection

        #creating the cube
         $queryExecutionResult = ""
        ProcessCube -query $Query -result ([ref]$queryExecutionResult)


        if($queryExecutionResult.ToLower().Contains("errorcode")) 
        {   
              #Calling the UpdateSubJobStatus to update the failed Status
             $result.Value = $true
             $currentTime = 1
             UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $failStatus -StartTime 0 -EndTime $currentTime -connection $connection       

             #Log the error
             Write-Log -messages $queryExecutionResult -title $title -con $connection -procName $jobTitle -severity "Error"
        }
        else 
        {
             $result.Value = $false
            #Calling the UpdateSubJobStatus to update the complete Status
            $endTime = 1
            UpdateSubJobStatus -JobId $jobID -JobTitle $jobTitle -JobStatusId $completeStatus -StartTime 0 -EndTime $endTime -connection $connection
       
            #Log Write, Processing End
            Write-Log -messages "Processing - End" -title $title -con $connection -procName $jobTitle -severity "0"
        }  

        #Log Write, Processing End
        Write-Log -messages "Processing - End" -title $title -con $connection -procName $jobTitle -severity "0"
        write-output "end ProcessPartialCube"
    }
    catch 
    {
        write-output $_.Exception.Message
        $message ="Runbook error in ProcessEngagementCube" + $_.Exception.Message
       
        #Log the error
        Write-Log -messages $message -title $title -con $connection -procName $jobTitle -severity "Error"
    }
}

#ProcessCube - to process the cube creation query
function ProcessCube {param($query,[ref]$result)
    try
    {
        write-output "start ProcessCube"

         $resultQ = Invoke-ASCmd -Server $SSASServerName `
            -ServicePrincipal `
            -TenantId $TenantId `
            -ApplicationId $ApplicationId `
            -CertificateThumbprint $CertificateThumbprint  `
            -Query $Query -OutVariable QueryResult; 
         
         $result.Value = ""
        foreach($QResult in $QueryResult)
        {
           $result.Value +=  $QResult
        }   

    
        write-output "end ProcessCube"
    }
    catch
    {
        write-output $_.Exception.Message
    }
}


# Sql Connectivity Code
$SqlConnection  = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Data Source="+$SqlServerName+";initial catalog="+$EngagementDatabaseName+";"
$SqlConnection.AccessToken = $SqlAccessToken

#region - Running the [app].[GetJobIDByProcessName] & get the job id
$IsError=$false
$jobId=-1
$ProcessName = "REBUILDCUBE"
try
{
    write-output "Calling app.GetJobIDByProcessName"
    $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
    $SqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
    $SqlCommand.Connection = $SqlConnection

    $SqlCommand.CommandText = "app.GetJobIDByProcessName"
    $SqlCommand.Parameters.Add("@ProcessName", [System.Data.SqlDbType]::NVarChar, 500) | Out-Null
    $SqlCommand.Parameters["@ProcessName"].Value = $ProcessName

    $SqlCommand.Parameters.Add("@ReturnValue", [System.Data.SqlDbType]::int) | Out-Null
    $SqlCommand.Parameters["@ReturnValue"].Direction = [System.Data.ParameterDirection]"ReturnValue"

    write-output "Openning connection"

    $SqlConnection.Open()
    $SqlCommand.ExecuteNonQuery()
    $SqlConnection.Close()
    write-output "Connection closed"

    $jobId = $SqlCommand.Parameters["@ReturnValue"].Value
    #endregion - Running the [app].[GetJobIDByProcessName] & get the job id
}
catch
{
    write-output $_.Exception.Message

    $SqlConnection.Close()
}
if($jobId -ne -1)
{
    write-output "start cube processing"
    #region - Updating the modified flag in the [app].[ProcessStatus]
    $title="Cube Processing"

    $SqlConnection.AccessToken = $SqlAccessToken
    UpdateIsModifiedFlag -IsModified 1 -ProcessName $ProcessName -connection $SqlConnection
    #endregion - Updating the modified flag in the [app].[ProcessStatus]
    write-output "flag updated"
    try
    {
        write-output "selecting the data"
        #region - Selecting the data from the [app].[Job] based on the Job ID & performing the cube creation task
        $SqlConnection.AccessToken = $SqlAccessToken
        $SqlCommand2 = New-Object System.Data.SqlClient.SqlCommand
        $SqlCommand2.CommandText = "SELECT CubeProcessingMode,CubeProcessingScript,CreatedBy FROM app.Job WHERE	JobID ="+$jobId
        $SqlCommand2.Connection = $SqlConnection

        $SqlConnection.Open()
        $Ds=New-Object system.Data.DataSet 
        $Da=New-Object system.Data.SqlClient.SqlDataAdapter($SqlCommand2) 
        [void]$Da.fill($Ds) 
        $rowCount = $Da.Fill($Ds)
        $SqlConnection.Close()

        if($rowCount -gt 0)
        {
            write-output "data found"
            #Selecting the data in varibles 
            $CubeProcessingMode=$Ds.Tables.CubeProcessingMode
            $CubeProcessingScript=$Ds.Tables.CubeProcessingScript
            $CreatedBy=$Ds.Tables.CreatedBy

            $SqlConnection.AccessToken = $SqlAccessToken

            write-output "Cube processing mode"
            write-output $CubeProcessingMode
            $IsError = $false

            if($CubeProcessingMode -eq 1) #Both 
            {
                $IsErrorInMasterCube  = $false              
				ProcessEngagementCube -jobID $jobId -connection $SqlConnection -result ([ref]$IsError)
                $IsErrorInMasterCube = $IsError
	            ProcessEngagementVersionCube -jobID $jobId -connection $SqlConnection -result ([ref]$IsError)
                if($IsError -eq $false)
                {
                    $IsError = $IsErrorInMasterCube
                }
            }
            elseif($CubeProcessingMode -eq 2) #Engagement
            {
                write-output "running ProcessEngagementCube" 
                ProcessEngagementCube -jobID $jobId -connection $SqlConnection -result ([ref]$IsError)
            }
            elseif($CubeProcessingMode -eq 3) #Version
            {
                 ProcessEngagementVersionCube -jobID $jobId -connection $SqlConnection -result ([ref]$IsError)
            }
            elseif($CubeProcessingMode -eq 4) #Partial
            {
                ProcessPartialCube -jobID $jobId -query "" -connection $SqlConnection  -result ([ref]$IsError)
            }

            $jobStatusID = 1
            if($IsError -eq $true)
            {
                $jobStatusID = 4
            }
            write-output "updating the job"
            #updating the status in the [app].[Job] table
            UpdateJob -JobStatusID $jobStatusID -JobId $jobId -connection $SqlConnection

            UpdateIsJobQueuedFlag -connection $SqlConnection
        }
        #endregion - Selecting the data from the [app].[Job] based on the Job ID & performing the cube creation task
    }
    catch
    {
        write-output "error occured"
        $SqlConnection.Close()
        
        #region - In case of any failure insert the error in [app].[log] table & updating the status of the job
        $message = $_.Exception.Message
        $failedItem = $_.Exception.ItemName

        #updating the status in the [app].[Job] table
        $SqlConnection.AccessToken = $SqlAccessToken
        UpdateJob -JobStatusID 4 -JobId $jobId -connection $SqlConnection

        Write-Log -messages $message -title $title -con $SqlConnection -procName "data.ProcessCubesViaJob" -severity "Error"
        UpdateIsJobQueuedFlag -connection $SqlConnection
        #endregion - In case of any failure insert the error in [app].[log] table & updating the status of the job
    }
    #updating the modified by details
    $SqlConnection.AccessToken = $SqlAccessToken
    UpdateIsModifiedFlag -IsModified 0 -ProcessName $ProcessName -connection $SqlConnection
    write-output "job complete"
}
else
{
    write-output "job not exist"
}
write-output $SqlConnection
   param (
        [Parameter (Mandatory = $false)]
        [object] $WebhookData
   )



if ($WebhookData) {
    "Before conversion"
    $WebhookData
    $WebHookBody = $WebhookData.RequestBody | ConvertFrom-Json 
    "after converion"
    $WebHookBody
    $ResourceGroupName =  $WebHookBody.ResourceGroupName
    $ServerName = $WebHookBody.ServerName.Replace(".database.windows.net","")
    $DatabaseName = $WebHookBody.DatabaseName
    $RetentionTime=$WebHookBody.RetentionTime
    $WeeklyRetention = $WebHookBody.WeeklyRetention
    $MonthlyRetention = $WebHookBody.MonthlyRetention
    $YearlyRetention = $WebHookBody.YearlyRetention
    $WeekOfYear = $WebHookBody.WeekOfYear
	$PiTRDays = $WebHookBody.PiTRDays
}
    Write-Output ("resourceGroupName = " + $ResourceGroupName)
    Write-Output ("sqlServerName = " + $ServerName)
    Write-Output ("databaseName = " + $DatabaseName)
    Write-Output ("weeklyRetention = " + $WeeklyRetention)
    Write-Output (" monthlyRetention = " + $MonthlyRetention) 
    Write-Output ("yearlyRetention = " + $YearlyRetention)
    Write-Output ("weekOfYear = " + $WeekOfYear)

	Start-Sleep -s 300

	
	# Set Long term Retention Policy
    switch($RetentionTime)
    {
      "weekly" {Set-AzureRmSqlDatabaseBackupLongTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName  -WeeklyRetention $WeeklyRetention}
      "monthly" {Set-AzureRmSqlDatabaseBackupLongTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName  -MonthlyRetention $MonthlyRetention }
      "yearly" {Set-AzureRmSqlDatabaseBackupLongTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName  -YearlyRetention $YearlyRetention -WeekOfYear $WeekOfYear}
      "removepolicy" {Set-AzureRmSqlDatabaseBackupLongTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName  -RemovePolicy}
      default {"Invalid retentiontime"}
    }
 
    Write-Output ("resourceGroupName = " + $ResourceGroupName)
    Write-Output ("sqlServerName = " + $ServerName)
    Write-Output ("databaseName = " + $DatabaseName)
    Write-Output ("PiTRDays = " + $PiTRDays)

    # Set Short tem Retention Policy
	#Set-AzSqlDatabaseBackupShortTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName -RetentionDays $PiTRDays
#Get the Hybrid Worker group name
$HybridWorkerGroup = "SQLServerMgmtGroup"
$AutomationAccountName = "codeveuskrtautacc1"

#Preparing input parameters for Runbook B
$params = @{
    "ResourceGroupName" = $ResourceGroupName;
    "ServerName" = $ServerName;
    "DatabaseName" = $DatabaseName;
    "PiTRDays" = $PiTRDays;
	}

$ShortTermPolicyRunbookName = "KRTSetAzSqlDatabaseBackupShortTermRetentionPolicy"
Start-AzureRmAutomationRunbook -ResourceGroupName $ResourceGroupName `
    -AutomationAccountName $AutomationAccountName `
    -Name $ShortTermPolicyRunbookName `
    -Parameters $params `
    -RunOn $HybridWorkerGroup
	
    Write-Output "Create Sql Database Backup Long Term Retention Policy END 1"
 
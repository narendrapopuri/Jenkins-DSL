#Runbook Name: KARTSetFileShareFolderPermissionRubook
#Runbook Type: Powershell
#Runbook Description: This runbook updates sets the folder permission
param(
    [parameter(Mandatory=$false)]
    [Object] $WebhookData
)


    $WebHookBody = $WebhookData.RequestBody | ConvertFrom-Json 
    $StorageAccountName =  $WebHookBody.StorageAccountName
	$KeyVaultName = $WebHookBody.KeyVaultName    
	$FileShareName = $WebHookBody.FileShareName
	$FolderName = $WebHookBody.FolderName
	$ADGroup = $WebHookBody.ADGroup
    $PermissionsList = $WebHookBody.PermissionsList   

    $DSADGroup = $ADGroup.Substring(0, $ADGroup.Length-3) + "-DS"
    $ROADGroup = $ADGroup.Substring(0, $ADGroup.Length-3) + "-RO"

    $ADGroupArray =  @()
    $ADGroupArray += $DSADGroup
    $ADGroupArray += $ROADGroup



		
	 $TotalSleepTime = 900
	 $CheckGroupSleepTime = 60
	 $SleepTimeIterations = $TotalSleepTime/$CheckGroupSleepTime

    	
    connect-azaccount -identity
	$StorageAccessKey = (Get-AzKeyVaultSecret –VaultName $KeyVaultName -Name "StorageAccessKey").SecretValueText
    $StorageAccountFileShareLink = $StorageAccountName+".file.core.windows.net" 
    $FolderDriveFolder = "K:\"+ $FolderName
	$StorageAccountFileShareDriveLink = "\\"+$StorageAccountFileShareLink +"\"+$FileShareName
 

     $connectTestResult = Test-NetConnection -ComputerName $StorageAccountFileShareLink -Port 445
    if ($connectTestResult.TcpTestSucceeded) {
        # Save the password so the drive will persist on reboot
        $cmdCommand = 'cmdkey /add:"'+$StorageAccountFileShareLink+'" /user:"Azure\'+$StorageAccountName+'" /pass:"'+$StorageAccessKey+'"'
        cmd.exe /C $cmdCommand

        'Executed the cmd to map drive.'            
        
        # Mount the drive
        if (Get-PSDrive K -ErrorAction SilentlyContinue) {
         'The K: drive is already in use, so removing the drive'
         Remove-PSDrive K
         $cmdCommand = "net use K: /delete"
         cmd.exe /C $cmdCommand
    }     
     
    $cmdCommand = "net use K: " + $StorageAccountFileShareDriveLink + " /persistent:yes"     
    cmd.exe /C $cmdCommand

    } else {
        Write-Error -Message "Unable to reach the Azure storage account via port 445. Check to make sure your organization or ISP is not blocking port 445, or use Azure P2S VPN, Azure S2S VPN, or Express Route to tunnel SMB traffic over a different port."
    }
    
        try

        {

		   #This removes inheritance from the folder
			$aclRemove = Get-Acl $FolderDriveFolder 
			$aclRemove.SetAccessRuleProtection($true,$true)
			$aclRemove | Set-Acl $FolderDriveFolder

			$aclRemove = Get-Acl $FolderDriveFolder
			$aclRemove.Access | %{$aclRemove.RemoveAccessRule($_)}
			$aclRemove | Set-Acl $FolderDriveFolder
		
			#This sets permissions
            $acl = Get-Acl $FolderDriveFolder  

            foreach($adGroupName in $ADGroupArray)
            {
            "`r`nSetting permissions for "+  $adGroupName
            $readRights=$adGroupName,$PermissionsList,'ContainerInherit,ObjectInherit','None','Allow'
            $AccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule $readRights 
                        
            For ($ctr=1; $ctr -lt $SleepTimeIterations+1; $ctr++)
			{
                try
                {
                    "`r`nChecking if User/AD Group exists - Attempt #"+ $ctr
                    $acl.SetAccessRule($AccessRule)            
                    $acl | Set-Acl $FolderDriveFolder
                   "`r`nPermissions successfully assigned to : "+ $adGroupName + " on folder : "+ $FolderName + " with Permission(s): " + $PermissionsList
                   break;

                }
                catch
                {
                    if($ctr -eq $SleepTimeIterations)
                    {
                        "`r`nGroup still not exist, hence exiting"
                    }
                    else
                    {
                    'Group does not exist, will be retryed after '+ $CheckGroupSleepTime + " secs"
					Start-Sleep -Seconds $CheckGroupSleepTime  
                    }
                }
            }
            }

        }
        catch
       {
             'Error occurred setting the permissions'
            Write-Error -Message $_.Exception.Message
       }
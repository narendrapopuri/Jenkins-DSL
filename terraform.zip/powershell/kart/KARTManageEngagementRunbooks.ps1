#Runbook Name: KARTManageEngagementRunbooks
#Runbook Type: Powershell
#Runbook Description: Parent Runbook that creates the child runbook for each engagement

param(
	
	[parameter(Mandatory=$True)]
    [string] $ResourceGroupName,
	
    [parameter(Mandatory=$True)]
    [string] $AutomationAccountName,

    [parameter(Mandatory=$True)]
    [string] $SqlServerName,
	
	[parameter(Mandatory=$True)]
    [string] $SSASServerName,
	
	[parameter(Mandatory=$True)]
    [string] $SupportFromEmailAddress,
	
	[parameter(Mandatory=$True)]
    [string] $SupportToEmailAddress,

	[parameter(Mandatory=$True)]
    [string] $SMTPServerHostName,

	[parameter(Mandatory=$True)]
    [string] $SMTPServerPort,

	[parameter(Mandatory=$True)]
    [Bool] $SMTPEnableSsl
)
#DEV
# $ResourceGroupName = "co-np-eastus-krt-rg" 
# $AutomationAccountName = "codeveuskrtautacc1"
# $SqlServerName = "codeveuskrtsqlserver1.database.windows.net"
# $SSASServerName = "asazure://eastus.asazure.windows.net/codeveuskrtanasvc1"
# $SupportFromEmailAddress = "kartdevsupport@kpmg.com"
# $SupportToEmailAddress = "syoganantham@kpmg.com"
# $SMTPServerHostName = "smtpoutdmz.us.kworld.kpmg.com"
# $SMTPServerPort = "25"
# $SMTPEnableSsl = $true

#QA
# $ResourceGroupName = "co-np-eastus-krt-rg" 
# $AutomationAccountName = "coqaeuskrtautacc1"
# $SqlServerName = "coqaeuskrtsqlserver1.database.windows.net"
# $SSASServerName = "asazure://eastus.asazure.windows.net/coqaeuskrtanasvc1"

#UAT
# $ResourceGroupName = "co-np-eastus-krt-rg" 
# $AutomationAccountName = "couateuskrtautacc1"
# $SqlServerName = "couateuskrtsqlserver1.database.windows.net"
# $SSASServerName = "asazure://eastus.asazure.windows.net/couateuskrtanasvc1"

#PRD
# $ResourceGroupName = "co-np-eastus-krt-rg" 
# $AutomationAccountName = "coprdeuskrtautacc1"
# $SqlServerName = "coprdeuskrtsqlserver1.database.windows.net"
# $SSASServerName = "asazure://eastus.asazure.windows.net/coprdeuskrtanasvc1"


$ConnectionName = "AzureRunAsConnection"
$IsLoginToAzureSuccessful = $false

$ToEmailAddress = $SupportToEmailAddress
$FromEmailAddress = $SupportFromEmailAddress
$SendEmail = $false
$EmailBody = ""
$KARTSmtpServer = $SMTPServerHostName;
$SMTPPortServer = $SMTPServerPort;


#UpdateIsModifiedFlag - updating the job status
function UpdateIsCubeProcessingRunBookExist {param($falg,$EngagementName,$connection)
    try
    {
        write-output " start UpdateIsCubeProcessingRunBookExist"
        $command = New-Object System.Data.SqlClient.SqlCommand
        $command.CommandText = "UPDATE [app].[Engagement] SET IsCubeProcessingRunBookExist = "+$falg+" WHERE EngagementName='"+$EngagementName+"'"
        $command.Connection = $connection
        $connection.Open()
        $command.ExecuteNonQuery()
        $connection.Close()
        write-output " end UpdateIsCubeProcessingRunBookExist"
    }
    catch
    {
        Write-Error -Message $_.Exception
        $connection.Close()
		$SendEmail = $true;
		$EmailBody += "Error Occured in function UpdateIsCubeProcessingRunBookExist : " + $_.Exception.Message;
    }
}

# Sending Email
 function SendEmail
 {
	  try
	  {
		'Sending Email to: ' + $ToEmailAddress

		$currenDate = (Get-Date -Format "MM/dd/yyyy HH:mm")	

		$Subject = "KARTManageEngagementRunbooks Error Logs"
		$EmailBody   = $EmailBody  -replace "`r`n", "<br/>" 
		$Body =  $EmailBody 
    
		$SMTPServer = $KARTSmtpServer
		$SMTPPort = $SMTPPortServer

		if ($SMTPEnableSsl)
		{
			'SSL Enabled '
			[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { return $true }
			Send-MailMessage -From $FromEmailAddress -to $ToEmailAddress  -Subject $Subject -Body $Body -BodyAsHtml -UseSsl   -SmtpServer $SMTPServer -port $SMTPPort  �DeliveryNotificationOption OnSuccess
		}
		else
		{
			Send-MailMessage -From $FromEmailAddress -to $ToEmailAddress  -Subject $Subject -Body $Body -BodyAsHtml  -SmtpServer $SMTPServer -port $SMTPPort  �DeliveryNotificationOption OnSuccess
		}

		'Email sent'
	  }
	  catch
	  {
		'Email failed'
		 Write-Error -Message $_.Exception.Message    
	  }

 }

try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection = Get-AutomationConnection -Name $ConnectionName 
	connect-azaccount -identity
    "Logging in to Azure..."
	$servicePrincipalConnection
    $IsLoginToAzureSuccessful = $true

    "Logged in to Azure..."
	# Runbook Details  
		$ManageEngagementRunbookJob = Get-AzAutomationJob -ResourceGroupName $ResourceGroupName `
						-AutomationAccountName $AutomationAccountName `
						-Id $PSPrivateMetadata.JobId.Guid -ErrorAction SilentlyContinue
		$ManageEngagementRunbookName = $ManageEngagementRunbookJob.RunbookName 

    
    "After Fetching runbook details..." + $ManageEngagementRunbookName
		

	#Create Variable to Keep the Main Runbook JobId
                    New-AzAutomationVariable `
                    -Name $ManageEngagementRunbookName `
                    -Encrypted $false `
                    -Value "" `
                    -ResourceGroupName $ResourceGroupName� `
                    -AutomationAccountName $AutomationAccountName� `
                    -ErrorAction SilentlyContinue

    "Variable creation "

		#Read MAin runbook JobId
        $MainJobVariable =  Get-AzAutomationVariable `
                -Name $ManageEngagementRunbookName `
                -ResourceGroupName $ResourceGroupName� `
                -AutomationAccountName $AutomationAccountName
                
        $MainRunbookJobID = $MainJobVariable.value

        "Fetched MainRunbookJobID " + $MainRunbookJobID

         $IsMainRunbookRunning = $false
			   if (-not ([string]::IsNullOrEmpty($MainRunbookJobID)))
			   {
					$MainJob = Get-AzAutomationJob -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -Id $MainRunbookJobID
					If($MainJob.status -contains "Running")
					{
						$IsMainRunbookRunning = $true
					}
                    else
                    {
                        "Job not running for the Main Runbook" + $ManageEngagementRunbookName;
                    }
			   }
               else{
                   "Main Runbook job id not exist..."
               }



	If(-not ($IsMainRunbookRunning))
	{
				#Set Current JobId value
			Set-AzAutomationVariable `
							-Name $ManageEngagementRunbookName `
							-Encrypted $false `
							-Value $PSPrivateMetadata.JobId.Guid `
							-ResourceGroupName $ResourceGroupName� `
							-AutomationAccountName $AutomationAccountName



			#InMinutes
			$RestartSleepInterval = 5
			#After every sleep it increaments to 1
			$SleepCounts  = 0

				while($IsLoginToAzureSuccessful)
				{
				   "Started at " + (Get-Date).toString("MM-dd-yyyy HH:mm tt")

					try
					{
						$runBooksPath = "C:\Runbooks"
						$EngagementRunBookTemplate = "EngagementRebuildCubesTemplate"
						If(!(test-path $runBooksPath))
						{
							New-Item -ItemType Directory -Force -Path $runBooksPath
						}

						Export-AzAutomationRunbook `
							-ResourceGroupName $ResourceGroupName `
							-Force `
							-Name $EngagementRunBookTemplate `
							-Slot "Published" `
							-OutputFolder "C:\Runbooks\" `
							-AutomationAccountName $AutomationAccountName

						# Generate Token to connect to Sql
						$response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 
						$content = $response.Content | ConvertFrom-Json
						$AccessToken = $content.access_token  

						# Sql Token has Generated
						# Create Sql Connection to Read the Engagements
						$SqlConnection  = New-Object System.Data.SqlClient.SqlConnection    
						$SqlConnection.ConnectionString = "Data Source="+$SqlServerName+";initial catalog=KART_CENTRAL;"
						$SqlConnection.AccessToken = $AccessToken

						# Create Sql Command
						$SqlCommand = New-Object System.Data.SqlClient.SqlCommand
						$SqlCommand.CommandText = "SELECT EngagementName, DatabaseName, IsJobsEnabled, IsCubeProcessingEnabled, IsCubeProcessingRunBookExist, IsJobQueued FROM app.Engagement WHERE IsActive = 1 AND IsJobsEnabled=1"
						$SqlCommand.Connection = $SqlConnection
 
						# Create Sql Adapter
						$SqlDataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
						$SqlDataAdapter.SelectCommand = $SqlCommand

						# Read Engagement Data
						$Engagements = New-Object System.Data.DataTable
						$SqlDataAdapter.Fill($Engagements)

						# Read Settings
						$SqlConnection.AccessToken = $AccessToken
						$SqlCommand.CommandText = "SELECT VALUE FROM KART_CENTRAL.cnfg.Setting WHERE SettingName = 'IsCubeProcessingEnabled' "
						$IsCubeProcessingEnabledAtCentral = $false
						$Settings = New-Object System.Data.DataTable
						$SqlDataAdapter.Fill($Settings)

						# Get all DB List
						$ServerName = $SqlServerName.Replace(".database.windows.net","")
						$AllDbList = Get-AzSqlDatabase `
									 -ResourceGroupName $ResourceGroupName `
									 -ServerName $ServerName `

						foreach($Setting in  $Settings.Rows)
						{
							$SettingValue = $Setting["VALUE"]
							if(!([string]::IsNullOrEmpty($SettingValue)))
							{         
								if($SettingValue.ToUpper() -eq "TRUE") 
								{                
									$IsCubeProcessingEnabledAtCentral = $true
								}
							}
						}

						# Traverse Engagements
						foreach($Engagement in  $Engagements.Rows)
						{
							$EngagementName =  $Engagement["EngagementName"]
							$DatabaseName =  $Engagement["DatabaseName"]       
							$IsJobsEnabled =  $Engagement["IsJobsEnabled"]
							$IsCubeProcessingEnabled =  $Engagement["IsCubeProcessingEnabled"]
							$IsCubeProcessingRunBookExist = $Engagement["IsCubeProcessingRunBookExist"]  
							$IsJobQueued = $Engagement["IsJobQueued"]  

							"Processing Engagement "+$EngagementName
							$RunBookName = $DatabaseName+"_RebuildCube"   
							
							$IsDatabaseOnline=$true

							if($AllDbList.Count -gt 0)
							{
								for ($i=0; $i -lt $AllDbList.Count; $i++) 
								{
									$dbName=$AllDbList[$i].DatabaseName
									$dbStatus=$AllDbList[$i].Status
									if($DatabaseName -eq $dbName)
									{
										if($dbStatus -eq "Paused")
										{
											$IsDatabaseOnline=$false
											"database is pause " + $AllDbList[$i].DatabaseName
										}
										else
										{
											$IsDatabaseOnline=$true
											"database is online " + $AllDbList[$i].DatabaseName
										}
									}
								}
							}

							$SqlConnection.AccessToken = $AccessToken
							if($IsDatabaseOnline)
							{
								if($IsJobsEnabled -and $IsCubeProcessingEnabled -and $IsCubeProcessingEnabledAtCentral)
								{
									if(!$IsCubeProcessingRunBookExist)
									{
										Write-Output "creating runbook"
										# Create Runbook           
										$TemplateRunbookPath = $runBooksPath + "\" + $EngagementRunBookTemplate + ".ps1"
										Import-AzAutomationRunbook `
											-Path $TemplateRunbookPath  `
											-Name $RunBookName `
											-ResourceGroupName $ResourceGroupName `
											-AutomationAccountName $AutomationAccountName `
											-Type PowerShell `
											-Force

										$RunBookName + " created successfully"        

										#Publish Runbook
										Publish-AzAutomationRunbook `
											-Name $RunBookName `
											-AutomationAccountName $AutomationAccountName `
											-ResourceGroupName $ResourceGroupName                     

										#Create Variable to Keep the JobId
										New-AzAutomationVariable `
										-Name $DatabaseName `
										-Encrypted $false `
										-Value "" `
										-ResourceGroupName $ResourceGroupName� `
										-AutomationAccountName $AutomationAccountName� `
										-ErrorAction SilentlyContinue

										UpdateIsCubeProcessingRunBookExist -falg 1 -EngagementName $EngagementName -connection $SqlConnection
									}

									# $runbookConnection = Get-AutomationConnection -Name $ConnectionName
									# Connect-AzureRmAccount -ServicePrincipal -Tenant $runbookConnection.TenantID `
									# -ApplicationID $runbookConnection.ApplicationID -CertificateThumbprint $runbookConnection.CertificateThumbprint

									# $AzureContext = Select-AzureRmSubscription -SubscriptionId $runbookConnection.SubscriptionID

									$JobVariable =  Get-AzAutomationVariable `
									-Name $DatabaseName `
									-ResourceGroupName $ResourceGroupName� `
									-AutomationAccountName $AutomationAccountName                               

									$CubeJobID = $JobVariable.value
									"Previous job Id of runbook " + $DatabaseName + " is "+ $CubeJobID
									# Check for already running or new runbooks
									#$jobs = Get-AzureRmAutomationJob -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -RunbookName $RunBookName -AzureRmContext $AzureContext
               
									  $IsRunbookRunning = $false
									   if (-not ([string]::IsNullOrEmpty($CubeJobID)))
									   {
											$Jobs = Get-AzAutomationJob -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -Id $CubeJobID
											If($jobs.status -notcontains "Completed" -and $jobs.status -notcontains "Stopped" -and $jobs.status -notcontains "Failed" )
											{
												$IsRunbookRunning = $true
											}

											$Jobs.status

											If($jobs.status -eq "Suspended")
											{
												"Stopping Suspended Job"
												Stop-AzAutomationJob `
													-ResourceGroupName $ResourceGroupName `
													-AutomationAccountName $AutomationAccountName `
													-Id $CubeJobID

												$IsRunbookRunning = $false
											}
									   }
									   else{
										   "Cube job id not exist..."
									   }
			  

									if ($IsRunbookRunning) {
										 "Runbook is already running"+$RunBookName
									}
									elseif(!$IsJobQueued) 
									{
										"job not exist in KART_CENTRAL for the runbook "+$RunBookName
									}
									else
									{
										#Start Runbook            
										$params = @{
											"EngagementDatabaseName"=$DatabaseName;
											"SqlServerName"=$SqlServerName;
											"SqlAccessToken"=$AccessToken;
											"SSASServerName"=$SSASServerName;                   
											"TenantId"=$servicePrincipalConnection.TenantId;
											"ApplicationId"=$servicePrincipalConnection.ApplicationId;
											"CertificateThumbprint"=$servicePrincipalConnection.CertificateThumbprint
											}

										"Starting Runbook "+$RunBookName
										$ChildJob = Start-AzAutomationRunbook   `
													 -RunOn "SQLServerMgmtGroup" `
													 -ResourceGroupName $ResourceGroupName `
													 -AutomationAccountName $AutomationAccountName `
													 -Name $RunBookName  `
													 -Parameters $params    

										Set-AzAutomationVariable `
										-Name $DatabaseName `
										-Encrypted $false `
										-Value $ChildJob.JobId `
										-ResourceGroupName $ResourceGroupName� `
										-AutomationAccountName $AutomationAccountName
									
										"Started Runbook "+$RunBookName
									}
								}
								else 
								{
									if($IsCubeProcessingRunBookExist)
									{
										Write-Output "deleting runbook"
										# Delete Runbook
										Remove-AzAutomationRunbook  `
												-ResourceGroupName $ResourceGroupName `
												-AutomationAccountName $AutomationAccountName  `
												-Name $RunBookName `
												-Force   

										$RunBookName + " removed successfully"

										Remove-AzAutomationVariable `
										-AutomationAccountName $AutomationAccountName `
										-Name $DatabaseName `
										-ResourceGroupName $ResourceGroupName `
										-ErrorAction SilentlyContinue

										UpdateIsCubeProcessingRunBookExist -falg 0 -EngagementName $EngagementName -connection $SqlConnection      
									}
								}    
							}
							else
							{
								"database is in pause state"
							}
						} 
					}
					catch {
						"Error occured"       
						Write-Error -Message $_.Exception
					}

					 "Completed at " + (Get-Date).toString("MM-dd-yyyy HH:mm tt")

					 #Sleep for 60 Seconds
						Start-Sleep -s 60
						$SleepCounts  = $SleepCounts + 1
						if($SleepCounts -eq $RestartSleepInterval)
						{
							"Stoping "
							$IsLoginToAzureSuccessful = $false

						}
				}


				$ManageEngagementRunbookParams = @{
					"ResourceGroupName"=$ResourceGroupName;
					"AutomationAccountName"=$AutomationAccountName;
					"SqlServerName"=$SqlServerName;
					"SSASServerName"=$SSASServerName;
					"SupportFromEmailAddress" = $SupportFromEmailAddress;
					"SupportToEmailAddress" = $SupportToEmailAddress;
					"SMTPServerHostName" = $SMTPServerHostName;
					"SMTPServerPort" = $SMTPServerPort;
					"SMTPEnableSsl" = $SMTPEnableSsl;
					}
                   
				Start-AzAutomationRunbook  `
					-RunOn "SQLServerMgmtGroup" `
					-ResourceGroupName $ResourceGroupName `
					-AutomationAccountName $AutomationAccountName `
					-Name $ManageEngagementRunbookName  `
					-Parameters $ManageEngagementRunbookParams 
	}
	else
	{
	  "Job already running for the Main Runbook with the JobId " + $MainRunbookJobID;
	}
	
 }
catch {
    "Error occured"
     Write-Error -Message $_.Exception
	 $SendEmail = $true;
	 $EmailBody += "Error Occured : " + $_.Exception.Message;
}
finally
{
	 if($SendEmail -eq $True)
	 {
		SendEmail
	 }

	 $EmailBody = "";
	 $SendEmail = $false;
}
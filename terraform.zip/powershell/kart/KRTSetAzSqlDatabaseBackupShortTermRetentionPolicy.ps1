   param (
        [Parameter (Mandatory = $false)] [string] $ResourceGroupName,
        [Parameter (Mandatory = $false)] [string] $ServerName,
        [Parameter (Mandatory = $false)] [string] $DatabaseName,
        [Parameter (Mandatory = $false)] [int] $PiTRDays
   )

    Write-Output ("child resourceGroupName = " + $ResourceGroupName)
    Write-Output ("child sqlServerName = " + $ServerName)
    Write-Output ("child databaseName = " + $DatabaseName)
    Write-Output ("child PiTRDays = " + $PiTRDays)


     # Set Short tem Retention Policy
	Set-AzSqlDatabaseBackupShortTermRetentionPolicy -ResourceGroupName $ResourceGroupName -ServerName $ServerName -DatabaseName $DatabaseName -RetentionDays $PiTRDays
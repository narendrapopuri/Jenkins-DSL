
# Runbook Name: KARTArchiveEngagementRunBooks
# Functionality: Archives KART Engagement Database by putting a '.bacpac' database file in its storage container in Azure
# Called by: EngagementController.ArchiveEngagementInAzure(...) method as well as by KARTArchiveUnUsedNonProdProjects runbook.

param
(
    [Parameter (Mandatory = $false)]
    [object] $WebhookData
)

#Write-Log - To insert the log in the [app].[log] table
function Write-Log {param($messages,$con)
    try
    {
        $cmd = New-Object System.Data.SqlClient.SqlCommand
        $cmd.CommandText = "App.WriteLog"
        $cmd.CommandType = [System.Data.CommandType]::StoredProcedure
        $cmd.Connection = $con 
        $cmd.Parameters.Add("@EventID", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@EventID"].Value = 0
        $cmd.Parameters.Add("@Priority", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@Priority"].Value = 0
        $cmd.Parameters.Add("@Severity", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@Severity"].Value = "Info"
        $cmd.Parameters.Add("@Title", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@Title"].Value = "Archive Project"
        $cmd.Parameters.Add("@Timestamp", [System.Data.SqlDbType]::DateTime) | Out-Null
        $cmd.Parameters["@Timestamp"].Value = [DBNull]::Value
        $cmd.Parameters.Add("@MachineName", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@MachineName"].Value = [System.Net.Dns]::GetHostName()
        $cmd.Parameters.Add("@AppDomainName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@AppDomainName"].Value = ""
        $cmd.Parameters.Add("@ProcessID", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@ProcessID"].Value = "0"
        $cmd.Parameters.Add("@ProcessName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ProcessName"].Value = "KARTArchiveEngagementRunBooks"
        $cmd.Parameters.Add("@ThreadName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ThreadName"].Value = ""
        $cmd.Parameters.Add("@Win32ThreadId", [System.Data.SqlDbType]::NVarChar, 128) | Out-Null
        $cmd.Parameters["@Win32ThreadId"].Value = ""
        $cmd.Parameters.Add("@Message", [System.Data.SqlDbType]::NVarChar, 1500) | Out-Null
        $cmd.Parameters["@Message"].Value = $messages
        $cmd.Parameters.Add("@FormattedMessage", [System.Data.SqlDbType]::NText) | Out-Null
        $cmd.Parameters["@FormattedMessage"].Value = ""
        $cmd.Parameters.Add("@LogId", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@LogId"].Value = 0
        $con.Open()
        $cmd.ExecuteNonQuery()
        $con.Close()
    }
    catch
    {
        $con.Close()
    }
}

function AddRowToAppDotCurrentlyArchivedTable
{
    [Parameter (Mandatory = $True)]
    param ($DBName)

    If ($DBName)
    {
        try
        { 
            $query = "IF NOT EXISTS (SELECT 1 FROM app.CurrentlyArchived WHERE DatabaseName = '" + $DBName + "'" + ") BEGIN INSERT INTO app.CurrentlyArchived (DatabaseName) VALUES ('" + $DBName + "'); END"

            if (!$ServerName.Contains(".database.windows.net"))
            {
                $ServerName = $ServerName + ".database.windows.net"
            }


            "Adding row to [app].[CurrentlyArchived] table..."
            $AccessToken
            $ServerName
            $SqlCon  = New-Object System.Data.SqlClient.SqlConnection
            $SqlCon.ConnectionString = "Data Source = " + $ServerName + "; initial catalog = KART_CENTRAL;"
            $SqlCon.AccessToken = $AccessToken

            $SqlCom = New-Object System.Data.SqlClient.SqlCommand
            $SqlCom.Connection = $SqlCon
            $SqlCom.CommandText = $query
            $SqlCon.Open()
            $SqlCom.ExecuteNonQuery()
            $SqlCon.Close()
        }
        catch
        {
            Write-Error -Message $_.Exception
        }
	}
}

function RemoveEncryptAndDecryptFunctions{param($DBName)
    try
    { 
        $query = "IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[scrty].[UDFS_Decrypt]')AND xtype IN (N'IF', N'FN', N'TF'))BEGIN DROP FUNCTION [scrty].[UDFS_Decrypt];END;"
        $query += " IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'[scrty].[UDFS_Encrypt]')AND xtype IN (N'IF', N'FN', N'TF'))BEGIN DROP FUNCTION [scrty].[UDFS_Encrypt] END"

        if (!$ServerName.Contains(".database.windows.net"))
        {
            $ServerName = $ServerName + ".database.windows.net"
        }

        "Removing Encrypt & Decrypt functions..."
        $SqlConnections  = New-Object System.Data.SqlClient.SqlConnection
        $SqlConnections.ConnectionString = "Data Source = " + $ServerName + "; initial catalog = " + $DBName + ";"
        $SqlConnections.AccessToken = $AccessToken

        $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $SqlCommand.Connection = $SqlConnections
        $SqlCommand.CommandText = $query
        $SqlConnections.Open()
        $SqlCommand.ExecuteNonQuery()
        $SqlConnections.Close()     
        "Removed Encrypt & Decrypt functions."
    }
    catch
    {
        Write-Error -Message $_.Exception
    }
}

function ArchiveDB {param($DB,$connection)
    try
    {   
        $SqlPackageExePath = "C:\Program Files\Microsoft SQL Server\150\DAC\bin\"
        $BackUpDrivePath = "C:\KART"
        "Processing Database " + $DB 
        $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $SqlCommand.Connection = $SqlConnection
        $SqlCommand.CommandText = "DECLARE @IsExist BIT = 0 IF EXISTS (SELECT 1 FROM sys.sysdatabases WHERE NAME = '" + $DB + "') BEGIN SET @IsExist = 1 END SELECT @IsExist"

        $SqlConnection.Open()
        $IsDBExist =  $SqlCommand.ExecuteScalar()
        $SqlConnection.Close()  
        If ($IsDBExist -eq $true)
        {    
            "DB exists"
            $message = "Found DB: " + $DB
            Write-Log -messages $message -con $connection


            $BlobName = $DB + (Get-Date).ToString("yyyyMMddHHmm") + ".bacpac"
            # $storageuri = $ArchiveStorageAccountURI + "/" + $ContainerName + "/" + $bacpacFilename

            If ($DB -notlike "*_STAGING_")
            {
                $message = "Calling 'RemoveEncryptAndDecryptFunctions' for " + $DB + ", $ ServerName: " + $ServerName
				Write-Log -messages $message -con $connection

                RemoveEncryptAndDecryptFunctions -DBName $DB

                $message="Removed Encrypt & Decrypt functions, if exist from DB: " + $DB
                Write-Log -messages $message -con $connection
            }

            if (!(Test-Path -Path $BackUpDrivePath ))
			{
                New-Item -ItemType directory -Path $BackUpDrivePath
                "KART folder created"
            }
            else
			{
                "KART folder already exist"
            }

            Write-Log -messages "KART folder created" -con $connection

            $BackupFileName = $BackUpDrivePath + "\" + $DB + ".bacpac"
            If (test-path $BackupFileName)
            {
                Remove-Item –path $BackupFileName
            }          

            $message="Started taking backup for DB: " + $DB + " from Server: " + $ServerName
            Write-Log -messages $message -con $connection

            "Started taking backup from Server " + $ServerName

            $SqlPackageExe = $SqlPackageExePath + "SqlPackage.exe"
            & $SqlPackageExe /Action:Export /ssn:tcp:$ServerName /sdn:$DB /su:$SqlUsername /sp:$SqlPassword /tf:$BackupFileName /p:Storage=File

            "Completed Sql Package"

	        $IsComplete = $false
	        $Counter = 1

            while ($true)
            {
                "Inside loop"
                If ($Counter -eq 10)
                {
                    break
                }

                If ((test-path $BackupFileName))
                {
                    $IsComplete = $true
                    break
                }
                else
                {
                    Start-Sleep -s 30
                }
				$Counter += $Counter
            }
                
            "Completed taking backup from Server " + $ServerName

            $message = "Backup completed for DB: " + $DB
            Write-Log -messages $message -con $connection    
      
            Set-AzStorageBlobContent `
            -Context $StorageAccountContext `
            -Container $ContainerName `
            -File $BackupFileName `
            -Blob $BlobName 

            If ($IsComplete)
            {
                $IsComplete = $false
                $Counter = 1

                while ($true)
                {
                    If ($Counter -eq 10)
                    {
                        break
                    }
                    $blob = Get-AzStorageBlob -Blob $bacpacFilename -Container $ContainerName -Context $StorageAccountContext -ErrorAction Ignore
                    if ($blob)
                    {
                        "Found blob"
                        $IsComplete=$true
                        break                   
                    }
                    else 
                    {
                        $Counter=$Counter+1
                        Start-Sleep -s 60
                        "Blob not exits"
                    }
                }
            }
			 
            #"Exporting of Database " + $DB + " Completed"
			If ($IsComplete)
			{
                Get-ChildItem -Path $BackUpDrivePath –File 

                If (test-path $BackupFileName)
                {
                    "Removed backup file"
                    Remove-Item –path $BackupFileName
                    Write-Log -messages "Removed backup file" -con $connection   
                }

                Get-ChildItem -Path $BackUpDrivePath –File 
               
				$SqlCommand.CommandText = "DROP DATABASE [" + $DB + "]"
				$SqlConnection.Open()
				$SqlCommand.ExecuteNonQuery()
				$SqlConnection.Close()
				"Deleting of Database " +$DB + " Completed"

                $message = "Deleting of Database " + $DB + " Completed"
                Write-Log -messages $message -con $connection
                
                $message = "Before AddRowToAppDotCurrentlyArchivedTable " + $DB
                Write-Log -messages $message -con $connection

                AddRowToAppDotCurrentlyArchivedTable -DBName $DB
                
                $message = "After AddRowToAppDotCurrentlyArchivedTable " + $DB
                Write-Log -messages $message -con $connection
			}
           
        }
        Else 
        {
            "Database " + $DB + " does not exist"
            $message = "Database " + $DB + " does not exist"
            Write-Log -messages $message -con $connection
        }
    }
    catch
    {
        Write-Error -Message $_.Exception
    }
}


try
{
    $ArchiveStorageAccountName = ""
    $SqlUsername = ""
    $SqlPassword = ""
    $StorageKeytype = "StorageAccessKey"
    $ResourceGroupName = "" 
    $ServerName = ""
	$EngagementName = ""
    $DatabaseName = ""
	$StagingDatabaseName = ""
    $KeyVaultName = ""
	$ContainerName = ""

    if ($WebhookData) {
        $WebHookBody = $WebhookData.RequestBody | ConvertFrom-Json 
        $ResourceGroupName =  $WebHookBody.ResourceGroupName
        $ServerName = $WebHookBody.ServerName
		$EngagementName = $WebHookBody.EngagementName
        $DatabaseName = $WebHookBody.DatabaseName
		$StagingDatabaseName = $WebHookBody.StagingDatabaseName
		$KeyVaultName = $WebHookBody.KeyVaultName    
		$ContainerName = $WebHookBody.ContainerName
    }

    "ResourceGroupName: " + $ResourceGroupName 
    "ServerName: " + $ServerName 
    "EngagementName: " + $EngagementName 
    "DatabaseName: " + $DatabaseName 
    "StagingDatabaseName: " + $StagingDatabaseName 
    "KeyVaultName: " + $KeyVaultName 
    "ContainerName: " + $ContainerName

    connect-azaccount -identity

    $ArchiveStorageAccountName = (Get-AzKeyVaultSecret –VaultName $KeyVaultName -Name "SAArchiveContainer").SecretValueText
    $ArchiveStorageAccountName
    $ArchiveStorageAccountURI = "https://"+$ArchiveStorageAccountName+".blob.core.windows.net"
    $ContainerName = $ContainerName;

    $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 
    $content = $response.Content | ConvertFrom-Json
    $AccessToken = $content.access_token  

    if ($ServerName -NotContains ".database.windows.net")
    {
        $ServerName = $ServerName + ".database.windows.net"
    }

    # Connection to SQL
    $SqlConnection  = New-Object System.Data.SqlClient.SqlConnection
    $SqlConnection.ConnectionString = "Data Source = " + $ServerName + "; initial catalog = master;"
    $SqlConnection.AccessToken = $AccessToken

    # Connection to KART central db
    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = "Data Source = " + $ServerName + "; initial catalog = KART_CENTRAL;"
    $connection.AccessToken = $AccessToken

    $SqlUsername = (Get-AzKeyVaultSecret –VaultName $KeyVaultName -Name "DBUserName").SecretValueText
    $SqlPassword = (Get-AzKeyVaultSecret –VaultName $KeyVaultName -Name "DBPassword").SecretValueText

    Write-Log -messages "Read DB credentials from key vault" -con $connection  

    $StorageAccountKey =  (Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -AccountName $ArchiveStorageAccountName).Value[0]
    $StorageAccountContext = New-AzStorageContext -StorageAccountName $ArchiveStorageAccountName -StorageAccountKey $StorageAccountKey

    if(Get-AzStorageContainer -Name $ContainerName -Context $StorageAccountContext -ErrorAction SilentlyContinue) 
    {
        "Container already exists"
         Write-Log -messages "Container already exists" -con $connection
    }
    else 
    {  
        $Container = New-AzStorageContainer -Name $ContainerName -Permission Off -Context $StorageAccountContext  
        "Container Created Successfully"
        Write-Log -messages "Container Created Successfully" -con $connection
    }   

    if(Get-AzStorageContainer -Name $ContainerName -Context $StorageAccountContext -ErrorAction SilentlyContinue) 
    {
        "Archiving Database: " + $DatabaseName + "..."
        ArchiveDB  -DB $DatabaseName -connection $connection
        ArchiveDB  -DB $StagingDatabaseName -connection $connection
    }   
}
catch
{
    Write-Error -Message $_.Exception
}


# Runbook Name: KARTArchiveUnUsedNonProdProjects-QA
# Functionality: For every KART Engagement Database not accessed in the last two weeks, calls the KARTArchiveEngagementRunBooks runbook, 
# followed by updating the app.Engagement table.
# Called by: Once daily schedule.

param
(
	[parameter(Mandatory=$False)]
    [string] $ResourceGroupName = "",

    [parameter(Mandatory=$False)]
    [string] $SqlServerName = "",

    [parameter(Mandatory=$False)]
    [string] $KeyVaultName = "",

    [parameter(Mandatory=$False)]
    [string] $ArchiveEngagementWebhookUrl = ""

)

#Write-Log - To insert the log in the [app].[log] table
function Write-Log {param($messages, $con)
    try
    {
        $cmd = New-Object System.Data.SqlClient.SqlCommand
        $cmd.CommandText = "App.WriteLog"
        $cmd.CommandType = [System.Data.CommandType]::StoredProcedure
        $cmd.Connection = $con 
        $cmd.Parameters.Add("@EventID", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@EventID"].Value = 0
        $cmd.Parameters.Add("@Priority", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@Priority"].Value = 0
        $cmd.Parameters.Add("@Severity", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@Severity"].Value = "Info"
        $cmd.Parameters.Add("@Title", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@Title"].Value = "Archive Un-Used Non-Prod Projects"
        $cmd.Parameters.Add("@Timestamp", [System.Data.SqlDbType]::DateTime) | Out-Null
        $cmd.Parameters["@Timestamp"].Value = [DBNull]::Value
        $cmd.Parameters.Add("@MachineName", [System.Data.SqlDbType]::NVarChar, 50) | Out-Null
        $cmd.Parameters["@MachineName"].Value = [System.Net.Dns]::GetHostName()
        $cmd.Parameters.Add("@AppDomainName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@AppDomainName"].Value = ""
        $cmd.Parameters.Add("@ProcessID", [System.Data.SqlDbType]::NVarChar, 256) | Out-Null
        $cmd.Parameters["@ProcessID"].Value = "0"
        $cmd.Parameters.Add("@ProcessName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ProcessName"].Value = "KARTArchiveUnUsedNonProdProjects-QA"
        $cmd.Parameters.Add("@ThreadName", [System.Data.SqlDbType]::NVarChar, 512) | Out-Null
        $cmd.Parameters["@ThreadName"].Value = ""
        $cmd.Parameters.Add("@Win32ThreadId", [System.Data.SqlDbType]::NVarChar, 128) | Out-Null
        $cmd.Parameters["@Win32ThreadId"].Value = ""
        $cmd.Parameters.Add("@Message", [System.Data.SqlDbType]::NVarChar, 1500) | Out-Null
        $cmd.Parameters["@Message"].Value = $messages
        $cmd.Parameters.Add("@FormattedMessage", [System.Data.SqlDbType]::NText) | Out-Null
        $cmd.Parameters["@FormattedMessage"].Value = ""
        $cmd.Parameters.Add("@LogId", [System.Data.SqlDbType]::int) | Out-Null
        $cmd.Parameters["@LogId"].Value = 0
        $con.Open()
        $cmd.ExecuteNonQuery()
        $con.Close()
    }
    catch
    {
        $con.Close()
        Write-Error -Message $_.Exception
    }
}

function UpdateEngagementTableAfterArchival
{
    param ($DBName)

    try
    { 
        $query = "UPDATE app.Engagement SET IsArchived = 1, ArchiveDate = GETDATE(), IsActive = 0 WHERE DatabaseName = '" + $DBName + "'"

        "Updating app.Engagement table..."
        $SqlConnections  = New-Object System.Data.SqlClient.SqlConnection
		$SqlConnections.ConnectionString = "Data Source = " + $SqlServerName + "; initial catalog = KART_CENTRAL;"
        $SqlConnections.AccessToken = $AccessToken

        $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $SqlCommand.Connection = $SqlConnections
        $SqlCommand.CommandText = $query
        $SqlConnections.Open()
        $SqlCommand.ExecuteNonQuery()
        $SqlConnections.Close()
    }
    catch
    {
        Write-Error -Message $_.Exception
    }
}

try 
{
    $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 
    $content = $response.Content | ConvertFrom-Json
    $AccessToken = $content.access_token
    #"AccessToken: " + $AccessToken

    $SqlConnection  = New-Object System.Data.SqlClient.SqlConnection
    $SqlConnection.ConnectionString = "Data Source = " + $SqlServerName + "; initial catalog = KART_CENTRAL;"
	#"Print1 " + $SqlConnection.ConnectionString
    #"Connection string: " + $SqlConnection.ConnectionString
    $SqlConnection.AccessToken = $AccessToken

    $SqlCommand = New-Object System.Data.SqlClient.SqlCommand
    $SqlCommand.CommandText = "SELECT EngagementName, DatabaseName, StagingDatabaseName, ContainerName FROM app.Engagement WHERE DatabaseName != 'KART_MASTER' AND DatabaseName NOT IN (SELECT DatabaseName FROM app.DoNotArchive) AND (IsArchived != 1 OR IsArchived IS NULL) AND LastAccessDate < (GETDATE() - 15) ORDER BY LastAccessDate DESC"
	#"Print2 " + $SqlCommand.CommandText
    $SqlCommand.Connection = $SqlConnection

    # Create Sql Adapter
    $SqlDataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
    $SqlDataAdapter.SelectCommand = $SqlCommand

    # Read Engagement Data
    $DT_Engagement = New-Object System.Data.DataTable
    $SqlDataAdapter.Fill($DT_Engagement)
    "Print Count: " + $DT_Engagement.Rows.Count

    if ($DT_Engagement.Rows.Count -eq 0) {
        "No databases to archive. Quitting..."
        exit(1)
    }
    else {

        $dt = Get-Date -Format "dd/MM/yyyy HH:mm:ss"
        $dt += ": Number of Engagement Databases to Archive today: " + $DT_Engagement.Rows.Count
        $message = $dt
        Write-Log -messages $message -con $SqlConnection

        foreach ($Engagement in $DT_Engagement.Rows)
        {
            $EngagementName =  $Engagement["EngagementName"]
            $DatabaseName =  $Engagement["DatabaseName"]
            $StagingDatabaseName =  $Engagement["StagingDatabaseName"]
            $ContainerName =  $Engagement["ContainerName"]

            $params = New-Object 'System.Collections.Generic.Dictionary[string, string]'
            $params.ResourceGroupName = $ResourceGroupName
            $params.ServerName = $SqlServerName
            $params.EngagementName = $EngagementName
            $params.DatabaseName = $DatabaseName
            $params.StagingDatabaseName = $StagingDatabaseName
            $params.KeyVaultName = $KeyVaultName
            $params.ContainerName = $ContainerName
            $RunBookName = 'KARTArchiveEngagementRunBooks'

            "Archiving Database: " + $DatabaseName
            "Calling 'KARTArchiveEngagementRunBooks' for $DatabaseName..."
            # Below line is not working, but kept for reference
            #$job = Start-AzureRmAutomationRunbook -AutomationAccountName 'coprdeuskrtautacc1' -ResourceGroupName $params.ResourceGroupName -Name $RunBookName -Parameters $params -RunOn "SQLServerMgmtGroup"

            # $RequestParams = @{"ResourceGroupName"=$params.ResourceGroupName}
            # $Requestbody = ConvertTo-Json -InputObject $RequestParams
            # DEV Environment value for $ArchiveEngagementWebhookUrl = "https://s16events.azure-automation.net/webhooks?token=gQQ5OYGEOCQR58fPA4vldYic5PeQbpmfqIWbg0K6Z%2bU%3d"

            #$ArchiveEngagementWebhookUrl = "https://s16events.azure-automation.net/webhooks?token=gQQ5OYGEOCQR58fPA4vldYic5PeQbpmfqIWbg0K6Z%2bU%3d"
            $Requestbody = ConvertTo-Json -InputObject $params
			#"Print Request body: " + $Requestbody
            Invoke-WebRequest -Method Post -Uri $ArchiveEngagementWebhookUrl  -Body $Requestbody -UseBasicParsing

            "Updating app.Engagement table, setting IsArchived = 1, IsActive = 0 for " + $DatabaseName
            UpdateEngagementTableAfterArchival -DBName $DatabaseName
        }
    }
    $SqlCommand.Connection.Close()
}
catch
{
    Write-Error -Message $_.Exception
}

# Runbook Name: KARTPeriodicCleanUpDEVandQASQLDatabases
# Functionality: DROP databases from KART_Central not accessed in last two weeks, DELETE records from tables that reference those DB's
# followed by updating the app.Engagement table.
# Called by: Schedule to run every other Friday post-Sprint 

param
(

    [parameter(Mandatory=$False)]
    [string] $SqlServerName = "srv-use-krt-dv.database.windows.net",

    [parameter(Mandatory=$False)]
    [string] $ResourceGroupName = "RGP-USE-KRT-DV",

    [parameter(Mandatory=$False)]
    [string] $KeyVaultName = "kvl-use-krt-dv",

    [parameter(Mandatory=$False)]
    [string] $AutomationAccountName = "ama-use-krt-dv"


)

#main 
try 
{

    connect-azaccount -identity
    $response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fdatabase.windows.net%2F' -Method GET -Headers @{Metadata="true"} -UseBasicParsing 

    $content = $response.Content | ConvertFrom-Json
    $AccessToken = $content.access_token 

    $SqlConnection1  = New-Object System.Data.SqlClient.SqlConnection
    $SqlConnection1.AccessToken = $AccessToken
    $SqlConnection1.ConnectionString = "Data Source=$SqlServerName;initial catalog=KART_CENTRAL; "
    $SqlConnection1.Open()

    #exec SP
    Get-Date
    "EXEC SQL SP..."
    $MasterDatabaseCommand = New-Object System.Data.SqlClient.SqlCommand
    $MasterDatabaseCommand.Connection = $SqlConnection1
    $MasterDatabaseCommand.CommandText = "dbo.MaintenanceProc_DropDevAndQADatabases_RB_EXEC"
    $MasterDatabaseCommand.CommandTimeout = 60*20 #20 minutes
    $MasterDatabaseCommand.ExecuteNonQuery()
    "EXEC SP Complete."
    Get-Date

    $SqlConnection1.Close()

    #Below child RB call is failing to PARSE, so calling from secondalry linked schedule for the time being
    #"Call child RB to Delete Cubes..."
    #Get-Date

    #method 1: inline
    #.\KARTDeleteEngagementCubes.ps1

    #"Child RB call complete."
    #Get-Date

}
catch
{
    Write-Error -Message $_.Exception
}
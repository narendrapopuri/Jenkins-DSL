Param(
    [Parameter(Mandatory=$true,
               HelpMessage = "The acronym of the project.")]
    [string]$ApplicationAcronym,
    [Parameter(Mandatory=$true,
               HelpMessage = "Personal access token.")]
    [string]$Token
)



$token = $Token
$basicAuthPair = "$($token):$($token)"
$bytes = [System.Text.Encoding]::Ascii.GetBytes($basicAuthPair)
$base64Token = [Convert]::ToBase64String($bytes)

$headers = @{}
$headers.Add("Authorization", "Basic $base64Token")

#For groups scoped to a Project {ex. KPMGAdvisoryCloud}, using a scope descriptor
$uri = "https://vssps.dev.azure.com/CO-AzureCore/_apis/graph/groups?scopeDescriptor=scp.ZmY1OGQ3ZTMtODFjMC00Y2YxLTg5YzMtYWYwNjAzMjQ0Yzg1&api-version=5.2-preview.1"

$groupTypes = @(
    "NonProd-PipelineAdmins=Can operate, modify, create, delete, modify approvers, and grant/modify permissions to pipelines that impact the Non-Prod environment"
    "Prod-PipelineAdmins=Can operate, modify, create, delete, modify approvers, and grant/modify permissions to pipelines that impact the Production environment"
    "NonProd-PipelineContributors=Can operate, modify, create, and delete pipelines that impact the Non-Prod environment"
    "Prod-PipelineContributors=Can operate, modify, create, and delete pipelines that impact the Production environment"
    "NonProd-PipelineOperators=Can operate pipelines that impact the Non-Prod environment"
    "Prod-PipelineOperators=Can operate pipelines that impact the Production environment"
    "DeploymentApprovers=Can approve releases into the Azure Production tenant"
    "ServiceConnectionAdmins=Can modify the Azure Cloud service connections for this project"
    "ServiceConnectionUsers=Can operate pipelines that use the Azure Cloud service connections for this project"
)


function Get-Groups
{
    Param(
        [cmdletbinding()]
        [string]$Token,
        [string]$GroupPrincipalName
    )
    
    $basicAuthPair = "$($token):$($token)"
    $bytes = [System.Text.Encoding]::Ascii.GetBytes($basicAuthPair)
    $base64Token = [Convert]::ToBase64String($bytes)
    
    $headers = @{}
    $headers.Add("Authorization", "Basic $base64Token")
    
    $baseUri = "https://vssps.dev.azure.com/CO-AzureCore/_apis/graph/groups?api-version=5.2-preview.1"

    try 
    {
        $response = $null
        $uri = $baseUri
        [System.Collections.ArrayList]$returnGroups=@()
        
        Do 
        {
            $response = Invoke-WebRequest -Method GET -Uri $uri -Header $headers -ContentType "application/json" -UseBasicParsing
            $returnGroups.AddRange(($response.Content | ConvertFrom-Json).value)
            $uri=$baseUri + "&continuationToken=" + $response.Headers.'X-MS-ContinuationToken'
        } 
        While($response.Headers.'X-MS-ContinuationToken' -ne $null)

        if($GroupPrincipalName -eq $null)
        {
            return $returnGroups
        }
        else
        {
            $x = $returnGroups | Where-Object { $_.principalName -eq $groupPrincipalName }
            return $x
        }   
    }
    catch
    {
        Write-Host $_
    }
    finally
    {
    }
}

function Add-GroupMember
{
    Param(
        [cmdletbinding()]
        [string]$Token,
        [string]$ParentDescriptor,
        [string]$MemberDescriptor
    )
    $basicAuthPair = "$($token):$($token)"
    $bytes = [System.Text.Encoding]::Ascii.GetBytes($basicAuthPair)
    $base64Token = [Convert]::ToBase64String($bytes)
    
    $headers = @{}
    $headers.Add("Authorization", "Basic $base64Token")

    $uri = "https://vssps.dev.azure.com/CO-AzureCore/_apis/graph/memberships/{0}/{1}?api-version=5.1-preview.1" -f $MemberDescriptor, $ParentDescriptor
    
    try 
    {
        $response = Invoke-WebRequest -Method PUT -Uri $uri -Header $headers -ContentType "application/json" -UseBasicParsing
        if($response.StatusCode -eq 200)
        {
            return $response.Content
        }
        else
        {
            return $null
        }
    }
    catch
    {
        Write-Host $_
    }
    finally
    {
        
    }
}


foreach($groupType in $groupTypes)
{
    $request = @{}
    $groupName = $groupType.Split('=')[0]
    $groupDescription = $groupType.Split('=')[1]
    $text = "CommercialCloud-{0}-{1}" -f $ApplicationAcronym, $groupName 
    $request.Add("displayName", $text)
    $request.Add("description", $groupType.Split('=')[1])
        
    $json = $request | ConvertTo-Json
    try 
    {
        #get all groups    $response = Invoke-RestMethod -Method GET -Body $request -Uri $uri -Header $headers -ContentType "application/json"
        $response = Invoke-RestMethod -Method POST -Body $json -Uri $uri -Header $headers -ContentType "application/json" -UseBasicParsing
        $parentGroup = $response.descriptor

        #The top level groups are not environment specific so remove the environment from the name
        $topLevelGroupName = "CommercialCloud-$groupName".Replace("NonProd-", "").Replace("Prod-", "")
        $groupToAdd = Get-Groups -Token $token -GroupPrincipalName "[KPMGAdvisoryCloud]\$topLevelGroupName"
        if($groupToAdd -eq $null)
        {
            throw;
        }
        Add-GroupMember -Token $token -ParentDescriptor $parentGroup -MemberDescriptor $groupToAdd.descriptor
    
    }
    catch
    {
        Write-Host $_
    }
    finally
    {
    }
}
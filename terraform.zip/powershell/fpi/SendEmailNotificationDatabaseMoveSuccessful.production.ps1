Connect-AzureRmAccount -MSI

$Sender = 'FPI Production GREEN: Master Database Moved SUCCESSFUL Notification <noreply@kpmg.com>'
$Recepients = 'Zoran Galovic <zgalovic@kpmg.com>', 'Sakthi Pichaimani <spichaimani@kpmg.com>', 'Dmitriy Modlin <dmodlin@kpmg.com>', 'Pavan Gudiyella <pgudiyella@kpmg.com>', 'Hurn, Scott <shurn@kpmg.com>', 'Koenigsknecht, Brandon <bkoenigsknecht@KPMG.com>', 'Nguyen, Jessica F <jessicanguyen@Kpmg.Com>', 'GO-FM ManagedServices <go-fmmanagedservices@kpmg.com>'
#$Recepients = 'Galovic, Zoran <zgalovic@kpmg.com>'
$Subject = "FPI Production GREEN: Master Database Moved SUCCESSFUL notification"
$Body1 = "FPI Production GREEN: Master Database Moved SUCCESSFUL"
$Body2 = "`r`n`r`nFPI Elastic pools (Production):`r`n"
$Body3 = "https://portal.azure.com/#@kpmgusadvcloudops.onmicrosoft.com/resource/subscriptions/9e27f52c-3c97-4fda-9c8f-eadcd0ad195a/resourceGroups/co-p-spi-fpi-rg/providers/Microsoft.Sql/servers/co-p-fpi-kpmg-sql/elasticPoolsList"
$SmtpServer = '199.207.144.9'

$Body = $Body1 + $Body2 + $Body3
Send-MailMessage -From $Sender -To $Recepients -Subject $Subject -Body $Body -SmtpServer $SmtpServer

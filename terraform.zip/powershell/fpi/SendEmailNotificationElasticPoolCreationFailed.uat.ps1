Connect-AzureRmAccount -MSI

$Sender = 'FPI UAT YELLOW: New Elastic Pool FAILED Notification <noreply@kpmg.com>'
$Recepients = 'Zoran Galovic <zgalovic@kpmg.com>', 'Sakthi Pichaimani <spichaimani@kpmg.com>', 'Dmitriy Modlin <dmodlin@kpmg.com>', 'Pavan Gudiyella <pgudiyella@kpmg.com>', 'Hurn, Scott <shurn@kpmg.com>', 'Koenigsknecht, Brandon <bkoenigsknecht@KPMG.com>', 'Nguyen, Jessica F <jessicanguyen@Kpmg.Com>', 'KPMG NP Support <go-fmmanagedservice1@kpmg.com>'
#$Recepients = 'Galovic, Zoran <zgalovic@kpmg.com>'
$Subject = "FPI UAT YELLOW: New Elastic Pool creation attempted but FAILED notification"
$Body1 = "FPI UAT YELLOW: New elastic Pool creation attempted but FAILED"
$Body2 = "`r`n`r`nFPI Elastic pools (UAT):`r`n"
$Body3 = "https://portal.azure.com/#@kpmgusadvcloudops.onmicrosoft.com/resource/subscriptions/b75fc3c3-04a4-45a6-b126-8279f505e873/resourceGroups/RGP-USE-KIP-UAT/providers/Microsoft.Sql/servers/srv-use-fpi-uat/elasticPoolsList"
$SmtpServer = '199.207.144.9'

$Body = $Body1 + $Body2 + $Body3
Send-MailMessage -From $Sender -To $Recepients -Subject $Subject -Body $Body -SmtpServer $SmtpServer

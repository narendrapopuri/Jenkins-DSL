﻿AAResourceGroupName: co-p-spi-fpi-rg
SubscriptionID: 9e27f52c-3c97-4fda-9c8f-eadcd0ad195a
AutomationAccountName: Spi-fpi-aa
HybridGroupName: FPIElasticPool

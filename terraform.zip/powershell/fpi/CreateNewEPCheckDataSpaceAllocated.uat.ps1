$connectionName = "AzureRunAsConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}
$TARGET_RESOURCE_GROUP = "RGP-USE-FPI-UAT"
$AUTOMATION_ACCOUNT_NAME = "ama-use-fpi-auto-uat"
#$TARGET_SQL_SERVER = "co-nps-fpi-kpmg-sql"
#$TARGET_ELASTIC_POOL = "fpi-sql-pool"

$DatabaseAlertON = $False
$DataSpaceAllocatedAlertON = $False

$TARGET_SQL_SERVER = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_TARGET_SQL_SERVER -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("TARGET_SQL_SERVER: ", $TARGET_SQL_SERVER.value)
$TARGET_CURRENT_ELASTIC_POOL = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_TARGET_CURRENT_ELASTIC_POOL -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("TARGET_CURRENT_ELASTIC_POOL: ", $TARGET_CURRENT_ELASTIC_POOL.value)
$MAX_DATABASE_NUMBER = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_MAX_DATABASE_NUMBER -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("MAX_DATABASE_NUMBER: ", $MAX_DATABASE_NUMBER.value)
$DATABASE_NAME = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_DATABASE_NAME -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("DATABASE_NAME: ", $DATABASE_NAME.value)

$NO_VCORE = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_VCORE -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("NO_VCORE: ", $NO_VCORE.value)
$STORAGE_MB = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_STORAGE_MB -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("STORAGE_MB: ", $STORAGE_MB.value)
$CURRENT_NO_OF_ELASTIC_POOLS = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_NO_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("CURRENT_NO_OF_ELASTIC_POOLS: ", $CURRENT_NO_OF_ELASTIC_POOLS.value)
$CURRENT_TOTAL_OF_ELASTIC_POOLS = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_TOTAL_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("CURRENT_TOTAL_OF_ELASTIC_POOLS: ", $CURRENT_TOTAL_OF_ELASTIC_POOLS.value)
$DB_VCORE = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_DB_VCORE -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("DB_VCORE: ", $DB_VCORE.value)
$DbVcoreDouble = [double]$DB_VCORE.value
Write-Output ("DbVcoreDouble: ", $DbVcoreDouble)

$STORAGE_MAX_LIMIT = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_STORAGE_MAX_LIMIT -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("STORAGE_MAX_LIMIT: ", $STORAGE_MAX_LIMIT.value)

$RETRIES_DB_CURRENT = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_DB_CURRENT -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("RETRIES_DB_CURRENT: ", $RETRIES_DB_CURRENT.value)
$RETRIES_DB_MAX = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_DB_MAX -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("RETRIES_DB_MAX: ", $RETRIES_DB_MAX.value)
$RETRIES_POOL_CURRENT = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_POOL_CURRENT -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("RETRIES_POOL_CURRENT: ", $RETRIES_POOL_CURRENT.value)
$RETRIES_POOL_MAX = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_POOL_MAX -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("RETRIES_POOL_MAX: ", $RETRIES_POOL_MAX.value)


if( $CURRENT_NO_OF_ELASTIC_POOLS.value -EQ 1 )
{
    $MyElasticPoolName = $TARGET_CURRENT_ELASTIC_POOL.value
}
else
{
    $MyElasticPoolName = $TARGET_CURRENT_ELASTIC_POOL.value + $CURRENT_NO_OF_ELASTIC_POOLS.value.ToString()
}
Write-Output ("MyElasticPoolName: ", $MyElasticPoolName)

$NextElasticPoolNumber = $CURRENT_NO_OF_ELASTIC_POOLS.value + 1
Write-Output ("NextElasticPoolNumber: ", $NextElasticPoolNumber)

$NextElasticPoolName = $TARGET_CURRENT_ELASTIC_POOL.value + $NextElasticPoolNumber.ToString()
Write-Output ("NextElasticPoolName: ", $NextElasticPoolName)

$PoolDatabaseCount = (Get-AzureRmSqlElasticPoolDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).Count
Write-Output ("PoolDatabaseCount: ", $PoolDatabaseCount)

#$eNotSent = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name emailNotSentYet -ResourceGroupName $TARGET_RESOURCE_GROUP
#Write-Output ("eNotSent: ", $eNotSent.value)

Get-AzureRmSqlElasticPoolDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName
#Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName | Get-Metrics -TimeGrain 0:5:0

Write-Output ("MyElasticPoolName: ", $MyElasticPoolName)
#$MyElasticPoolName = "ZTest"
Write-Output ("MyElasticPoolName: ", $MyElasticPoolName)


$MyEP = Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName | Get-AzureRmMetric -TimeGrain 6:0:0
Write-Output ("MyEP: ", $MyEP)
$MyEPDbMaxSizeBytes = (Get-AzureRmSqlElasticPoolDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).MaxSizeBytes
Write-Output ("MyEPDbMaxSizeBytes: ", $MyEPDbMaxSizeBytes.ToString())
$MyEPDbStatus = (Get-AzureRmSqlElasticPoolDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).Status
Write-Output ("MyEPDbStatus: ", $MyEPDbStatus.ToString())
$EPResourceId = (Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).ResourceId
Write-Output ("EPResourceId: ", $EPResourceId)
$EPCapacity = (Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).Capacity
Write-Output ("EPCapacity: ", $EPCapacity)
$EPDatabaseCapacityMax = (Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).DatabaseCapacityMax
Write-Output ("EPDatabaseCapacityMax: ", $EPDatabaseCapacityMax)
$EPDatabaseCapacityMin = (Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).DatabaseCapacityMin
Write-Output ("EPDatabaseCapacityMin: ", $EPDatabaseCapacityMin)
$EPMaxSizeBytes = (Get-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).MaxSizeBytes
Write-Output ("EPMaxSizeBytes: ", $EPMaxSizeBytes)


#
#Get-AzureRmMetric -ResourceId "/subscriptions/e3f5b07d-3c39-4b0f-bf3b-40fdeba10f2a/resourceGroups/Default-Web-EastUS/providers/microsoft.web/sites/website3" -TimeGrain 00:01:00 -DetailedOutput
$MetricsALSP = Get-AzureRmMetric -ResourceId $EPResourceId -TimeGrain 00:01:00 -DetailedOutput -MetricName "allocated_data_storage_percent"
Write-Output ("ALSP Metrics allocated_data_storage_percent: ", $MetricsALSP)
Write-Output ("ALSP Metrics Id: ", $MetricsALSP.Id)
Write-Output ("ALSP Metrics Name: ", $MetricsALSP.Name)
Write-Output ("ALSP Metrics Name Value: ", $MetricsALSP.Name.Value)
Write-Output ("ALSP Metrics Type: ", $MetricsALSP.Type)
Write-Output ("ALSP Metrics Unit: ", $MetricsALSP.Unit)
Write-Output ("ALSP Metrics Data: ", $MetricsALSP.Data)
Write-Output ("ALSP Metrics Timeseries: ", $MetricsALSP.Timeseries)
Write-Output ("ALSP Metrics Data[0]: ", $MetricsALSP.Data[0])
Write-Output ("ALSP Metrics Data[1]: ", $MetricsALSP.Data[1])
Write-Output ("ALSP Metrics Data[2]: ", $MetricsALSP.Data[2])
Write-Output ("ALSP Metrics Data[3]: ", $MetricsALSP.Data[3])
Write-Output ("ALSP Metrics Data[4]: ", $MetricsALSP.Data[4])
Write-Output ("ALSP Metrics Data[0] Maximum: ", $MetricsALSP.Data[0].Maximum)
Write-Output ("ALSP Metrics Data[0] Average: ", $MetricsALSP.Data[0].Average)
Write-Output ("ALSP STORAGE_MAX_LIMIT: ", $STORAGE_MAX_LIMIT.value)

$Metrics = Get-AzureRmMetric -ResourceId $EPResourceId -TimeGrain 00:01:00 -DetailedOutput -MetricName "storage_percent"
Write-Output ("Metrics storage_percent: ", $Metrics)
Write-Output ("Metrics Id: ", $Metrics.Id)
Write-Output ("Metrics Name: ", $Metrics.Name)
Write-Output ("Metrics Name Value: ", $Metrics.Name.Value)
Write-Output ("Metrics Type: ", $Metrics.Type)
Write-Output ("Metrics Unit: ", $Metrics.Unit)
Write-Output ("Metrics Data: ", $Metrics.Data)
Write-Output ("Metrics Timeseries: ", $Metrics.Timeseries)
Write-Output ("Metrics Data[0]: ", $Metrics.Data[0])
Write-Output ("Metrics Data[1]: ", $Metrics.Data[1])
Write-Output ("Metrics Data[2]: ", $Metrics.Data[2])
Write-Output ("Metrics Data[3]: ", $Metrics.Data[3])
Write-Output ("Metrics Data[4]: ", $Metrics.Data[4])
Write-Output ("Metrics Data[0] Maximum: ", $Metrics.Data[0].Maximum)
Write-Output ("Metrics Data[0] Average: ", $Metrics.Data[0].Average)
Write-Output ("STORAGE_MAX_LIMIT: ", $STORAGE_MAX_LIMIT.value)

Write-Output ("DatabaseAlertON 1: ", $DatabaseAlertON)
Write-Output ("DataSpaceAllocatedAlertON : ", $DataSpaceAllocatedAlertON)

#if(  $Metrics.Data[0].Average -ge $STORAGE_MAX_LIMIT.value )
if( $MetricsALSP.Data[0].Maximum -ge $STORAGE_MAX_LIMIT.value )
{
    $DataSpaceAllocatedAlertON = $True
}
if(  $DataSpaceAllocatedAlertON -eq $True -AND 1 -eq 5 )
{
    Write-Output "000000000000000000000000000000000000000000000000"
    Write-Output "Elastic pool to be created"

    Write-Output ("Starting New Azure Sql Elastic Pool creation : " + $NextElasticPoolName )
    $Status = New-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $NextElasticPoolName -Edition "GeneralPurpose" -StorageMB $STORAGE_MB.value -VCore $NO_VCORE.value -DatabaseVCoreMax $DbVcoreDouble -ComputeGeneration "Gen5"
    Write-Output ("Status: ", $Status)
    Write-Output ("Status ElasticPoolName: ", $Status.ElasticPoolName)


    $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=Lz7cYOUpgYJd6OjtKH0eVs3zK5B4wzzTFbpuf1zZ5FM%3d'
    $params = @{
        ContentType = 'application/json'
        Method = 'Post'
        URI = $webhookurl
    }
    Invoke-RestMethod @params -Verbose
}


$RmAlertHistory = Get-AzureRmAlertHistory -ResourceId $EPResourceId -StartTime (Get-Date).AddHours(-12) -EndTime (Get-Date)
Write-Output ("RmAlertHistory: ", $RmAlertHistory)

Get-AzureRmAlertRule -ResourceGroup $TARGET_RESOURCE_GROUP -DetailedOutput

if( $PoolDatabaseCount -ge $MAX_DATABASE_NUMBER.value )
{
    $DatabaseAlertON = $True
}

Write-Output ("DatabaseAlertON 2: ", $DatabaseAlertON)
Write-Output ("DataSpaceAllocatedAlertON 2: ", $DataSpaceAllocatedAlertON)

if( ($DatabaseAlertON -eq $True) -OR ($DataSpaceAllocatedAlertON -eq $True) )
{
    if( $CURRENT_NO_OF_ELASTIC_POOLS.value -ge $CURRENT_TOTAL_OF_ELASTIC_POOLS.value )
    {
        Write-Output "Elastic pool to be created"

        Write-Output ("Starting New Azure Sql Elastic Pool creation : " + $NextElasticPoolName )
        $Status = New-AzureRmSqlElasticPool -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $NextElasticPoolName -Edition "GeneralPurpose" -StorageMB $STORAGE_MB.value -VCore $NO_VCORE.value -DatabaseVCoreMax $DbVcoreDouble -ComputeGeneration "Gen5"
        Write-Output ("Status: ", $Status)
        Write-Output ("Status ElasticPoolName: ", $Status.ElasticPoolName)

        if( $Status.ElasticPoolName -eq $NextElasticPoolName )
        {
            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_TOTAL_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextElasticPoolNumber -Encrypted $False
            Write-Output ("ELASTIC POOL SUCCESS: NEW EMAIL TO BE SENT Status: ", $Status)

            $NextRetriesPoolCurrent = 0
            Write-Output ("NextRetriesPoolCurrent: ", $NextRetriesPoolCurrent)
            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_POOL_CURRENT -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextRetriesPoolCurrent -Encrypted $False

            $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=EplkLZPDTyLaltNlcKMbpq5h1%2fQ2q9Su9Nj3Y6p4CBw%3d'
            $params = @{
                ContentType = 'application/json'
                Method = 'Post'
                URI = $webhookurl
            }
            Invoke-RestMethod @params -Verbose
            Write-Output "111111111111111111111111111111111111111111111111"
        }
        else
        {
            Write-Output ("ELASTIC POOL FAILED: NEW EMAIL TO BE SENT Status: ", $Status)

            $NextRetriesPoolCurrent = $RETRIES_POOL_CURRENT.value + 1
            Write-Output ("NextRetriesPoolCurrent: ", $NextRetriesPoolCurrent)
            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_POOL_CURRENT -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextRetriesPoolCurrent -Encrypted $False

            if( $NextRetriesPoolCurrent -ge $RETRIES_POOL_MAX.value )
            {
                $webhookurl = 'https://d8e79983-045d-48f9-8367-570873fe6a5d.webhook.eus.azure-automation.net/webhooks?token=%2bLornqV%2bCjEpLeI4CZFn3ONs8GgRUFIId9mAPLJEPPQ%3d'
            }
            else
            {
                $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=ZJVmEwGqJdP8ZZt22Iomaki%2bfSzVyK37h4EkVlpv2DM%3d'
            }

            $params = @{
                ContentType = 'application/json'
                Method = 'Post'
                URI = $webhookurl
            }
            Invoke-RestMethod @params -Verbose
            Write-Output "22222222222222222222222222222222222222222222222222"
        }

        #$NextEPActivity = Get-AzureRmSqlElasticPoolActivity -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $NextElasticPoolName
        #Write-Output ("NextEPActivity: ", $NextEPActivity)

        Write-Output ("Finished Azure Sql Elastic Pool creation, starting database move")

    }
    else
    {
        Write-Output "Elastic pool NOT to be created"
    }

    $myOldMasterDb = Get-AzureRmSqlDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -DatabaseName $DATABASE_NAME.value
    Write-Output ("myOldMasterDb: ", $myOldMasterDb)
    Write-Output ("myOldMasterDb ElasticPoolName: ", $myOldMasterDb.ElasticPoolName)

    Set-AzureRmSqlElasticPool  -ElasticPoolName $NextElasticPoolName -VCore $NO_VCORE.value -DatabaseVCoreMax $DbVcoreDouble -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value
    Set-AzureRmSqlDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -DatabaseName $DATABASE_NAME.value -ElasticPoolName $NextElasticPoolName

    $myNewMasterDb = Get-AzureRmSqlDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -DatabaseName $DATABASE_NAME.value
    Write-Output ("myNewMasterDb: ", $myNewMasterDb)
    Write-Output ("myNewMasterDb ElasticPoolName: ", $myNewMasterDb.ElasticPoolName)

    if($myOldMasterDb.ElasticPoolName -eq $myNewMasterDb.ElasticPoolName)
    {
            Write-Output ("DATABASE MOVE FAILED: NEW EMAIL TO BE SENT ElasticPoolName: ", $myNewMasterDb.ElasticPoolName)

            $NextRetriesDbCurrent = $RETRIES_DB_CURRENT.value + 1
            Write-Output ("NextRetriesDbCurrent: ", $NextRetriesDbCurrent)
            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_DB_CURRENT -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextRetriesDbCurrent -Encrypted $False

            if( $NextRetriesDbCurrent -ge $RETRIES_DB_MAX.value )
            {
                $webhookurl = 'https://d8e79983-045d-48f9-8367-570873fe6a5d.webhook.eus.azure-automation.net/webhooks?token=dgyZGasXjhCw%2f39Py9ykXFVhoSQnC6hUDgk%2f%2f8kqXkI%3d'
            }
            else
            {
                $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=VPc534E%2b%2ffdd3BnTW0myv6vEvwVz%2bEUKYQGKcDxITtA%3d'
            }
            $params = @{
                ContentType = 'application/json'
                Method = 'Post'
                URI = $webhookurl
            }
            Invoke-RestMethod @params -Verbose
            Write-Output "333333333333333333333333333333333333333333333333333"
    }
    else
    {
            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_NO_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextElasticPoolNumber -Encrypted $False
            Write-Output ("DATABASE MOVE SUCCESS: NEW EMAIL TO BE SENT ElasticPoolName: ", $myNewMasterDb.ElasticPoolName)

            $NextRetriesDbCurrent = 0
            Write-Output ("NextRetriesDbCurrent: ", $NextRetriesDbCurrent)
            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_RETRIES_DB_CURRENT -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextRetriesDbCurrent -Encrypted $False

            $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=dBVT%2fzrnNoajh%2bJO8ng53uvwYdWFTJkoQJVfAMrFeg8%3d'
            $params = @{
                ContentType = 'application/json'
                Method = 'Post'
                URI = $webhookurl
            }
            Invoke-RestMethod @params -Verbose
            Write-Output "4444444444444444444444444444444444444444444444444444444"
    }
}
else
{
    Write-Output "55555555555555555555555555555555555555555555555555"
}
#$MyEPActivity = Get-AzureRmSqlElasticPoolActivity -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName
#Write-Output ("MyEPActivity: ", $MyEPActivity)


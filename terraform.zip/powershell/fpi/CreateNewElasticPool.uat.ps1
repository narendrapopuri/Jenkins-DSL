$connectionName = "AzureRunAsConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}
$TARGET_RESOURCE_GROUP = "RGP-USE-FPI-UAT"
$AUTOMATION_ACCOUNT_NAME = "ama-use-fpi-auto-uat"
#$TARGET_SQL_SERVER = "co-np-fpi-kpmg-sql"
#$TARGET_ELASTIC_POOL = "fpi-sql-pool"

$TARGET_SQL_SERVER = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_TARGET_SQL_SERVER -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("TARGET_SQL_SERVER: ", $TARGET_SQL_SERVER.value)
$TARGET_CURRENT_ELASTIC_POOL = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_TARGET_CURRENT_ELASTIC_POOL -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("TARGET_CURRENT_ELASTIC_POOL: ", $TARGET_CURRENT_ELASTIC_POOL.value)
$MAX_DATABASE_NUMBER = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_MAX_DATABASE_NUMBER -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("MAX_DATABASE_NUMBER: ", $MAX_DATABASE_NUMBER.value)
$DATABASE_NAME = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_DATABASE_NAME -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("DATABASE_NAME: ", $DATABASE_NAME.value)

$EMAIL_NOT_SENT_YET = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_EMAIL_NOT_SENT_YET -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("EMAIL_NOT_SENT_YET: ", $EMAIL_NOT_SENT_YET.value)
$NO_VCORE = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_VCORE -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("NO_VCORE: ", $NO_VCORE.value)
$STORAGE_MB = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_STORAGE_MB -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("STORAGE_MB: ", $STORAGE_MB.value)
$CURRENT_NO_OF_ELASTIC_POOLS = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_NO_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("CURRENT_NO_OF_ELASTIC_POOLS: ", $CURRENT_NO_OF_ELASTIC_POOLS.value)


if( $CURRENT_NO_OF_ELASTIC_POOLS.value -EQ 1 )
{
    $MyElasticPoolName = $TARGET_CURRENT_ELASTIC_POOL.value
}
else
{
    $MyElasticPoolName = $TARGET_CURRENT_ELASTIC_POOL.value + $CURRENT_NO_OF_ELASTIC_POOLS.value.ToString()
}
Write-Output ("MyElasticPoolName: ", $MyElasticPoolName)

$NextElasticPoolNumber = $CURRENT_NO_OF_ELASTIC_POOLS.value + 1
Write-Output ("NextElasticPoolNumber: ", $NextElasticPoolNumber)

$NextElasticPoolName = $TARGET_CURRENT_ELASTIC_POOL.value + $NextElasticPoolNumber.ToString()
Write-Output ("NextElasticPoolName: ", $NextElasticPoolName)

$PoolDatabaseCount = (Get-AzureRmSqlElasticPoolDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -ElasticPoolName $MyElasticPoolName).Count
Write-Output ("PoolDatabaseCount: ", $PoolDatabaseCount)

#$eNotSent = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name emailNotSentYet -ResourceGroupName $TARGET_RESOURCE_GROUP
#Write-Output ("eNotSent: ", $eNotSent.value)

if ($EMAIL_NOT_SENT_YET.value) {
    Write-Output "Email not sent yet, to be sent"
}
else{
    Write-Output "Email already sent"
}

if( $PoolDatabaseCount -ge $MAX_DATABASE_NUMBER.value -AND $EMAIL_NOT_SENT_YET.value )
{
    try
    {
        Write-Output ("Starting New Azure Sql Elastic Pool creation : " + $NextElasticPoolName )
        $CmdExecuted = New-AzureRmSqlElasticPool -ElasticPoolName $NextElasticPoolName -Edition "GeneralPurpose" -StorageMB $STORAGE_MB.value -VCore $NO_VCORE.value -ComputeGeneration "Gen5" -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value
        Write-Output ("CmdExecuted: ", $CmdExecuted)
        Write-Output ("Finished Azure Sql Elastic Pool creation, starting database move")
        try
        {
            Set-AzureRmSqlElasticPool  -ElasticPoolName $NextElasticPoolName -VCore $NO_VCORE.value  -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value
            Set-AzureRmSqlDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -DatabaseName $DATABASE_NAME.value -ElasticPoolName $NextElasticPoolName
            Write-Output ("Finished database move 1")

            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_NO_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextElasticPoolNumber -Encrypted $False
        }
        catch
        {
            Write-Output ("MOVING DATABASE FAILED 1, email notification to be sent")
        }
    }
    catch
    {
        Write-Output ("ELASTIC POOL CREATION FAILED, email notification to be sent")

        try
        {
            Set-AzureRmSqlElasticPool  -ElasticPoolName $NextElasticPoolName -VCore $NO_VCORE.value  -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value
            Set-AzureRmSqlDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER.value -DatabaseName $DATABASE_NAME.value -ElasticPoolName $NextElasticPoolName
            Write-Output ("Finished database move 2")

            Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_CURRENT_NO_OF_ELASTIC_POOLS -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $NextElasticPoolNumber -Encrypted $False
        }
        catch
        {
            Write-Output ("MOVING DATABASE FAILED 2, email notification to be sent")
        }
    }
    Write-Output ("Number of databases greater or equal 300 AND email is being sent")

#    $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=XOd461XvcIdvfLeZy34x%2fhLYRrlrWOkBBJhonpZFYmw%3d'
    $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=Y2KFrLtm3N9Ub7Lo5AwqQ4J7%2fqPs2IUp%2fUha4uXaBDs%3d'
    $params = @{
        ContentType = 'application/json'
        Method = 'Post'
        URI = $webhookurl
    }
    Invoke-RestMethod @params -Verbose

    Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name V_EMAIL_NOT_SENT_YET -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $False -Encrypted $False
}
else
{
    Write-Output ("Number of databases not greater or equal 300 OR email had been sent already")
}


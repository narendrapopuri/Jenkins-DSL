Connect-AzureRmAccount -MSI

$Sender = 'FPI QA GREEN: New Elastic Pool SUCCESSFUL Notification <noreply@kpmg.com>'
$Recepients = 'Zoran Galovic <zgalovic@kpmg.com>', 'Sakthi Pichaimani <spichaimani@kpmg.com>', 'Dmitriy Modlin <dmodlin@kpmg.com>', 'Pavan Gudiyella <pgudiyella@kpmg.com>', 'Hurn, Scott <shurn@kpmg.com>', 'Koenigsknecht, Brandon <bkoenigsknecht@KPMG.com>', 'Nguyen, Jessica F <jessicanguyen@Kpmg.Com>', 'KPMG NP Support <go-fmmanagedservice1@kpmg.com>'
#$Recepients = 'Galovic, Zoran <zgalovic@kpmg.com>'
$Subject = "FPI QA GREEN: New Elastic pool creation SUCCESSFUL notification"
$Body1 = "FPI QA GREEN: New Elastic Pool creation SUCCESSFUL"
$Body2 = "`r`n`r`nFPI Elastic pools (QA):`r`n"
$Body3 = "https://portal.azure.com/#@kpmgusadvspectrum.onmicrosoft.com/resource/subscriptions/adf88b05-d3d7-4dee-ba30-ea939f9a1b1c/resourceGroups/RGP-USE-FPI-QA/providers/Microsoft.Sql/servers/srv-use-fpi-qa/elasticPoolsList"
$SmtpServer = '199.207.144.9'

$Body = $Body1 + $Body2 + $Body3
Send-MailMessage -From $Sender -To $Recepients -Subject $Subject -Body $Body -SmtpServer $SmtpServer

﻿AAResourceGroupName: co-nps-spi-fpi-rg
SubscriptionID: 0feb4855-aaa2-40f1-bec2-a8db1dfe472e
AutomationAccountName: Spi-fpi-aa-uat
HybridGroupName: FPIElasticPoolUAT

$connectionName = "AzureRunAsConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}
$TARGET_RESOURCE_GROUP = "CO-NP-SPI-FPI-RG"
$AUTOMATION_ACCOUNT_NAME = "Spi-fpi-aa-qa"
$TARGET_SQL_SERVER = "co-np-fpi-kpmg-sql"
$TARGET_ELASTIC_POOL = "fpi-sql-pool"

$PoolDatabaseCount = (Get-AzureRmSqlElasticPoolDatabase -ResourceGroupName $TARGET_RESOURCE_GROUP -ServerName $TARGET_SQL_SERVER -ElasticPoolName $TARGET_ELASTIC_POOL).Count
Write-Output ("PoolDatabaseCount: ", $PoolDatabaseCount)

$eNotSent = Get-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name emailNotSentYet -ResourceGroupName $TARGET_RESOURCE_GROUP
Write-Output ("eNotSent: ", $eNotSent.value)

if ($eNotSent.value) {
    Write-Output "Email not sent yet, to be sent"
}
else{
    Write-Output "Email already sent"
}

if( $PoolDatabaseCount -ge 300 -AND $eNotSent.value )
{
    Write-Output ("Number of databases greater or equal 250 AND email is being sent")

    $webhookurl = 'https://s16events.azure-automation.net/webhooks?token=XOd461XvcIdvfLeZy34x%2fhLYRrlrWOkBBJhonpZFYmw%3d'
    $params = @{
        ContentType = 'application/json'
        Method = 'Post'
        URI = $webhookurl
    }
    Invoke-RestMethod @params -Verbose

    Set-AzureRmAutomationVariable -AutomationAccountName $AUTOMATION_ACCOUNT_NAME -Name emailNotSentYet -ResourceGroupName $TARGET_RESOURCE_GROUP -Value $False -Encrypted $False
}
else
{
    Write-Output ("Number of databases not greater or equal 279 OR email had been sent already")
}


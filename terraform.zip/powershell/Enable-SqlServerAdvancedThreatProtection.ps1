param (
    [string]$ResourceGroupName,
    [string]$ServerName,
    [boolean]$EmailAdmins = $true,
    [string]$StorageAccountName,
    [int]$RetentionInDays = 6,
    [string]$ScanResultsContainerName = "vulnerability-assessment",
    [string]$RecurringScansInterval = "Weekly",
    [array]$NotificationEmail = @(),
    [string]$Environment = "usgovcloudapi"

)

$key = (Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -AccountName $StorageAccountName).Value[0]
$ctx = New-AzStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $key
$sastoken = New-AzStorageContainerSASToken -Name $ScanResultsContainerName -Permission rwdl -Context $ctx
$sasurl = "https://" + $StorageAccountName + ".blob.core." + $Environment + ".net/" + $ScanResultsContainerName + $sastoken

Update-AzSqlServerAdvancedThreatProtectionSetting -ResourceGroupName $ResourceGroupName -ServerName $ServerName -EmailAdmins $EmailAdmins -RetentionInDays $RetentionInDays
Update-AzSqlServerVulnerabilityAssessmentSetting -ResourceGroupName $ResourceGroupName -ServerName $ServerName -BlobStorageSasUri $sasurl -RecurringScansInterval $RecurringScansInterval -EmailAdmins $EmailAdmins -NotificationEmail $NotificationEmail 

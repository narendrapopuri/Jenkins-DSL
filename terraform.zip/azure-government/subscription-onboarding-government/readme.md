# About This Project

This project is used to onboard new subscriptions with the required baseline resource group, key vault, and storage account.  It can be deployed using the following unified YAML pipeline:

https://dev.azure.com/CO-AzureCore/KpmgAdvisoryCloud/_build?definitionId=467 #TODO

Pipeline Status:

![Pipeline Status](https://dev.azure.com/CO-AzureCore/KpmgAdvisoryCloud/_apis/build/status/iac-subscription-onboarding-government?branchName=master) #TODO
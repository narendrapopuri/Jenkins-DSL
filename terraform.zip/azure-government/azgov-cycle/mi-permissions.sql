if not exists(select * from sysusers where name='app-ugv-cycle-web-dv')
begin
CREATE USER e590a6fe-ab80-40f2-8cf3-864c51dd9a02 FROM EXTERNAL PROVIDER;
ALTER ROLE db_owner ADD MEMBER e590a6fe-ab80-40f2-8cf3-864c51dd9a02;
end

if not exists(select * from sysusers where name='app-ugv-cycle-reporting-dv')
begin
CREATE USER 1d10bc24-538a-4fe5-8cff-e68fa02a251f FROM EXTERNAL PROVIDER;
ALTER ROLE db_owner ADD MEMBER 1d10bc24-538a-4fe5-8cff-e68fa02a251f;
end

if not exists(select * from sysusers where name='app-ugv-cycle-search-dv')
begin
CREATE USER e0a53833-09d9-491c-bc85-0a143d791af9 FROM EXTERNAL PROVIDER;
ALTER ROLE db_owner ADD MEMBER e0a53833-09d9-491c-bc85-0a143d791af9;
end
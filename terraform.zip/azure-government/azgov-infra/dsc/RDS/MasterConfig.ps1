Configuration MasterConfig {

    param (

     
     [Parameter(Mandatory)]
     [String]$domainName,
     
     [Parameter(Mandatory)]
     [String]$credentialKey        
    
    )

    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Import-DscResource -ModuleName ComputerManagementDsc
    Import-DscResource -ModuleName xRemoteDesktopSessionHost

    $DomainCredential = Get-AutomationPSCredential -Name $credentialKey #-ResourceGroupName "g-aads" -AutomationAccountName "ama-adds"

    Node $AllNodes.NodeName {

        Computer JoinDomain
        {
            Name       = 'localhost'
            DomainName = $domainName
            Credential = $DomainCredential # Credential to join to domain
        }

    }
    
    Node $AllNodes.Where{$_.Role -eq "rds-broker"}.NodeName {

        WindowsFeature RDS-Connection-Broker
            {
                Ensure = "Present"
                Name = "RDS-Connection-Broker"
            }

        WindowsFeature RDS-Licensing
            {
                Ensure = "Present"
                Name = "RDS-Licensing"
            }

        xRDLicenseConfiguration RdsLicenseConfig {
            ConnectionBroker = "vmcb.rcddevryan.local"
            LicenseMode      = "PerUser"
        }

    } 
    
    Node $AllNodes.Where{$_.Role -eq "rds-session"}.NodeName {

        WindowsFeature RDS-RD-Server
            {
                Ensure = "Present"
                Name = "RDS-RD-Server"
            }

        xRDSessionDeployment Deployment
        {
            SessionHosts = "vmsh.rcddevryan.local"
            ConnectionBroker = "vmcb.rcddevryan.local"
            WebAccessServer = "vmrdsweb.rcddevryan.local"
            DependsOn = "[WindowsFeature]RDS-RD-Server"
        }

        xRDSessionCollection CloudOpsDscCollection
        {
            CollectionName = "CloudOpsDsc"
            CollectionDescription = "This is a test of session collections"
            SessionHosts = "vmsh.rcddevryan.local"
            ConnectionBroker = "vmcb.rcddevryan.local"
        }

        xRDSessionCollectionConfiguration CollectionConfiguration
        {
            CollectionName = "CloudOpsDsc"
            CollectionDescription = "This is a test of session collections"
            ConnectionBroker = "vmcb.rcddevryan.local"
            TemporaryFoldersDeletedOnExit = $false
            SecurityLayer = "SSL"
            DependsOn = "[xRDSessionCollection]CloudOpsDscCollection"impor
        }

    }  
    
    Node $AllNodes.Where{$_.Role -eq "rds-license"}.NodeName {

        WindowsFeature RDS-Licensing
            {
                Ensure = "Present"
                Name = "RDS-Licensing"
            }

        xRDLicenseConfiguration RdsLicenseConfig {
            ConnectionBroker = "vmcb"
            LicenseMode      = "PerUser"
        }

    } 

    Node $AllNodes.Where{$_.Role -eq "rds-gateway"}.NodeName {

        

        WindowsFeature RDS-Web-Access
            {
                Ensure = "Present"
                Name = "RDS-Web-Access"
            }

        WindowsFeature RDS-Gateway
            {
                Ensure = "Present"
                Name = "RDS-Gateway"
            }

        xRDGatewayConfiguration GatewayConfiguration {
            ConnectionBroker     = "vmcb.rcddevryan.local"
            GatewayServer        = "vmrdsweb.rcddevryan.local"
            ExternalFqdn         = "rcddev.com"
            GatewayMode          = "Custom"
            LogonMethod          = "Password"
            UseCachedCredentials = $false
            BypassLocal          = $false
            DependsOn = "[WindowsFeature]RDS-Gateway"
        }

    } 

    Node $AllNodes.Where{$_.Role -eq "rds-web"}.NodeName {

        WindowsFeature RDS-Web-Access
            {
                Ensure = "Present"
                Name = "RDS-Web-Access "
            }

    }
}  
#MasterConfig -OutputPath 'C:\users\scottmcco (73D30B87)\repos\Terraform\azgov-infra\dsc\rds' -ConfigurationData $ConfigData -domainName $domainName -credentialKey $credentialKey
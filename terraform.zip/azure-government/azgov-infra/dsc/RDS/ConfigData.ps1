@{
    AllNodes =
    @(
        @{
            NodeName = "*"
            PSDscAllowPlainTextPassword = $true
        },
        @{
            NodeName = "rds-broker"
            Role = "rds-broker"
        },
        @{
            NodeName = "rds-session"
            Role = "rds-session"
        },
        @{
            NodeName = "rds-license"
            Role = "rds-license"
        },
        @{
            NodeName = "rds-gateway"
            Role = "rds-gateway"
        },
        @{
            NodeName = "rds-web"
            Role = "rds-web"
        }
    )
}
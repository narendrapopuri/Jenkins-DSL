$env = "dv"
$scriptPath = "c:\rds"
#Requires -version 4.0
#Requires -RunAsAdministrator

#Functions
function Test-PsRemoting {
    param(
        [Parameter(Mandatory = $true)]
        $computername
    )
   
    try
    {
        $errorActionPreference = "Stop"
        $result = Invoke-Command -ComputerName $computername { 1 }
    }
    catch
    {
        Write-Verbose $_
        return $false
    }
   
    if($result -ne 1)
    {
        Write-Verbose "Remoting to $computerName returned an unexpected result."
        return $false
    }
   
    $true   
} # end Test-PsRemoting
$startPoint = Read-Host "Enter Start Point [1-35]:"
$endPoint = Read-Host "Enter End Point [1-35]:"
$startPoint = [int]$startPoint
$endPoint = [int]$endPoint

$configpath= "$($scriptPath)\config.json"
$StartDate = (Get-Date) 
$Vendor = "Microsoft"
$Product = "Remote Desktop Farm"
$Version = "2016"
$LogPath = "$($scriptPath)" + "\$Vendor $Product $Version.log"

Start-Transcript $LogPath

#region "Check Prerequisites"
Write-Verbose "Check Prerequisites" -Verbose

if (Get-WindowsFeature -Name RSAT-AD-Tools, RSAT-DNS-Server){
Write-Verbose "Needed PowerShell Modules available." -Verbose
} else {    
Write-Verbose "Needed PowerShell Modules will be installed." -Verbose
Install-WindowsFeature RSAT-AD-Tools, RSAT-DNS-Server
Write-Verbose "Needed PowerShell Modules have been installed." -Verbose
} #end if Get-WindowsFeature

if (Test-Path $configpath) {
Write-Verbose "JSON File was found." -Verbose
$config = Get-Content -Path $configpath -Raw | ConvertFrom-Json
Write-Verbose "JSON File was imported." -Verbose
} Else {
Write-Warning "Failed to find the JSON File."
break
} #end if Test-Path $configpath

if (Test-Path $config.$env.CertPath) {
Write-Verbose "SSL Certificate was found." -Verbose
CERTUTIL -f -p $config.$env.CertPassword -importpfx "$($config.$env.CertPath)"
} Else {
Write-Warning "Failed to find the SSL Certificate."
break
} # end if Test-Path $config.$env.CertPath

Import-Module Activedirectory
$NameRDSAccessGroup = $config.$env.RDSAccessGroup.split('@')[0]
$NameGatewayAccessGroup = $config.$env.GatewayAccessGroup.split('@')[0]
$testRDSAccessGroup = Get-ADGroup $NameRDSAccessGroup
$testGatewayAccessGroup = Get-ADGroup $NameGatewayAccessGroup

#endregion "Check Prerequisites"

#region TEST
if(Test-PsRemoting -computername $config.$env.RDSHost01, $config.$env.RDSHost02, $config.$env.ConnectionBroker01, $config.$env.WebAccessServer01, $config.$env.RDGatewayServer01){
	Write-Verbose "PSRemoting is enabled on all Hosts. Deployment ready." -Verbose
} Else {
	Write-Warning "PSRemoting is not enabled on all Hosts. Deployment is not ready!" 
	$PSRemoteMulti = @("$($config.$env.RDSHost01)","$($config.$env.RDSHost02)","$($config.$env.ConnectionBroker01)","$($config.$env.ConnectionBroker02)","$($config.$env.RDGatewayServer01)","$($config.$env.RDGatewayServer02)")
	foreach($TestMulti in $PSRemoteMulti){
		$status = Test-PsRemoting -computername $TestMulti; "$TestMulti;$status"
	}
	break
} #end Test-PsRemoting MultiDeployment

Write-Host "Testing SMB ACCESS TO CONNECTION BROKERS"
if(Test-Path "\\$($config.$env.ConnectionBroker01)\c$"){Write-Verbose "Connection Broker 01 UNC path reachable"} else { Write-Warning "$($config.$env.ConnectionBroker01) SMB Failed"; break}
if(Test-Path "\\$($config.$env.ConnectionBroker02)\c$"){Write-Verbose "Connection Broker 02 UNC path reachable"} else { Write-Warning "$($config.$env.ConnectionBroker02) SMB Failed"; break}

if(Test-PsRemoting -computername $config.$env.RDSHost01, $config.$env.RDSHost02, $config.$env.ConnectionBroker01, $config.$env.ConnectionBroker02, $config.$env.WebAccessServer01, $config.$env.WebAccessServer02, $config.$env.RDGatewayServer01, $config.$env.RDGatewayServer02 ){
Write-Verbose "PSRemoting is enabled on all Hosts." -Verbose
} Else {
Write-Warning "PSRemoting is not enabled on all Hosts." -Verbose
$PSRemoteHA = @("$($config.$env.RDSHost01)","$($config.$env.RDSHost02)","$($config.$env.ConnectionBroker01)","$($config.$env.ConnectionBroker02)","$($config.$env.WebAccessServer01)","$($config.$env.WebAccessServer02)","$($config.$env.RDGatewayServer01)","$($config.$env.RDGatewayServer02)")
foreach($TestHA in $PSRemoteHA){
	$status = Test-PsRemoting -computername $TestHA; "$TestHA;$status"
}
break
} #end if Test-PsRemoting

set-azcontext -SubscriptionName $config.$env.SubscriptionName
if(!($NameGatewayAccessGroup)){Write-Warning "AD group $NameGatewayAccessGroup does not exist."; break}
if(!($testRDSAccessGroup)){Write-Warning "AD group $NameRDSAccessGroup does not exist."; break}

#if(Test-Path "$($config.$env.ProfileDiskPath)"){Write-Verbose "Profile path reachable"} else { Write-Warning "$($config.$env.ProfileDiskPath) UPD UNC Path Unreachable"; break}

read-host "All Testing is done. Press enter to continue"
Read-Host "Verify Hosts are domain joined before continuing"

Write-Verbose "Starting Installation of $Vendor $Product $Version" -Verbose

if (($startPoint -le 1) -and ($startPoint -le $endPoint))
{
	Write-Host "<<<<<<<<<<<<<<<Step 1 Start>>>>>>>>>>>>>>>"
	try 
	{
		# Import the RemoteDesktop Module
		Import-Module RemoteDesktop

		# Create RDS deployment
		New-RDSessionDeployment -ConnectionBroker $config.$env.ConnectionBroker01 -WebAccessServer $config.$env.WebAccessServer01 -SessionHost @($config.$env.RDSHost01, $config.$env.RDSHost02)
		Write-Verbose "Created New RDS deployment" -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 1 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch 
	{
		Write-Host "Step 1 Failed"
		break
	}
}

if (($startPoint -le 2) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 2 Start>>>>>>>>>>>>>>>"
		#Install Broker Role on ConnectionBroker02
		Add-WindowsFeature -Name RDS-Connection-Broker -IncludeManagementTools -ComputerName $config.$env.ConnectionBroker02
		Write-Verbose "Installed Connection Broker Role On ConnectionBroker02"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 2 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 2 Failed"
		break
	}
}

if (($startPoint -le 3) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 3 Start>>>>>>>>>>>>>>>"
		# Create Desktop Collection
		New-RDSessionCollection  -CollectionName $config.$env.DesktopCollectionName -SessionHost @($config.$env.RDSHost01, $config.$env.RDSHost02)  -CollectionDescription $config.$env.DesktopDescription  -ConnectionBroker $config.$env.ConnectionBroker01 
		Write-Verbose "Created new Desktop Collection"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 3 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 3 Failed"
		break
	}
}

if (($startPoint -le 4) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 4 Start>>>>>>>>>>>>>>>"
		#Install Gateway 1
		Add-WindowsFeature -Name RDS-Gateway -IncludeManagementTools -ComputerName $config.$env.RDGatewayServer01
		Write-Verbose "Installed RDS Gateway"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 4 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 4 Failed"
		break
	}
}

if (($startPoint -le 5) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 5 Start>>>>>>>>>>>>>>>"
		#Install Gateway 2
		Add-WindowsFeature -Name RDS-Gateway -IncludeManagementTools -ComputerName $config.$env.RDGatewayServer02
		Write-Verbose "Installed RDS Gateway"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 5 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 5 Failed"
		break
	}
}

if (($startPoint -le 6) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 6 Start>>>>>>>>>>>>>>>"
		#Join Gateway 1 to Broker 1 (Gateway 2 is step 19)
		Add-RDServer -Server $config.$env.RDGatewayServer01 -Role "RDS-GATEWAY" -ConnectionBroker $config.$env.ConnectionBroker01 -GatewayExternalFqdn $config.$env.RDGatewayServer01
		Write-Verbose "Joined RDS Gateway to Broker"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 6 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 6 Failed"
		break
	}
}

if (($startPoint -le 7) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 7 Start>>>>>>>>>>>>>>>"
		# Create RDS Broker Load Balancer DNS-Record
		Import-Module DNSServer
		#$IPBroker01 = [System.Net.Dns]::GetHostAddresses("$($config.$env.ConnectionBroker01)")[0].IPAddressToString
		$IP = $config.$env.ConnectionBrokerLoadbalancerIP
		Add-DnsServerResourceRecordA -ComputerName $config.$env.DomainController  -Name $config.$env.RDBrokerDNSInternalName -ZoneName $config.$env.RDBrokerDNSInternalZone -AllowUpdateAny -IPv4Address $IP 
		Write-Verbose "Configured RDSBroker Load Balancer DNS-Record"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 7 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 7 Failed"
		break
	}
}

if (($startPoint -le 8) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 8 Start>>>>>>>>>>>>>>>"
		# Create RDS Gateway DNS-Record (Round Robin)
		Import-Module DNSServer
		$GW1_IP = [System.Net.Dns]::GetHostAddresses("$($config.$env.RDGatewayServer01)")[0].IPAddressToString
		$GW2_IP = [System.Net.Dns]::GetHostAddresses("$($config.$env.RDGatewayServer02)")[0].IPAddressToString
		Add-DnsServerResourceRecordA -ComputerName $config.$env.DomainController  -Name $config.$env.RDWebAccessDNSInternalName -ZoneName $config.$env.RDWebAccessDNSInternalZone -AllowUpdateAny -IPv4Address $GW1_IP,$GW2_IP
		Write-Verbose "Configured RDS Gateway Load Balancer DNS-Record"  -Verbose
		
		# Create Primary DNS Zone for database.usgovcloudapi.net and Private Endpoint DNS Entry for RDS SQL DB 
		Add-DnsServerPrimaryZone -ComputerName $config.$env.DomainController -Name "database.usgovcloudapi.net" -ReplicationScope Domain -PassThru -ErrorAction SilentlyContinue
		Write-Verbose "Added DNS Primary Zone for database.usgovcloudapi.net"  -Verbose
		Add-DnsServerResourceRecordA -ComputerName $config.$env.DomainController  -Name $config.$env.SQLServerName -ZoneName database.usgovcloudapi.net -AllowUpdateAny -IPv4Address $config.$env.SQLDBPrivateEndpointIP
		Write-Verbose "Configured RDS SQL DB Private Endpoint DNS-Record"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 8 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 8 Failed"
		break
	}
}

if (($startPoint -le 9) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 9 Start>>>>>>>>>>>>>>>"
		# Configure Gateway Server Settings
		Set-RDDeploymentGatewayConfiguration -GatewayMode Custom -GatewayExternalFqdn $config.$env.GatewayInternalFqdn -LogonMethod Password -UseCachedCredentials $True -BypassLocal $False -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Write-Host "<<<<<<<<<<<<<<<Step 9 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 9 Failed"
		break
	}
}

if (($startPoint -le 10) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 10 Start>>>>>>>>>>>>>>>"
		#Redirect to RDWeb (IIS)
		Invoke-Command -ComputerName $config.$env.WebAccessServer01 -ArgumentList $config.$env.RDWebAccessDNSInternalName, $config.$env.RDWebAccessDNSInternalZone  -ScriptBlock {
			$RDWebAccessDNSInternalName = $args[0]
			$RDWebAccessDNSInternalZone = $args[1]
			$siteName = "Default Web Site"
			Import-Module webAdministration
			Set-WebConfiguration system.webServer/httpRedirect "IIS:\sites\$siteName" -Value @{enabled="true";destination="https://$RDWebAccessDNSInternalName.$RDWebAccessDNSInternalZone/RDWeb";exactDestination="true";httpResponseStatus="Found";childOnly="true"} 
		} #end Redirect to RDWeb
		Write-Verbose "Configured RDWeb Redirect"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 10 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 10 Failed"
		break
	}
}

if (($startPoint -le 11) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 11 Start>>>>>>>>>>>>>>>"
		# Set Access Group for RDS Collection
		Set-RDSessionCollectionConfiguration -CollectionName $config.$env.DesktopCollectionName -UserGroup "AAD DC Administrators","$($config.$env.RDSAccessGroup)" -ConnectionBroker $config.$env.ConnectionBroker01
		Write-Verbose "Configured Access for $($config.$env.RDSAccessGroup)"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 11 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 11 Failed"
		break
	}
}

# Set Profile Disk 
#Set-RDSessionCollectionConfiguration -CollectionName $config.$env.DesktopCollectionName -EnableUserProfileDisk -MaxUserProfileDiskSizeGB "20" -DiskPath $config.$env.ProfileDiskPath -ConnectionBroker $config.$env.ConnectionBroker01
#Write-Verbose "Configured ProfileDisk"  -Verbose

if (($startPoint -le 12) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 12 Start>>>>>>>>>>>>>>>"
		# RDS Licensing for Connection Broker 01
		Add-RDServer -Server $config.$env.LICserver01 -Role "RDS-LICENSING" -ConnectionBroker $config.$env.ConnectionBroker01
		Write-Verbose "Installed RDS Licence Server: $($config.$env.LICserver01)"  -Verbose
		Set-RDLicenseConfiguration -LicenseServer $config.$env.LICserver01 -Mode $config.$env.LICmode -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Write-Verbose "Configured RDS Licening"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 12 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 12 Failed"
		break
	}
}

if (($startPoint -le 13) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 13 Start>>>>>>>>>>>>>>>"
		# Set Certificates
		$Password = ConvertTo-SecureString -String $config.$env.CertPassword -AsPlainText -Force 
		Set-RDCertificate -Role RDPublishing -ImportPath $config.$env.CertPath  -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Set-RDCertificate -Role RDRedirector -ImportPath $config.$env.CertPath -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Set-RDCertificate -Role RDWebAccess -ImportPath $config.$env.CertPath -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Set-RDCertificate -Role RDGateway -ImportPath $config.$env.CertPath  -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Write-Verbose "Configured SSL Certificates"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 13 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 13 Failed"
		break
	}
}

if (($startPoint -le 14) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 14 Start>>>>>>>>>>>>>>>"
		#Reboot ConnectionBroker01 (without Reboot, there can occur errors with the next commands)
		Write-Verbose "$($config.$env.ConnectionBroker01) will reboot"  -Verbose
		Restart-Computer -ComputerName $config.$env.ConnectionBroker01 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
		Write-Verbose "$($config.$env.ConnectionBroker01) online again"  -Verbose

		#Reboot ConnectionBroker02 (without Reboot, there can occur errors with the next commands)
		Write-Verbose "$($config.$env.ConnectionBroker02) will reboot"  -Verbose
		Restart-Computer -ComputerName $config.$env.ConnectionBroker02 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
		Write-Verbose "$($config.$env.ConnectionBroker02) online again"  -Verbose
		Write-Verbose "Waiting for RD Deployment to come online" -Verbose
		Start-Sleep -s 130
		Set-RDConnectionBrokerHighAvailability -ConnectionBroker $config.$env.ConnectionBroker01`
			-DatabaseConnectionString "Driver={ODBC Driver 13 for SQL Server};Server=$($config.$env.SQLServerFqdn),1433;Database=$($config.$env.SQLDatabase);Uid=$($config.$env.SqlAccount);Pwd=$($config.$env.SqlDBPassword);Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30"`
			-ClientAccessName "$($config.$env.RDBrokerDNSInternalName).$($config.$env.RDBrokerDNSInternalZone)"
			#parameter DatabaseFilePath not needed.
			#-DatabaseFilePath  $config.$env.SQLFilePath
			Write-Verbose "Configured RDSBroker High Availablilty"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 14 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 14 Failed.  This step may need to be re-run without the reboots happening immediately prior"
		break
	}
}

if (($startPoint -le 15) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 15 Start>>>>>>>>>>>>>>>"
		# Configure GW Policies on RDGatewayServer01
		Invoke-Command -ComputerName $config.$env.RDGatewayServer01 -ArgumentList "$($config.$env.GatewayAccessGroup)@$($config.$env.DomainController)","AAD DC Administrators@$($config.$env.DomainController)", $config.$env.RDBrokerDNSInternalName, $config.$env.RDBrokerDNSInternalZone, $config.$env.RDSHost01, $config.$env.RDSHost02, "RDG_CAP_$($config.$env.DesktopCollectionName)","RDG_RAP_$($config.$env.DesktopCollectionName)","RDG_$($config.$env.DesktopCollectionName)", $config.$env.ConnectionBroker01, $config.$env.ConnectionBroker02 -ScriptBlock {
			$GatewayAccessGroupEng = $args[0]
			$GatewayAccessGroupAdmins = $args[1]
			$RDBrokerDNSInternalName = $args[2]
			$RDBrokerDNSInternalZone = $args[3]
			$RDSHost01 = $args[4]
			$RDSHost02 = $args[5]
			$GatewayAccessCAPName = $args[6]
			$GatewayAccessRAPName = $args[7]
			$GatewayAccessGroupName = $args[8]
			$CB1 = $args[9]
			$CB2 = $args[10]
			Import-Module RemoteDesktopServices
			Remove-Item -Path "RDS:\GatewayServer\CAP\RDG_CAP_AllUsers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\RAP\RDG_HighAvailabilityBroker_DNS_RR" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\RAP\RDG_RDConnectionBrokers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\RAP\RDG_AllDomainComputers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item  -Path "RDS:\GatewayServer\GatewayManagedComputerGroups\RDG_RDCBComputers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item  -Path "RDS:\GatewayServer\GatewayManagedComputerGroups\RDG_DNSRoundRobin" -Force -recurse -ErrorAction SilentlyContinue
			New-Item -Path "RDS:\GatewayServer\GatewayManagedComputerGroups" -Name $GatewayAccessGroupName -Description "GovCloud" -Computers "$RDBrokerDNSInternalName.$RDBrokerDNSInternalZone",$RDSHost01,$RDSHost02,$CB1,$CB2 -ItemType "String" -ErrorAction SilentlyContinue
			New-Item -Path "RDS:\GatewayServer\RAP" -Name $GatewayAccessRAPName -UserGroups $GatewayAccessGroupAdmins,$GatewayAccessGroupEng -ComputerGroupType 0 -ComputerGroup $GatewayAccessGroupName -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\CAP\$($GatewayAccessCAPName)" -Force -recurse -ErrorAction SilentlyContinue
			New-Item -Path "RDS:\GatewayServer\CAP" -Name $GatewayAccessCAPName -UserGroups $GatewayAccessGroupAdmins,$GatewayAccessGroupEng -AuthMethod 1 -ErrorAction SilentlyContinue
		}
		Write-Verbose "Configured CAP & RAP Policies on: $($config.$env.RDGatewayServer01)"  -Verbose	
		Write-Host "<<<<<<<<<<<<<<<Step 15 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 15 Failed"
		break
	}
}

if (($startPoint -le 16) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 16 Start>>>>>>>>>>>>>>>"
		Add-RDServer -Server $config.$env.ConnectionBroker02 -Role "RDS-CONNECTION-BROKER" -ConnectionBroker $config.$env.ConnectionBroker01
		Write-Verbose "Joined Broker Server: $($config.$env.ConnectionBroker02)"  -Verbose

		#Reboot ConnectionBroker02 (without Reboot, there can occur errors with the next commands)
		Write-Verbose "$($config.$env.ConnectionBroker02) will reboot"  -Verbose
		Restart-Computer -ComputerName $config.$env.ConnectionBroker02 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
		Write-Verbose "$($config.$env.ConnectionBroker02) online again"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 16 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 16 Failed"
		break
	}
}

if (($startPoint -le 17) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 17 Start>>>>>>>>>>>>>>>"
		#Join WebAccess02
		#Determine ActiveBroker
		$primaryBroker = (Get-RDConnectionBrokerHighAvailability -ConnectionBroker $config.$env.ConnectionBroker01).ActiveManagementServer
		Add-RDServer -Server $config.$env.WebAccessServer02 -Role "RDS-WEB-ACCESS" -ConnectionBroker $primaryBroker
		Write-Verbose "Joined WebAccess Server:  $($config.$env.ConnectionBroker02)"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 17 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 17 Failed"
		break
	}
}

if (($startPoint -le 18) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 18 Start>>>>>>>>>>>>>>>"
		#Join RDGatewayServer02
		#Determine ActiveBroker
		$primaryBroker = (Get-RDConnectionBrokerHighAvailability -ConnectionBroker $config.$env.ConnectionBroker01).ActiveManagementServer
		Add-RDServer -Server $config.$env.RDGatewayServer02 -Role "RDS-GATEWAY" -ConnectionBroker $primaryBroker -GatewayExternalFqdn $config.$env.GatewayInternalFqdn
		Write-Verbose "Joined Gateway Server:  $($config.$env.ConnectionBroker02)"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 18 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 18 Failed"
		break
	}
}

if (($startPoint -le 19) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 19 Start>>>>>>>>>>>>>>>"
		# Configure GW Policies on RDGatewayServer02
		Invoke-Command -ComputerName $config.$env.RDGatewayServer02 -ArgumentList "$($config.$env.GatewayAccessGroup)@$($config.$env.DomainController)","AAD DC Administrators@$($config.$env.DomainController)", $config.$env.RDBrokerDNSInternalName, $config.$env.RDBrokerDNSInternalZone, $config.$env.RDSHost01, $config.$env.RDSHost02, "RDG_CAP_$($config.$env.DesktopCollectionName)","RDG_RAP_$($config.$env.DesktopCollectionName)","RDG_$($config.$env.DesktopCollectionName)", $config.$env.ConnectionBroker01, $config.$env.ConnectionBroker02 -ScriptBlock {
			$GatewayAccessGroupEng = $args[0]
			$GatewayAccessGroupAdmins = $args[1]
			$RDBrokerDNSInternalName = $args[2]
			$RDBrokerDNSInternalZone = $args[3]
			$RDSHost01 = $args[4]
			$RDSHost02 = $args[5]
			$GatewayAccessCAPName = $args[6]
			$GatewayAccessRAPName = $args[7]
			$GatewayAccessGroupName = $args[8]
			$CB1 = $args[9]
			$CB2 = $args[10]
			Import-Module RemoteDesktopServices
			Remove-Item -Path "RDS:\GatewayServer\CAP\RDG_CAP_AllUsers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\RAP\RDG_HighAvailabilityBroker_DNS_RR" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\RAP\RDG_RDConnectionBrokers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\RAP\RDG_AllDomainComputers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item  -Path "RDS:\GatewayServer\GatewayManagedComputerGroups\RDG_RDCBComputers" -Force -recurse -ErrorAction SilentlyContinue
			Remove-Item  -Path "RDS:\GatewayServer\GatewayManagedComputerGroups\RDG_DNSRoundRobin" -Force -recurse -ErrorAction SilentlyContinue
			New-Item -Path "RDS:\GatewayServer\GatewayManagedComputerGroups" -Name $GatewayAccessGroupName -Description "GovCloud" -Computers "$RDBrokerDNSInternalName.$RDBrokerDNSInternalZone",$RDSHost01,$RDSHost02,$CB1,$CB2 -ItemType "String" -ErrorAction SilentlyContinue
			New-Item -Path "RDS:\GatewayServer\RAP" -Name $GatewayAccessRAPName -UserGroups $GatewayAccessGroupAdmins,$GatewayAccessGroupEng -ComputerGroupType 0 -ComputerGroup $GatewayAccessGroupName -ErrorAction SilentlyContinue
			Remove-Item -Path "RDS:\GatewayServer\CAP\$($GatewayAccessCAPName)" -Force -recurse -ErrorAction SilentlyContinue
			New-Item -Path "RDS:\GatewayServer\CAP" -Name $GatewayAccessCAPName -UserGroups $GatewayAccessGroupAdmins,$GatewayAccessGroupEng -AuthMethod 1 -ErrorAction SilentlyContinue
		}
		Write-Verbose "Configured CAP & RAP Policies on: $($config.$env.RDGatewayServer02)"  -Verbose	
		Write-Host "<<<<<<<<<<<<<<<Step 19 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 19 Failed"
		break
	}
}

if (($startPoint -le 20) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 20 Start>>>>>>>>>>>>>>>"
		#Redirect to RDWeb (IIS)
		Invoke-Command -ComputerName $config.$env.WebAccessServer02 -ArgumentList $config.$env.RDWebAccessDNSInternalName, $config.$env.RDWebAccessDNSInternalZone  -ScriptBlock {
			$RDWebAccessDNSInternalName = $args[0]
			$RDWebAccessDNSInternalZone = $args[1]
			$siteName = "Default Web Site"
			Import-Module webAdministration
			Set-WebConfiguration system.webServer/httpRedirect "IIS:\sites\$siteName" -Value @{enabled="true";destination="https://$RDWebAccessDNSInternalName.$RDWebAccessDNSInternalZone/RDWeb";exactDestination="true";httpResponseStatus="Found";childOnly="true"} 
		} #end Redirect to RDWeb
		Write-Verbose "Configured RDWeb Redirect"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 20 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 20 Failed"
		break
	}
}

if (($startPoint -le 21) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 21 Start>>>>>>>>>>>>>>>"
		#Create Gateway Farm on RDGatewayServer01
		Invoke-Command -ComputerName $config.$env.RDGatewayServer01 -ArgumentList $config.$env.RDGatewayServer01, $config.$env.RDGatewayServer02 -ScriptBlock {
			$RDGatewayServer01 = $args[0]
			$RDGatewayServer02 = $args[1]
			Import-Module RemoteDesktopServices
			New-Item -Path "RDS:\GatewayServer\GatewayFarm\Servers" -Name $RDGatewayServer01 -ItemType "String"
			New-Item -Path "RDS:\GatewayServer\GatewayFarm\Servers" -Name $RDGatewayServer02 -ItemType "String"
		} #end invoke Create Gateway Farm on RDGatewayServer01
		Write-Verbose "Created Gateway Server Farm on: $($config.$env.RDGatewayServer01)"  -Verbose

		#Create Gateway Farm on RDGatewayServer02
		Invoke-Command -ComputerName $config.$env.RDGatewayServer02 -ArgumentList $config.$env.RDGatewayServer01, $config.$env.RDGatewayServer02 -ScriptBlock {
			$RDGatewayServer01 = $args[0]
			$RDGatewayServer02 = $args[1]
			Import-Module RemoteDesktopServices
			New-Item -Path "RDS:\GatewayServer\GatewayFarm\Servers" -Name $RDGatewayServer01 -ItemType "String"
			New-Item -Path "RDS:\GatewayServer\GatewayFarm\Servers" -Name $RDGatewayServer02 -ItemType "String"
		} #end invoke Create Gateway Farm on RDGatewayServer01
		Write-Verbose "Created Gateway Server Farm on: $($config.$env.RDGatewayServer02)"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 21 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 21 Failed"
		break
	}
}

if (($startPoint -le 22) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 22 Start>>>>>>>>>>>>>>>"
		#CONFIGURE MACHINE KEYS FOR GATEWAY Servers
		remove-item "$($scriptPath)\cmk.ps1" -ErrorAction SilentlyContinue
		$content = get-content "$($scriptPath)\Configure-MachineKeys.ps1"
		$content = $content -replace 'Test-Connection -ComputerName \$ComputerName -Count 1 -Quiet','Test-NetConnection -ComputerName $ComputerName -Port 5985'
		$content | out-file "$($scriptPath)\cmk.ps1"
        start-process -FilePath "powershell" -ArgumentList "$($scriptPath)\cmk.ps1 -ComputerName $($config.$env.WebAccessServer01), $($config.$env.WebAccessServer02) -Mode Write" -Wait
		remove-item "$($scriptPath)\cmk.ps1"
		Write-Verbose "Configured Machine Keys for Gateway Servers"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 22 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 22 Failed"
		break
	}
}

if (($startPoint -le 23) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 23 Start>>>>>>>>>>>>>>>"
		# RDS Licensing for Connection Broker 01 and 02
		#Determine ActiveBroker
		$primaryBroker = (Get-RDConnectionBrokerHighAvailability -ConnectionBroker $config.$env.ConnectionBroker01).ActiveManagementServer
		Add-RDServer -Server $config.$env.LICserver02 -Role "RDS-LICENSING" -ConnectionBroker $primaryBroker
		Write-Verbose "Installed RDS Licence Server: $($config.$env.LICserver02)"  -Verbose
		Set-RDLicenseConfiguration -LicenseServer $config.$env.LICserver01,$config.$env.LICserver02 -Mode $config.$env.LICmode -ConnectionBroker $primaryBroker -Force
		Write-Verbose "Configured RDS Licening"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 23 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 23 Failed"
		break
	}
}

if (($startPoint -le 24) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 24 Start>>>>>>>>>>>>>>>"
		# Update Certificates
		$Password = ConvertTo-SecureString -String $config.$env.CertPassword -AsPlainText -Force 
		Set-RDCertificate -Role RDPublishing -ImportPath $config.$env.CertPath  -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Set-RDCertificate -Role RDRedirector -ImportPath $config.$env.CertPath -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Set-RDCertificate -Role RDWebAccess -ImportPath $config.$env.CertPath -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Set-RDCertificate -Role RDGateway -ImportPath $config.$env.CertPath  -Password $Password -ConnectionBroker $config.$env.ConnectionBroker01 -Force
		Write-Verbose "Configured SSL Certificates"  -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 24 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 24 Failed"
		break
	}
}
##******************************************************************************************************************************************************
##******************************************************************************************************************************************************
function EnableAADAuth
{
	param (
		[string] $share_rgName,
		[string] $share_storageAccountName
	)
	import-module AzFilesHybrid
	Join-AzStorageAccountForAuth -ResourceGroupName $share_rgName -Name $share_storageAccountName -DomainAccountType "ComputerAccount" 
}
function FileShareSetup 
{
	param (
		[string] $share_rgName,
		[string] $share_storageAccountName,
		[string] $shareName,
		[string] $groupAccess,
		[string] $permissions,
        [string] $groupAccessAdmins,
        [string] $permissionsAdmins,
        [string] $subscriptionId
	)
	Write-Host "--------------------"
	Write-Host $share_rgName
	Write-Host $share_storageAccountName
	Write-Host $shareName
	Write-Host $groupAccess
	Write-Host $subscriptionId
	Write-Host "--------------------"

	$groupNameOnly = ($groupAccess -split '\\')[1]
	Write-Host "Group Name Only: "$groupNameOnly
	$share_storageAccountName = $share_storageAccountName.ToLower()
	$shareName = $sharename.ToLower()

	$rg = Get-AzResourceGroup -Name $share_rgName -erroraction SilentlyContinue
	$stg = Get-AzStorageAccount -Name $share_storageAccountName -ResourceGroupName $share_rgName -erroraction SilentlyContinue

	$share_storageAccountKey = (get-azstorageaccountkey -resourcegroupname $share_rgName -accountname $share_storageAccountName)[0].value

	$stgcontext = New-AzStorageContext -StorageAccountName $share_storageAccountName -storageaccountkey $share_storageAccountKey
	$stgcontext
	
	New-AzRmStorageShare -ResourceGroupName $share_rgName -StorageAccountName $share_storageAccountName -Name $shareName -QuotaGiB 5120
	
	$groupId = (get-AzAdgroup -searchstring $groupNameOnly).id
	$groupId

	$key = ConvertTo-SecureString -String $share_storageAccountKey -AsPlainText -Force
	$arg = "Azure\" + $share_storageAccountName
	$credential = New-Object System.Management.Automation.PSCredential -ArgumentList $arg, $key
	$path = "\\" + $share_storageAccountName + ".file.core.usgovcloudapi.net\" + $shareName
	Write-Host "Path: "$path
	New-PSDrive -Name X -PSProvider FileSystem -Root $path -Credential $credential -Persist
	
	icacls X:
	icacls X: /remove "BUILTIN\Users"
	icacls X: /remove "BUILTIN\Administrators"
	icacls X: /remove "NT AUTHORITY\Authenticated Users"
	icacls X: /remove "CREATOR OWNER"

	icacls X: /inheritance:r
	#get-azurermroleassignment -resourcegroupname $rgName | where {$_.RoleDefinitionName -like "*SMB*"}
	#Role below allows AAD DC Administrators to use AAD Authentication to access the file share however AAD Auth is not yet implemented in Azure Gov
	#The role assignment does complete successfully however
	$fsr = Get-AzRoleDefinition "Storage File Data SMB Share Contributor"
	$scope = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $share_rgName + "/providers/Microsoft.Storage/storageAccounts/" + $share_storageAccountName + "/fileServices/default/fileshares/" + $shareName
	New-AzRoleAssignment -ObjectId $groupId -RoleDefinitionName $fsr.Name -Scope $scope

	$cmd = "icacls X: /grant ""$($groupAccessAdmins)"":$($permissionsAdmins)"
	cmd /c $cmd
    $cmd = "icacls X: /grant ""$($groupAccess)"":$($permissions)"
	cmd /c $cmd

	write-host "------------------------------"
	icacls X:
	Remove-PSDrive -Name X
	#Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $share_rgName -Name $share_storageAccountName -DefaultAction Deny  //Terraform is setting Deny, mgmt, rdssvcs subnets allowed.
}

function DiskSetup
{
	###INITIALIZE THE DISKS ON THE SESSION HOSTS AND SET PERMISSIONS###
	$createDisksScript = @"
`$disks = Get-Disk | Where partitionstyle -eq 'raw' | Sort Number 
`$disks[0] | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "P" -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "Profiles" -Confirm:`$false
`$disks[1] | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "Z" -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "FileShare" -Confirm:`$false
net stop server /y
net start server /y
"@
	$cds = [Scriptblock]::Create($createDisksScript)
	Invoke-Command -ComputerName $config.$env.RDShost01 -ScriptBlock $cds
	Invoke-Command -ComputerName $config.$env.RDShost02 -ScriptBlock $cds

		$cmd = "net use P: \\$($config.$env.RDShost01)\p$"
		cmd /c $cmd
		$cmd = "net use Z: \\$($config.$env.RDShost01)\z$"
		cmd /c $cmd
		$cmd = "net use A: \\$($config.$env.RDShost02)\p$"
		cmd /c $cmd
		$cmd = "net use B: \\$($config.$env.RDShost02)\z$"
		cmd /c $cmd	

		$cmd = "icacls P: /grant ""$($config.$env.DomainController)\AAD DC Administrators:(OI)(CI)(F)"""
		cmd /c $cmd
		$cmd = "icacls P: /grant ""$($config.$env.DomainController)\$($config.$env.RDSAccessGroup):(OI)(CI)(RX,W)"""
		cmd /c $cmd
		icacls P: /remove "BUILTIN\Users"
		icacls P: /remove "NT AUTHORITY\Authenticated Users"
		icacls P: /remove "CREATOR OWNER"
		icacls P: /remove "Everyone"
		icacls P: /inheritance:e
		icacls P:
		
		$cmd = "icacls Z: /grant ""$($config.$env.DomainController)\AAD DC Administrators:(OI)(CI)(F)"""
		cmd /c $cmd
		$cmd = "icacls Z: /grant ""$($config.$env.DomainController)\$($config.$env.RDSAccessGroup):(OI)(CI)(M)"""
		cmd /c $cmd
		icacls Z: /remove "BUILTIN\Users"
		icacls Z: /remove "NT AUTHORITY\Authenticated Users"
		icacls Z: /remove "CREATOR OWNER"
		icacls Z: /remove "Everyone"
		icacls Z: /inheritance:e
		icacls Z:
		
		$cmd = "icacls A: /grant ""$($config.$env.DomainController)\AAD DC Administrators:(OI)(CI)(F)"""
		cmd /c $cmd
		$cmd = "icacls A: /grant ""$($config.$env.DomainController)\$($config.$env.RDSAccessGroup):(OI)(CI)(RX,W)"""
		cmd /c $cmd
		icacls A: /remove "BUILTIN\Users"
		icacls A: /remove "NT AUTHORITY\Authenticated Users"
		icacls A: /remove "CREATOR OWNER"
		icacls A: /remove "Everyone"
		icacls A: /inheritance:e
		icacls A:
		
		$cmd = "icacls B: /grant ""$($config.$env.DomainController)\AAD DC Administrators:(OI)(CI)(F)"""
		cmd /c $cmd
		$cmd = "icacls B: /grant ""$($config.$env.DomainController)\$($config.$env.RDSAccessGroup):(OI)(CI)(M)"""
		cmd /c $cmd
		icacls B: /remove "BUILTIN\Users"
		icacls B: /remove "NT AUTHORITY\Authenticated Users"
		icacls B: /remove "CREATOR OWNER"
		icacls B: /remove "Everyone"
		icacls B: /inheritance:e
		icacls B:
	net use P: /delete
	net use Z: /delete
	net use A: /delete
	net use B: /delete
}

##CONFIGURE THE FILE SHARE PERMISSIONS
if (($startPoint -le 25) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 25 Start>>>>>>>>>>>>>>>"
		Write-Verbose "Configuring the Azure File Shares" -Verbose

		$grpAccess = $config.$env.DomainController

		$grpAccess = ($grpAccess -split '\.')[0]
		$grpAccessAdmins = ($grpAccess -split '\.')[0]

		$grpAccess = $grpAccess + "\" + $config.$env.RDSAccessGroup
		$grpAccessAdmins = $grpAccessAdmins + "\AAD DC Administrators"

		$profileShare = $config.$env.DesktopCollectionName + "-profiles"
		$fileShare = $config.$env.DesktopCollectionName + "-fileshare"

		$permissionsAdmins = "(OI)(CI)(F)"

		$permissions = "(OI)(CI)(RX,W)"
		FileShareSetup $config.$env.ResourceGroup $config.$env.StorageAccountName $profileShare $grpAccess $permissions $grpAccessAdmins $permissionsAdmins $config.$env.SubscriptionId

		$permissions = "(OI)(CI)(M)"
		FileShareSetup $config.$env.ResourceGroup $config.$env.StorageAccountName $fileShare $grpAccess $permissions $grpAccessAdmins $permissionsAdmins $config.$env.SubscriptionId

		Write-Verbose "File Share Setup Complete" -Verbose
		###EnableAADAuth $config.$env.ResourceGroup $config.$env.StorageAccountName
		Write-Host "<<<<<<<<<<<<<<<Step 25 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 25 Failed"
		break
	}
}

##INITILIZE THE SESSION HOST DATA DISKS AND SET PERMISSIONS
if (($startPoint -le 26) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 26 Start>>>>>>>>>>>>>>>"
		Write-Verbose "Configuring Session Host Data Disks and Setting Permissions" -Verbose
		DiskSetup
		Write-Verbose "Disk Setup Complete" -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 26 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 26 Failed"
		break
	}
}

###CREATE THE SYNC SERVICE###
if (($startPoint -le 27) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 27 Start>>>>>>>>>>>>>>>"
		Write-Host "Creating Storage Sync Service"
		New-AzStorageSyncService -StorageSyncServiceName $config.$env.StorageSyncServicename -ResourceGroupName $config.$env.ResourceGroup -Location "usgovvirginia" -ErrorAction SilentlyContinue
		Write-Host "<<<<<<<<<<<<<<<Step 27 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 27 Failed"
		break
	}
}

###REGISTER THE SESSION HOSTS WITH THE SYNC SERVICE###
if (($startPoint -le 28) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 28 Start>>>>>>>>>>>>>>>"
$registerFileSyncScript = @"

`$username = `"$($config.$env.DevOpsAppId)`"
`$password = `"$($config.$env.DevOpsPassword)`"
`$subscription = `"$($config.$env.SubscriptionName)`"
`$region = `"usgovvirginia`"
`$resourceGroup = `"$($config.$env.ResourceGroup)`"
`$storageSyncName = `"$($config.$env.StorageSyncServiceName)`"
`$secpasswd = ConvertTo-SecureString `$password -AsPlainText -Force
`$creds = New-Object System.Management.Automation.PSCredential (`$username, `$secpasswd)
Import-Module Az
Add-AzAccount -Credential `$creds -Environment `'AzureUSGovernment`' -ServicePrincipal -TenantId `"$($config.$env.TenantId)`"
`$sub = Get-AzSubscription -SubscriptionName `$subscription
Set-AzContext -SubscriptionName `$sub.Name

`$subId = (Get-AzSubscription -SubscriptionName `$subscription).Id
`$tenantId = (Get-AzSubscription -SubscriptionName `$subscription).TenantId

##Configure the Agent
`$agentPath = `'C:\Program Files\Azure\StorageSyncAgent`' ## Make sure to change this if the default path was not used
Import-Module `"`$agentPath\StorageSync.Management.PowerShell.Cmdlets.dll`"
`$creds = New-Object System.Management.Automation.PSCredential (`$username, `$secpasswd)
Invoke-Command -ScriptBlock {Import-Module `"`$agentPath\StorageSync.Management.PowerShell.Cmdlets.dll`" ; Login-AzureRmStorageSync -Credential `$creds -SubscriptionId `$subId -ResourceGroupName `$resourceGroup -TenantId `$tenantID -Location `$region -ErrorAction SilentlyContinue}

`$c = get-command Register-AzStorageSyncServer -ErrorAction SilentlyContinue
if (`$c -eq `$null)
{
`$registeredServer = Register-AzureRmStorageSyncServer -StorageSyncServiceName `$storageSyncName -ResourceGroupName `$resourceGroup
}
else
{
`$registeredServer = Register-AzStorageSyncServer -StorageSyncServiceName `$storageSyncName -ResourceGroupName `$resourceGroup
}
"@
		$registerFileSyncScript
		$rfs = [Scriptblock]::Create($registerFileSyncScript)
		Invoke-Command -ComputerName $config.$env.RDSHost01 -ScriptBlock $rfs
		Invoke-Command -ComputerName $config.$env.RDSHost02 -ScriptBlock $rfs
		Write-Host "<<<<<<<<<<<<<<<Step 28 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 28 Failed"
		break
	}
}

###CONFIGURE SYNC SERVICE ENDPOINTS###
if (($startPoint -le 29) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 29 Start>>>>>>>>>>>>>>>"
		$resourceGroup = $config.$env.ResourceGroup
		$resourceGroupStgAcct = $config.$env.ResourceGroup 
		$storageSyncName = $config.$env.StorageSyncServiceName
		$sgProfiles = $config.$env.DesktopCollectionName.ToLower() + "-profiles"
		$sgFileShare = $config.$env.DesktopCollectionName.ToLower() + "-fileshare"
		$syncGroupNameProfiles = $sgProfiles
		$syncGroupNameFileshare = $sgFileShare
		$storageAccountName = $config.$env.StorageAccountName
		$snProfiles = $config.$env.DesktopCollectionName.ToLower() + "-profiles"
		$snFileShare = $config.$env.DesktopCollectionName.ToLower() + "-fileshare"
		$shareNameProfiles = $snProfiles
		$ShareNameFileshare = $snFileShare
		$serverEndpointPathProfiles = "P:\"
		$serverEndpointPathFileshare = "Z:\"

		$storageAccount = Get-AzStorageAccount -ResourceGroupName $resourceGroupStgAcct -Name $storageAccountName

		$storageKey = (Get-AzStorageAccountKey -ResourceGroupName $storageAccount.ResourceGroupName -Name $storageAccount.StorageAccountName | select -first 1).Value
		$storageContext = New-AzStorageContext -StorageAccountName $storageAccount.StorageAccountName -StorageAccountKey $storageKey

		Write-Host "Create Sync Group"
		$storageSyncService = Get-AzStorageSyncService -ResourceGroupName $resourceGroup -Name $storageSyncName
		New-AzStorageSyncGroup -SyncGroupName $syncGroupNameProfiles -StorageSyncService $storageSyncService
		New-AzStorageSyncGroup -SyncGroupName $syncGroupNameFileshare -StorageSyncService $storageSyncService

		Write-Host "Create Cloud Endpoint"
		$cen = $storageAccountName + "_" + $shareName
		New-AzStorageSyncCloudEndpoint -StorageSyncServiceName $storageSyncName -SyncGroupName $syncGroupNameProfiles -StorageAccountResourceId $storageAccount.Id -StorageAccountShareName $shareNameProfiles -ResourceGroupName $resourceGroup -Name $cen
		New-AzStorageSyncCloudEndpoint -StorageSyncServiceName $storageSyncName -SyncGroupName $syncGroupNameFileshare -StorageAccountResourceId $storageAccount.Id -StorageAccountShareName $shareNameFileshare -ResourceGroupName $resourceGroup -Name $cen

		Write-Host "Create Server Endpoint"
		#regServers = Get-AzStorageSyncServer -ResourceGroupName $resourceGroup -StorageSyncServiceName $storageSyncName
		$regServers = Get-AzStorageSyncServer -ResourceGroupName RGP-UGV-CORE-RDS-DV -StorageSyncServiceName $storageSyncName | where {($_.FriendlyName -like "$($config.$env.RDSHost01)") -or ($_.FriendlyName -like "$($config.$env.RDSHost02)")}
		$sep = $serverEndpointPathProfiles -replace '\\',''
		$sep = $sep -replace ':',''
		foreach ($rs in $regServers)
		{
			$sen = $rs.FriendlyName + "_" + $sep
			New-AzStorageSyncServerEndpoint -ResourceGroupName $resourceGroup -StorageSyncServiceName $storageSyncName -SyncGroupName $syncGroupNameProfiles -ServerResourceId $rs.ResourceId -ServerLocalPath $serverEndpointPathProfiles -Name $sen -ErrorAction Stop
		}
		$sep = $serverEndpointPathFileshare -replace '\\',''
		$sep = $sep -replace ':',''
		foreach ($rs in $regServers)
		{
			$sen = $rs.FriendlyName + "_" + $sep
			New-AzStorageSyncServerEndpoint -ResourceGroupName $resourceGroup -StorageSyncServiceName $storageSyncName -SyncGroupName $syncGroupNameFileshare -ServerResourceId $rs.ResourceId -ServerLocalPath $serverEndpointPathFileshare -Name $sen -ErrorAction Stop
		}
		Write-Host "<<<<<<<<<<<<<<<Step 29 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 29 Failed"
		break
	}
}

###CREATE FSLOGIX REGISTRY SETTINGS###
if (($startPoint -le 30) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 30 Start>>>>>>>>>>>>>>>"
$fslogixScript = @"
Push-Location
Set-Location HKLM:
if (!(Test-Path .\SOFTWARE\FSLogix\Profiles))
{
if (!(Test-Path .\SOFTWARE\FSLogix))
{
New-Item -Path .\SOFTWARE\FSLogix
}
New-Item -Path .\SOFTWARE\FSLogix\Profiles
}
Pop-Location

New-ItemProperty -Path `"HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer`" -Name `"NoDrives`" -Value 32768 -PropertyType Dword -Force -ErrorAction SilentlyContinue
New-ItemProperty -Path `"HKLM:\Software\FSLogix\Profiles`" -Name `"Enabled`" -Value 1 -PropertyType DWord -Force -ErrorAction SilentlyContinue
New-ItemProperty -Path `"HKLM:\Software\FSLogix\Profiles`" -Name `"VHDLocations`" -Value `"P:\`" -PropertyType Multistring -Force -ErrorAction SilentlyContinue
New-ItemProperty -Path `"HKLM:\Software\FSLogix\Profiles`" -Name `"DeleteLocalProfileWhenVHDShouldApply`" -Value 1 -PropertyType DWord -Force -ErrorAction SilentlyContinue
`$cmd = "taskkill /f /im explorer.exe"
cmd /c `$cmd
Start-Process "c:\windows\explorer.exe"
"@
		$fs = [Scriptblock]::Create($fslogixScript)
		Invoke-Command -ComputerName $config.$env.RDSHost01 -ScriptBlock $fs
		Invoke-Command -ComputerName $config.$env.RDSHost02 -ScriptBlock $fs
		Write-Verbose "NOTE: Ignore any explorer.exe not found errors" -Verbose
		Write-Host "<<<<<<<<<<<<<<<Step 30 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 30 Failed"
		break
	}
}

if (($startPoint -le 31) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 31 Start>>>>>>>>>>>>>>>"
		Write-Host "Encrypting Session Host Data Disks"
		$kv = Get-AzKeyVault $config.$env.KeyVaultVMEncrypt
		#Reboot Session Hosts To Encrypt Data Disks 
		Write-Verbose "$($config.$env.RDSHost01) will reboot"  -Verbose
		Restart-Computer -ComputerName $config.$env.RDSHost01 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
		Write-Verbose "$($config.$env.RDSHost01) online again"  -Verbose
		$sequenceVersion = [Guid]::NewGuid()
		Set-AzVMDiskEncryptionExtension -ResourceGroupName $config.$env.ResourceGroup -VMName ($config.$env.RDShost01 -split '\.')[0] -DiskEncryptionKeyVaultUrl $kv.VaultUri -DiskEncryptionKeyVaultId $kv.ResourceId -Confirm:$false -Force -ErrorAction Stop -SequenceVersion $sequenceVersion

		Write-Verbose "$($config.$env.RDSHost02) will reboot"  -Verbose
		Restart-Computer -ComputerName $config.$env.RDSHost02 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
		Write-Verbose "$($config.$env.RDSHost02) online again"  -Verbose
		$sequenceVersion = [Guid]::NewGuid()
		Set-AzVMDiskEncryptionExtension -ResourceGroupName $config.$env.ResourceGroup -VMName ($config.$env.RDShost02 -split '\.')[0] -DiskEncryptionKeyVaultUrl $kv.VaultUri -DiskEncryptionKeyVaultId $kv.ResourceId -Confirm:$false -Force -ErrorAction Stop -SequenceVersion $sequenceVersion
		Write-Host "<<<<<<<<<<<<<<<Step 31 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 31 Failed"
		break
	}
}


if (($startPoint -le 32) -and ($startPoint -le $endPoint))
{
	try
	{
        Write-Host "<<<<<<<<<<<<<<<Step 32 Start>>>>>>>>>>>>>>>"
		# Configure Gateway Server Settings
        $appProxyUrl = $config.$env.AppProxyUrl
        $appproxyurl = $appproxyurl -replace "https://",""
        $primaryBroker = (Get-RDConnectionBrokerHighAvailability -ConnectionBroker $config.$env.ConnectionBroker01).ActiveManagementServer
		Set-RDDeploymentGatewayConfiguration -GatewayMode Custom -GatewayExternalFqdn $appProxyUrl -LogonMethod Password -UseCachedCredentials $True -BypassLocal $False -ConnectionBroker $primaryBroker -Force
		Write-Host "<<<<<<<<<<<<<<<Step 32 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 32 Failed"
		break
	}
}

if (($startPoint -le 33) -and ($startPoint -le $endPoint))
{
	try
	{
		### This does not work properly (possibly due to government region)
		# Grant Access to AAD DC Administrators and RDSAccessGroup to the App Proxy application
		Write-Host "<<<<<<<<<<<<<<<Step 33 Start>>>>>>>>>>>>>>>"
		Write-Verbose "Enter Azure Credentials" -Verbose
		Connect-AzureAD -AzureEnvironmentName 'AzureUSGovernment'
		$sp = Get-AzureADApplication -All $true -Filter "displayName eq 'rds'"
		$group = Get-AzureADGroup -SearchString "$($config.$env.GatewayAccessGroup)"
		New-AzureADGroupAppRoleAssignment -ObjectId $group.ObjectId -PrincipalId $group.ObjectId -ResourceId $sp.ObjectId -Id ([Guid]::Empty) -ErrorAction Stop
		Write-Host "<<<<<<<<<<<<<<<Step 33 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		$appGroupMessage = "Log in to the portal and grant access for: " + $config.$env.GatewayAccessGroup + " to the rds enterprise application"
	}
}


if (($startPoint -le 34) -and ($startPoint -le $endPoint))
{
	try
	{
		# Update RD Session Collection Configuration Pre-Authentication server to App Proxy address
		Write-Host "<<<<<<<<<<<<<<<Step 34 Start>>>>>>>>>>>>>>>"
        Write-Verbose "Update RD Session Collection Configuration Pre-Authentication server to App Proxy address" -Verbose
		$primaryBroker = (Get-RDConnectionBrokerHighAvailability -ConnectionBroker $config.$env.ConnectionBroker01).ActiveManagementServer
        $scriptContent = "Set-RDSessionCollectionConfiguration -CollectionName ""$($config.$env.DesktopCollectionName)"" -CustomRdpProperty ""pre-authentication server address:s:$($config.$env.AppProxyUrl)/``nrequire pre-authentication:i:1``nuse multimon:i:0"""
        $scriptContent | out-file "$($scriptPath)\scc.ps1" -Force
        Write-Host "NOTE-----> Log in to" $primaryBroker "and run the command found in $($scriptPath)\scc.ps1 in an administrative powershell session" -ForegroundColor Yellow
		if ($appGroupMessage -ne $null){Write-Host "NOTE----->" $appGroupMessage -ForegroundColor Yellow}
	    Write-Host "<<<<<<<<<<<<<<<Step 34 Complete>>>>>>>>>>>>>>>"
		$startPoint++
    }
	catch
	{
		Write-Host "Step 34 Failed"
		break
	}
}

###Disable fPromptForPassword (Reduce Logins)###
if (($startPoint -le 35) -and ($startPoint -le $endPoint))
{
	try
	{
		Write-Host "<<<<<<<<<<<<<<<Step 35 Start>>>>>>>>>>>>>>>"
$pfpScript = @"
New-ItemProperty -Path `"HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services`" -Name `"fPromptForPassword`" -Value 0 -PropertyType Dword -Force -ErrorAction SilentlyContinue
"@
		$pfp = [Scriptblock]::Create($pfpScript)
		Invoke-Command -ComputerName $config.$env.ConnectionBroker01 -ScriptBlock $pfp
		Invoke-Command -ComputerName $config.$env.ConnectionBroker02 -ScriptBlock $pfp
		Invoke-Command -ComputerName $config.$env.RDSHost01 -ScriptBlock $pfp
		Invoke-Command -ComputerName $config.$env.RDSHost02 -ScriptBlock $pfp
		Invoke-Command -ComputerName $config.$env.RDGatewayServer01 -ScriptBlock $pfp
		Invoke-Command -ComputerName $config.$env.RDGatewayServer02 -ScriptBlock $pfp
		Write-Host "<<<<<<<<<<<<<<<Step 35 Complete>>>>>>>>>>>>>>>"
		$startPoint++
	}
	catch
	{
		Write-Host "Step 35 Failed"
		break
	}
}

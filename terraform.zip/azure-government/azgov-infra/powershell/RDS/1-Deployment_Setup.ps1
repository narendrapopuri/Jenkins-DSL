$scriptPath = "c:\rds"
$rds_setup_sas = "https://stougvcoresoftwarepd.blob.core.usgovcloudapi.net/rds/RDS_Setup.zip?sp=r&st=2020-05-13T16:04:07Z&se=2020-12-11T01:04:07Z&spr=https&sv=2019-10-10&sr=b&sig=3i53mpI24kAIdgyfJ%2FnAGe%2BoWSVyHNDO6qCYKVB4kJg%3D"

#Requires -version 4.0
#Requires -RunAsAdministrator
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-ExecutionPolicy Undefined -Scope CurrentUser -Confirm:$false -force

$fanswer = Read-Host "Disable FIPS?  (Forces Restart) [yes/no]"
if ($fanswer -eq "yes")
{
	Set-ItemProperty -Path HKLM:\System\CurrentControlSet\Control\Lsa\FIPSAlgorithmPolicy -name Enabled -value 0 -ErrorAction SilentlyContinue
	Restart-Computer -Force
}

if (!(Test-Path "$($scriptPath)\RDS_Setup.zip"))
{
    Invoke-WebRequest -Uri $rds_setup_sas -OutFile "$($scriptPath)\RDS_Setup.zip"
}
if (Test-Path "$($scriptPath)\RDS_Setup.zip"){
	Write-Verbose "Downloaded RDS Setup" -Verbose
} Else {
	Write-Warning "Couldn't download RDS Setup"
	break
}

Write-Host "Disabling IE Enhanced Security"
function Disable-ieESC 
{
 $AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
 $UserKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
 Set-ItemProperty -Path $AdminKey -Name "IsInstalled" -Value 0
 Set-ItemProperty -Path $UserKey -Name "IsInstalled" -Value 0
 Stop-Process -Name Explorer -Force
 Write-Host "IE Enhanced Security Configuration (ESC) has been disabled." -ForegroundColor Green
 }

Disable-ieESC
Expand-Archive -LiteralPath "$($scriptPath)\RDS_Setup.zip" -DestinationPath $scriptpath -Force
Remove-Item "$($scriptPath)\RDS_Setup.zip"

mkdir "C:\Program Files\WindowsPowerShell\Modules" -ErrorAction SilentlyContinue
Copy-Item "$($scriptPath)\Az\*" "C:\Program Files\WindowsPowerShell\Modules" -Recurse -Force

mkdir "C:\ProgramData\Microsoft\Windows\PowerShell\PowerShellGet" -ErrorAction SilentlyContinue
Copy-Item "$($scriptPath)\nuget.exe" "C:\ProgramData\Microsoft\Windows\PowerShell\PowerShellGet" -Recurse -Force

mkdir "C:\Program Files\WindowsPowerShell\Modules\AzureAD" -ErrorAction SilentlyContinue
Copy-Item "$($scriptPath)\AzureAd\*" "C:\Program Files\WindowsPowerShell\Modules\AzureAd" -Recurse -Force

mkdir "C:\Program Files\WindowsPowerShell\Modules\AzFilesHybrid" -ErrorAction SilentlyContinue
Copy-Item "$($scriptPath)\AzFilesHybrid\*" "C:\Program Files\WindowsPowerShell\Modules\AzFilesHybrid" -Recurse -Force

mkdir "C:\Program Files\PackageManagement\ProviderAssemblies\nuget\2.8.5.201" -ErrorAction SilentlyContinue
Copy-Item "$($scriptPath)\Nuget\*" "C:\Program Files\PackageManagement\ProviderAssemblies\nuget" -Recurse -Force

Register-PSRepository -Name LocalPSRepo -SourceLocation 'c:\rds\' -ScriptSourceLocation 'c:\rds\' -InstallationPolicy Trusted

Write-Host "Updating PackageManagement Module"
install-module packagemanagement -force

Write-Host "Updating PowerShellGet Module"
install-module powershellget -force

#Write-Host "Installing Az.Accounts Module"
#install-module Az.Accounts -force

#Write-Host "Installing Az.Compute Module"
#install-module Az.Compute -force

remove-module PowerShellGet
remove-module PackageManagement

$deleteModulesScript = @"
@echo off
taskkill /F /IM "powershell.exe"
pause
rmdir "C:\Program Files\WindowsPowerShell\Modules\PackageManagement\1.0.0.1" /s /q
rmdir "C:\Program Files\WindowsPowerShell\Modules\PowerShellGet\1.0.0.1" /s /q
echo Finished Installing Modules
pause
exit
"@
$deleteModulesScript | out-file "$($scriptPath)\deletemodules.bat" -force -Encoding ASCII

start-process "$($scriptPath)\deletemodules.bat"

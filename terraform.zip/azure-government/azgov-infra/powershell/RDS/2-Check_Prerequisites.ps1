$env = "dv"
$scriptPath = "c:\rds"
#Requires -version 4.0
#Requires -RunAsAdministrator
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$configpath= "$($scriptPath)\config.json"
if (Test-Path $configpath) {
    Write-Verbose "JSON File was found." -Verbose
    $config = Get-Content -Path $configpath -Raw | ConvertFrom-Json
    Write-Verbose "JSON File was imported." -Verbose
} Else {
    Write-Warning "Failed to find the JSON File."
    break
} #end if Test-Path $configpath

function Test-PsRemoting {
    param(
        [Parameter(Mandatory = $true)]
        $computername
    )
   
    try
    {
        $errorActionPreference = "Stop"
        $result = Invoke-Command -ComputerName $computername { 1 }
    }
    catch
    {
        Write-Verbose $_
        return $false
    }
   
    ## I've never seen this happen, but if you want to be
    ## thorough....
    if($result -ne 1)
    {
        Write-Verbose "Remoting to $computerName returned an unexpected result."
        return $false
    }
   
    $true   
} # end Test-PsRemoting

### Disable Windows Firewall ###
$fanswer = Read-Host "Disable RD Host Firewalls? [yes/no]"
if ($fanswer -eq "yes")
{
	Write-Verbose "Enter Azure Credentials" -Verbose
    Add-AzAccount -Environment 'AzureUSGovernment'
    Start-Sleep -s 10
    $servers = "$($config.$env.RDGatewayServer01)","$($config.$env.RDGatewayServer02)","$($config.$env.ConnectionBroker01)","$($config.$env.ConnectionBroker02)","$($config.$env.RDSHost01)","$($config.$env.RDSHost02)"
	$dfscript = @"
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force	
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False
ipconfig /registerdns
"@
	$dfscript | out-file "$($scriptPath)\disablefirewall.ps1" -force
	foreach ($s in $servers)
	{
		$hostname = ($s -split '\.')[0]
		Write-Host $hostname
		$script = "Invoke-AzVMRunCommand -ResourceGroupName $($config.$env.ResourceGroup) -VMName $($hostname) -ScriptPath $($scriptPath)\disablefirewall.ps1 -CommandId RunPowerShellScript"
		$sb = [Scriptblock]::Create($script)
		Start-Job -ScriptBlock $sb
	}
	Get-Job | Wait-Job
	Write-Verbose "Firewall Disable Complete (Verify Results)" -Verbose
	remove-item "$($scriptPath)\disablefirewall.ps1"

    Write-Verbose "$($config.$env.RDGatewayServer01) will reboot"  -Verbose
    Restart-Computer -ComputerName $config.$env.GW1_IP -For PowerShell -Timeout 300 -Delay 2 -Force

    Write-Verbose "$($config.$env.RDGatewayServer02) will reboot"  -Verbose
    Restart-Computer -ComputerName $config.$env.GW2_IP -For PowerShell -Timeout 300 -Delay 2 -Force

    Write-Verbose "$($config.$env.ConnectionBroker01) will reboot"  -Verbose
    Restart-Computer -ComputerName $config.$env.CB1_IP -For PowerShell -Timeout 300 -Delay 2 -Force

    Write-Verbose "$($config.$env.ConnectionBroker02) will reboot"  -Verbose
    Restart-Computer -ComputerName $config.$env.CB2_IP -For PowerShell -Timeout 300 -Delay 2 -Force

    Write-Verbose "$($config.$env.RDSHost01) will reboot"  -Verbose
    Restart-Computer -ComputerName $config.$env.SH1_IP -For PowerShell -Timeout 300 -Delay 2 -Force

    Write-Verbose "$($config.$env.RDSHost02) will reboot"  -Verbose
    Restart-Computer -ComputerName $config.$env.SH2_IP -For PowerShell -Timeout 300 -Delay 2 -Force
	break
}

###Join RDS Servers to Domain
$danswer = Read-Host "Join Domain? [yes/no]"
if ($danswer -eq "yes")
{
	Write-Host "Joining RDS Servers to the domain"
	Write-Verbose "Enter Domain Credentials" -Verbose
	$domaincreds = get-credential

	$localsecpasswd = ConvertTo-SecureString $config.$env.RDSHostLocalPassword -AsPlainText -Force
	$localcreds = New-Object System.Management.Automation.PSCredential($config.$env.RDSHostLocalAccount,$localsecpasswd)

	add-computer -computername $config.$env.GW1_IP, $config.$env.GW2_IP, $config.$env.CB1_IP, $config.$env.CB2_IP, $config.$env.SH1_IP, $config.$env.SH2_IP -domainname $config.$env.DomainController -credential $domaincreds -LocalCredential $localcreds
	$hostList = $config.$env.GW1_IP,$config.$env.GW2_IP,$config.$env.CB1_IP,$config.$env.CB2_IP,$config.$env.SH1_IP,$config.$env.SH2_IP


    $user = $config.$env.RDSHostLocalAccount
	$password = $config.$env.RDSHostLocalPassword
foreach ($h in $hostList)
{
	$ip = $h
	$rscript = @"
`$user = "$ip\$user"
`$password = "$password"
`$secpassword = `$password | ConvertTo-SecureString -AsPlainText -Force
`$creds = New-Object -TypeName System.Management.Automation.PSCredential -Argumentlist `$user, `$secpassword
Restart-Computer -ComputerName $($ip) -Force -Credential `$creds
"@
	$rsb = [Scriptblock]::Create($rscript)
	Start-Job -ScriptBlock $rsb
}

Get-Job | Wait-Job
Write-Host "Domain Join Complete.  Re-run this script and choose ""no"" to check remaining prerequisites"
break
}

#enable SMB
Invoke-Command -ComputerName $config.$env.ConnectionBroker01 {
	Get-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" | Enable-NetFirewallRule
}
if(Test-Path "\\$($config.$env.ConnectionBroker01)\c$"){Write-Verbose "UNC path reachable"} else { Write-Warning "$($config.$env.ConnectionBroker01) UNC path is not reachable"; break}
Invoke-Command -ComputerName $config.$env.ConnectionBroker02 {
	Get-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" | Enable-NetFirewallRule
}
if(Test-Path "\\$($config.$env.ConnectionBroker02)\c$"){Write-Verbose "UNC path reachable"} else { Write-Warning "$($config.$env.ConnectionBroker02) UNC path is not reachable"; break}

    if(Test-PsRemoting -computername $config.$env.RDSHost01, $config.$env.RDSHost02, $config.$env.ConnectionBroker01, $config.$env.ConnectionBroker02, $config.$env.RDGatewayServer01, $config.$env.RDGatewayServer02){
        Write-Verbose "PSRemoting is enabled on all Hosts. MultiDeployment is ready" -Verbose
    } Else {
        Write-Warning "PSRemoting is not enabled on all Hosts. MultiDeployment is not ready!" 
        $PSRemoteMulti = @("$($config.$env.RDSHost01)","$($config.$env.RDSHost02)","$($config.$env.ConnectionBroker01)","$($config.$env.ConnectionBroker02)","$($config.$env.RDGatewayServer01)","$($config.$env.RDGatewayServer02)")
        foreach($TestMulti in $PSRemoteMulti){
            $status = Test-PsRemoting -computername $TestMulti; "$TestMulti;$status"
        }
        break
    } #end Test-PsRemoting MultiDeployment


### Create Self-Signed Certificate ###
Write-Verbose "Creating Certificate" -Verbose
$displayName = ($config.$env.DomainController -split '\.')[0] +"_rds"
$certPassword = $config.$env.CertPassword
$pfxPassword = ConvertTo-SecureString $certPassword -ASPlainText -Force
$pfxFilepath = $config.$env.CertPath

$currentDate = Get-Date
$endDate = $currentDate.AddYears(5)
$notAfter = $endDate.AddMinutes(1)

$certName = $config.$env.RDBrokerDNSInternalZone
$certStore = "Cert:\LocalMachine\My"
$certThumbprint = (New-SelfSignedCertificate -Subject *.$certName -DnsName $certName,*.$certName -CertStoreLocation $CertStore -KeyExportPolicy Exportable -Provider "Microsoft Enhanced RSA and AES Cryptographic Provider" -NotAfter $notAfter).Thumbprint

Remove-Item $pfxFilepath -ErrorAction SilentlyContinue
Export-PfxCertificate -Cert "$($certStore)\$($CertThumbprint)" -FilePath $pfxFilepath -Password $pfxPassword

# Download Machine Key Script for RDWeb Services
# https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/rds-rdweb-gateway-ha
# https://gallery.technet.microsoft.com/Get-and-Set-the-machineKeys-9a1e7b77
#[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
#Invoke-WebRequest -Uri "https://gallery.technet.microsoft.com/Get-and-Set-the-machineKeys-9a1e7b77/file/122500/1/Configure-MachineKeys.ps1" -OutFile "$($scriptPath)\Configure-MachineKeys.ps1"
#if (Test-Path "$($scriptPath)\Configure-MachineKeys.ps1"){
#	Write-Verbose "Downloaded Configure-MachineKeys Script" -Verbose
#} Else {
#	Write-Warning "Couldn't download Configure-MachineKeys Script"
#	break
#}

if ((Get-WindowsFeature -Name RSAT-DNS-Server).Installed -ne "True")
{
	Install-WindowsFeature -IncludeAllSubFeature RSAT
}
try
{
	Import-Module ActiveDirectory -ErrorAction Stop
	Write-Host "ActiveDirectory Module is already installed (RSAT)"
}
catch
{
	Write-Host "Installing WindowsFeature (RSAT)"
	Install-WindowsFeature -IncludeAllSubFeature RSAT
}

# Download ODBC Driver
#Write-Host "Downloading ODBC Driver 13.0 for SQL"
#$url = "https://download.microsoft.com/download/1/E/7/1E7B1181-3974-4B29-9A47-CC857B271AA2/English/X64/msodbcsql.msi"
#$outpath = "$($scriptPath)\odbc.msi"
#Invoke-WebRequest -Uri $url -OutFile $outpath
$cb1Drivers = invoke-command -ComputerName $config.$env.ConnectionBroker01 -ScriptBlock {get-odbcdriver}
$cb2Drivers = invoke-command -ComputerName $config.$env.ConnectionBroker02 -ScriptBlock {get-odbcdriver}
if (Test-Path "$($scriptPath)\odbc.msi"){
	Write-Verbose "ODBC Driver 13.0 for SQL is Present" -Verbose
} Else {
	Write-Warning "Couldn't find ODBC Driver"
	break
}

# Download Azure App Proxy Connector
#Write-host "Downloading Azure App Proxy Connector"
#[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
#Invoke-WebRequest -Uri "https://download.msappproxy.net/subscription/d3c8b69d-6bf7-42be-a529-3fe9c2e70c90/connector/DownloadConnectorInstaller" -OutFile "$($scriptPath)\AADApplicationProxyConnectorInstaller.exe"
if (Test-Path "$($scriptPath)\AADApplicationProxyConnectorInstaller.exe"){
	Write-Verbose " App Proxy Connector is Present" -Verbose
} Else {
	Write-Warning "Couldn't find App Proxy Connector"
	break
}


$osbInstallScript = @"
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force
`$cmd = "MSIEXEC.EXE /I $($scriptPath)\odbc.msi /qb IACCEPTMSODBCSQLLICENSETERMS=YES ALLUSERS=1"
cmd /c `$cmd
"@

$osb = [Scriptblock]::Create($osbInstallScript)
if (!($cb1drivers.name -contains 'ODBC Driver 13 for SQL Server'))
{
	New-PSDrive -Name cb1 -Root "\\$($config.$env.ConnectionBroker01)\c$" -PSProvider FileSystem
	mkdir cb1:\rds -ErrorAction SilentlyContinue
	copy-item "$($scriptPath)\odbc.msi" cb1:\rds -Recurse -Force
	Invoke-Command -ComputerName $config.$env.ConnectionBroker01 -ScriptBlock $osb
}
if (!($cb2drivers.name -contains 'ODBC Driver 13 for SQL Server'))
{
	New-PSDrive -Name cb2 -Root "\\$($config.$env.ConnectionBroker02)\c$" -PSProvider FileSystem
	mkdir cb2:\rds -ErrorAction SilentlyContinue
	copy-item "$($scriptPath)\odbc.msi" cb2:\rds -Recurse -Force
	Invoke-Command -ComputerName $config.$env.ConnectionBroker02 -ScriptBlock $osb
}
start-sleep -s 15
$cb1Drivers = invoke-command -ComputerName $config.$env.ConnectionBroker01 -ScriptBlock {get-odbcdriver}
$cb2Drivers = invoke-command -ComputerName $config.$env.ConnectionBroker02 -ScriptBlock {get-odbcdriver}
if ((!($cb1drivers.name -contains 'ODBC Driver 13 for SQL Server')) -or (!($cb2drivers.name -contains 'ODBC Driver 13 for SQL Server')))
{
	start-sleep -s 30
	$cb1Drivers = invoke-command -ComputerName $config.$env.ConnectionBroker01 -ScriptBlock {get-odbcdriver}
	$cb2Drivers = invoke-command -ComputerName $config.$env.ConnectionBroker02 -ScriptBlock {get-odbcdriver}
}
Write-Host "Connection Broker 1 ODBC Installation Status --->" ($cb1drivers.name -contains 'ODBC Driver 13 for SQL Server')
Write-Host "Connection Broker 2 ODBC Installation Status --->" ($cb2drivers.name -contains 'ODBC Driver 13 for SQL Server')
Read-Host "If Either Connection Broker ODBC Installation Status is False, re-run this script or manually install the ODBC Driver before continuing.  Otherwise press Enter to continue the prerequisite check"


###INSTALL Azure App Proxy Connector###
Write-Host "Copy App Proxy to Gateway Servers"
Invoke-Command -ComputerName $config.$env.RDGatewayServer01 {
	Get-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" | Enable-NetFirewallRule
}
if(Test-Path "\\$($config.$env.RDGatewayServer01)\c$"){Write-Verbose "UNC path reachable"} else { Write-Warning "$($config.$env.RDGatewayServer01) UNC path is not reachable"; break}
Invoke-Command -ComputerName $config.$env.RDGatewayServer02 {
	Get-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" | Enable-NetFirewallRule
}
if(Test-Path "\\$($config.$env.RDGatewayServer02)\c$"){Write-Verbose "UNC path reachable"} else { Write-Warning "$($config.$env.RDGatewayServer02) UNC path is not reachable"; break}
start-sleep -s 10
New-PSDrive -Name gw1 -Root "\\$($config.$env.RDGatewayServer01)\c$" -PSProvider FileSystem
mkdir gw1:\rds -ErrorAction SilentlyContinue
mkdir "gw1:\Program Files\WindowsPowerShell\Modules" -ErrorAction SilentlyContinue
mkdir "gw1:\Program Files\WindowsPowerShell\Modules\AzureAD" -ErrorAction SilentlyContinue
copy-item "$($scriptPath)\AADApplicationProxyConnectorInstaller.exe" gw1:\rds -Recurse -Force
Copy-Item "$($scriptPath)\Az\*" "gw1:\Program Files\WindowsPowerShell\Modules" -Recurse -Force
Copy-Item "$($scriptPath)\AzureAd\*" "gw1:\Program Files\WindowsPowerShell\Modules\AzureAd" -Recurse -Force
New-PSDrive -Name gw2 -Root "\\$($config.$env.RDGatewayServer02)\c$" -PSProvider FileSystem
mkdir gw2:\rds -ErrorAction SilentlyContinue
mkdir "gw2:\Program Files\WindowsPowerShell\Modules" -ErrorAction SilentlyContinue
mkdir "gw2:\Program Files\WindowsPowerShell\Modules\AzureAD" -ErrorAction SilentlyContinue
copy-item "$($scriptPath)\AADApplicationProxyConnectorInstaller.exe" gw2:\rds -Recurse -Force
Copy-Item "$($scriptPath)\Az\*" "gw2:\Program Files\WindowsPowerShell\Modules" -Recurse -Force
Copy-Item "$($scriptPath)\AzureAd\*" "gw2:\Program Files\WindowsPowerShell\Modules\AzureAd" -Recurse -Force


$apcScript = @"
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force
`$filepath = "$($scriptPath)\AADApplicationProxyConnectorInstaller.exe"
`$arg = "REGISTERCONNECTOR=""false"" /q"
Start-Process -FilePath `$filepath -ArgumentList `$arg -Wait
"@
$sb = [Scriptblock]::Create($apcScript)


## REGISTER APP PROXY SCRIPT
$user = $config.$env.DevOpsAppId
$password = $config.$env.DevOpsPassword
$rapScript = @"
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force
`$user = "$user"
`$password = "$password"
`$secpassword = `$password | ConvertTo-SecureString -AsPlainText -Force
`$creds = New-Object -TypeName System.Management.Automation.PSCredential -Argumentlist `$user, `$secpassword
`$creds
c:\"program files"\"microsoft aad app proxy connector"\RegisterConnector.ps1 -modulePath "c:\Program Files\Microsoft AAD App Proxy Connector\Modules\" -moduleName "AppProxyPSModule" -Authenticationmode Credentials -Usercredentials `$creds -Feature ApplicationProxy
"@
$rap = [Scriptblock]::Create($rapScript)

if (!(Test-Path "\\$($config.$env.RDGatewayServer01)\c$\Program Files\Microsoft AAD App Proxy Connector\ApplicationProxyConnectorService.exe"))
{
	Write-Host "Installing App Proxy on Gateway 1"
	Invoke-Command -ComputerName $config.$env.RDGatewayServer01 -ScriptBlock $sb
    Write-Host "Registering App Proxy - Gateway 1"
    Invoke-Command -ComputerName $config.$env.RDGatewayServer01 -ScriptBlock $rap
}
if (!(Test-Path "\\$($config.$env.RDGatewayServer02)\c$\Program Files\Microsoft AAD App Proxy Connector\ApplicationProxyConnectorService.exe"))
{
	Write-Host "Installing App Proxy on Gateway 2"
	Invoke-Command -ComputerName $config.$env.RDGatewayServer02 -ScriptBlock $sb
    Write-Host "Registering App Proxy - Gateway 2"
    Invoke-Command -ComputerName $config.$env.RDGatewayServer02 -ScriptBlock $rap
}


###SESSION HOST SETUP (FSLOGIX AND FILE SYNC)
Write-Verbose "Copy FSLogix and File Sync Agent to Session Hosts" -Verbose
Invoke-Command -ComputerName $config.$env.RDSHost01 {
	Get-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" | Enable-NetFirewallRule
}
if(Test-Path "\\$($config.$env.RDSHost01)\c$"){Write-Verbose "UNC path reachable"} else { Write-Warning "$($config.$env.RDSHost01) UNC path is not reachable"; break}
Invoke-Command -ComputerName $config.$env.RDSHost02 {
	Get-NetFirewallRule -DisplayName "File and Printer Sharing (SMB-In)" | Enable-NetFirewallRule
}
if(Test-Path "\\$($config.$env.RDSHost02)\c$"){Write-Verbose "UNC path reachable"} else { Write-Warning "$($config.$env.RDSHost02) UNC path is not reachable"; break}
start-sleep -s 10
New-PSDrive -Name sh1 -Root "\\$($config.$env.RDSHost01)\c$" -PSProvider FileSystem
mkdir sh1:\rds -ErrorAction SilentlyContinue
copy-item "$($scriptPath)\FSLogixAppsSetup.exe" sh1:\rds -Recurse -Force
copy-item "$($scriptPath)\StorageSyncAgent_WS2016.msi" sh1:\rds -Recurse -Force
copy-Item "$($scriptPath)\Az\*" "sh1:\Program Files\WindowsPowerShell\Modules" -Force -Recurse
New-PSDrive -Name sh2 -Root "\\$($config.$env.RDSHost02)\c$" -PSProvider FileSystem
mkdir sh2:\rds -ErrorAction SilentlyContinue
copy-item "$($scriptPath)\FSLogixAppsSetup.exe" sh2:\rds -Recurse -Force
copy-item "$($scriptPath)\StorageSyncAgent_WS2016.msi" sh2:\rds -Recurse -Force
Copy-Item "$($scriptPath)\Az\*" "sh2:\Program Files\WindowsPowerShell\Modules" -Force -Recurse

Write-Host "Install FSLogix and File Sync Agent on Session Hosts"
$fslInstallScript = @"
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force	
`$filepath = "$($scriptPath)\FSLogixAppsSetup.exe"
`$arg = "/QUIET /NORESTART"
Start-Process -FilePath `$filepath -ArgumentList `$arg -Wait
"@

$fsl = [Scriptblock]::Create($fslInstallScript)
Invoke-Command -ComputerName $config.$env.RDSHost01 -ScriptBlock $fsl
Invoke-Command -ComputerName $config.$env.RDSHost02 -ScriptBlock $fsl

Write-Verbose "$($config.$env.RDSHost01) will reboot"  -Verbose
Restart-Computer -ComputerName $config.$env.RDSHost01 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
Write-Verbose "$($config.$env.RDSHost01) online again"  -Verbose
Write-Verbose "$($config.$env.RDSHost02) will reboot"  -Verbose
Restart-Computer -ComputerName $config.$env.RDSHost02 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
Write-Verbose "$($config.$env.RDSHost02) online again"  -Verbose

$fsaInstallScript = @"
New-ItemProperty -Path HKLM:Software\Microsoft\Windows\CurrentVersion\policies\system -Name EnableLUA -PropertyType DWord -Value 0 -Force	
`$filepath = "$($scriptPath)\StorageSyncAgent_WS2016.msi"
`$arg = "/QUIET"
Start-Process -FilePath `$filepath -ArgumentList `$arg -Wait
"@
$fsa = [Scriptblock]::Create($fsaInstallScript)
Invoke-Command -ComputerName $config.$env.RDSHost01 -ScriptBlock $fsa
Invoke-Command -ComputerName $config.$env.RDSHost02 -ScriptBlock $fsa

Write-Verbose "$($config.$env.RDSHost01) will reboot"  -Verbose
Restart-Computer -ComputerName $config.$env.RDSHost01 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
Write-Verbose "$($config.$env.RDSHost01) online again"  -Verbose
Write-Verbose "$($config.$env.RDSHost02) will reboot"  -Verbose
Restart-Computer -ComputerName $config.$env.RDSHost02 -Wait -For PowerShell -Timeout 300 -Delay 2 -Force
Write-Verbose "$($config.$env.RDSHost02) online again"  -Verbose
Write-Host ""
Write-Verbose "Log in to both Gateway servers and run the following command to manually register the App Proxy if the App Proxy registration failed:" -Verbose
Write-Host "C:\""Program Files""\""Microsoft AAD App Proxy Connector""\RegisterConnector.ps1 -ModulePath ""C:\Program Files\Microsoft AAD App Proxy Connector\Modules"" -modulename 'AppProxyPSModule' -Feature ApplicationProxy"
Write-Host ""
Write-Verbose "Do not continue until the App Proxys are registered" -Verbose
pause
Write-Verbose "App Proxy Connector Group and Application Setup" -Verbose
Write-Verbose "Enter Azure AD Credentials" -Verbose
Connect-AzureAD -AzureEnvironmentName 'AzureUSGovernment'
New-AzureADApplicationProxyConnectorGroup -Name RDS -ErrorAction SilentlyContinue

## Move Gateway hosts from the Default connector group to RDS connector group
$rdsCg = Get-AzureAdApplicationProxyConnectorGroup | where {$_.Name -eq "RDS"}
$connector = Get-AzureADApplicationProxyConnector | where {$_.MachineName -eq "$($config.$env.RDGatewayServer01)"}
Set-AzureADApplicationProxyConnector -Id $connector.id -ConnectorGroupId $rdsCg.id
$connector = Get-AzureADApplicationProxyConnector | where {$_.MachineName -eq "$($config.$env.RDGatewayServer02)"}
Set-AzureADApplicationProxyConnector -Id $connector.id -ConnectorGroupId $rdsCg.id

## Create App Proxy Application
$domain = $config.$env.DomainController
$domain = ($domain -split '\.')[0]
New-AzureADApplicationProxyApplication -DisplayName rds -ExternalUrl "https://rds-$($domain).msappproxy.us/" -InternalUrl "https://$($config.$env.GatewayInternalFqdn)/" -ConnectorGroupId $rdsCg.id -ExternalAuthenticationType AadPreAuthentication -IsHttpOnlyCookieEnabled $false -IsPersistentCookieEnabled $false -IsTranslateHostHeaderEnabled $false -IsSecureCookieEnabled $true -IsTranslateLinksInBodyEnabled $false -ApplicationServerTimeout Default -ErrorAction SilentlyContinue
$rdsApp = Get-AzureADApplication | where {$_.DisplayName -eq "rds"}
try
{
	Set-AzureADApplicationProxyApplication -ObjectId $rdsApp.ObjectId -ExternalUrl "https://rds-$($domain).msappproxy.us/" -InternalUrl "https://$($config.$env.GatewayInternalFqdn)/" -ConnectorGroupId $rdsCg.id -ExternalAuthenticationType AadPreAuthentication -IsHttpOnlyCookieEnabled $false -IsPersistentCookieEnabled $false -IsTranslateHostHeaderEnabled $false -IsSecureCookieEnabled $true -IsTranslateLinksInBodyEnabled $false -ApplicationServerTimeout Default -ErrorAction Stop
}
catch
{
	Write-Host -ForegroundColor Red "Error Creating Proxy Application"
}



### Rotate All VM Disk Encryption Keys By Creating A New Key Vault And Setting The Disk Encryption Extension To Register With The New Vault.
### The RunAs account needs the following API permissions:

#--Azure Active Directory	
#          |-------Application
#                  |-------Application.ReadWrite.All
#          |-------Directory
#                  |-------Directory.Read.All

# KeyVault Name is kvl-ugv-vm-encrypt[index]-[env] Where "index" is incremented each time a new vault is created.
Param
(
  [Parameter (Mandatory= $true)]
  [String] $Environment,

  [Parameter (Mandatory= $true)]
  [String] $DevopsSPNDisplayName
)

Disable-AzContextAutosave –Scope Process

$connection = Get-AutomationConnection -Name AzureRunAsConnection

while(!($connectionResult) -And ($logonAttempt -le 5))
{
    $LogonAttempt++
    # Logging in to Azure...
    $connectionResult =    Connect-AzAccount -Environment 'AzureUSGovernment' `
                               -ServicePrincipal `
                               -Tenant $connection.TenantID `
                               -ApplicationId $connection.ApplicationID `
                               -CertificateThumbprint $connection.CertificateThumbprint

    Start-Sleep -Seconds 5
}

$existingVault = (get-azkeyvault | where {$_.VaultName -like '*kvl-ugv-vm-encrypt*'} | select VaultName | sort-object -Descending -Property VaultName)[0].VaultName

$vaultIndex = $existingVault -replace "kvl-ugv-vm-encrypt",""
$vaultIndex = $vaultIndex -replace "-$($Environment)",""
$vaultIndex = [int]$vaultIndex
$vaultIndex++
$errorFlag = $false
$sendEmail = $false

$devopsSpn = Get-AzADApplication -DisplayName $DevopsSPNDisplayName
$backupSpn = Get-AzADServicePrincipal -DisplayName BackupFairFax

$newVaultName = "kvl-ugv-vm-encrypt$($vaultIndex)-$($Environment)"
$newVault = New-AzKeyVault -VaultName $newVaultName -ResourceGroupName "RGP-UGV-CORE-$($Environment)"  -Location 'usgovvirginia' -Sku Standard -EnabledForDiskEncryption -Tags $existingVault.tags

Set-AzKeyVaultAccessPolicy -VaultName $newVault.VaultName -ServicePrincipalName $devopsSpn.IdentifierUris[0] -PermissionsToSecrets get,list,set,delete,recover,backup,restore -PermissionsToKeys get,list,update,create,import,delete,recover,backup,restore -PermissionsToCertificates get,list,update,create,import,delete,recover,backup,restore,managecontacts,manageissuers,getissuers,listissuers,setissuers,deleteissuers -PermissionsToStorage backup,delete,deletesas,get,getsas,list,listsas,purge,recover,regeneratekey,restore,set,setsas,update
Set-AzKeyVaultAccessPolicy -VaultName $newVault.VaultName -ObjectId $backupSpn.Id -PermissionsToSecrets get,list,backup -PermissionsToKeys get,list,backup

Update-AzKeyVaultNetworkRuleSet -VaultName $newVaultName -DefaultAction Deny

Add-AzKeyVaultNetworkRule -VaultName $newVaultName -IpAddressRange 199.207.253.101/32,199.207.253.96/32,13.72.13.237/32 -PassThru

$coreVnet = Get-AzVirtualNetwork  -name "vnt-ugv-core-$($Environment)" -resourcegroupname "RGP-UGV-CORE-$($Environment)"

$subnet = Get-AzVirtualNetworkSubnetConfig -Name "sub-ugv-build-$($Environment)" -VirtualNetwork $coreVnet
Add-AzKeyVaultNetworkRule -VaultName $newVaultName -VirtualNetworkResourceId $subnet.Id
Start-Sleep -s 5
$subnet = Get-AzVirtualNetworkSubnetConfig -Name "sub-ugv-mgmt-$($Environment)" -VirtualNetwork $coreVnet
Add-AzKeyVaultNetworkRule -VaultName $newVaultName -VirtualNetworkResourceId $subnet.Id
Start-Sleep -s 5
$subnet = Get-AzVirtualNetworkSubnetConfig -Name "sub-ugv-rdsgw-$($Environment)" -VirtualNetwork $coreVnet
Add-AzKeyVaultNetworkRule -VaultName $newVaultName -VirtualNetworkResourceId $subnet.Id
Start-Sleep -s 5
$subnet = Get-AzVirtualNetworkSubnetConfig -Name "sub-ugv-rdssvcs-$($Environment)" -VirtualNetwork $coreVnet
Add-AzKeyVaultNetworkRule -VaultName $newVaultName -VirtualNetworkResourceId $subnet.Id
Start-Sleep -s 5
$subnet = Get-AzVirtualNetworkSubnetConfig -Name "sub-ugv-snw-$($Environment)" -VirtualNetwork $coreVnet
Add-AzKeyVaultNetworkRule -VaultName $newVaultName -VirtualNetworkResourceId $subnet.Id
Start-Sleep -s 5
$subnet = Get-AzVirtualNetworkSubnetConfig -Name "sub-ugv-squid-$($Environment)" -VirtualNetwork $coreVnet
Add-AzKeyVaultNetworkRule -VaultName $newVaultName -VirtualNetworkResourceId $subnet.Id
Start-Sleep -s 5
#####################################################################################################################################
#####################################################################################################################################

$vms = Get-AzVm
$errorVms = @()
foreach ($vm in $vms)
{
	
    if ($vm.StorageProfile.OsDisk.OsType -eq "Windows")
    {
       try
    	{
    		Write-Output "Updating:" $vm.Name
            Set-AzVMDiskEncryptionExtension -ResourceGroupName $vm.ResourceGroupName -VMName $vm.Name -DiskEncryptionKeyVaultUrl $newVault.VaultUri -DiskEncryptionKeyVaultId $newvault.ResourceId -Confirm:$false -Force -ErrorAction Stop
    	}
        catch
    	{
    	    try
    	    {
    		   Write-Output "Updating:" $vm.Name " (Old Version)"
               Set-AzVMDiskEncryptionExtension -ResourceGroupName $vm.ResourceGroupName -VMName $vm.Name -AadClientID $devopsSpn.ApplicationId.Guid -AadClientSecret "wuYcFwA=Y2p._K:QMRkDZ2xtXwHA2q3l" -DiskEncryptionKeyVaultUrl $newVault.VaultUri -DiskEncryptionKeyVaultId $newvault.ResourceId -Confirm:$false -Force -ErrorAction Stop
    		}
    		catch
    		{
    			$errorFlag = $true
    			$errorVms += $vm.Name
    		}
    	}
    }
}

if (!($errorFlag))
{
	Write-Output "All VM Encryption Keys Successfully Rotated.  New Key Vault Is: "$newVaultName
	#Remove-AzKeyVault -VaultName $existingVault -PassThru
}
else
{
	Write-Output "The following VM's encryption keys failed to rotate successfully.  The old key vault was not deleted."
	$errorVms
	Write-Output "Old Key Vault: "$existingVault
	Write-Output "New Key Vault: "$newVaultName
}

if ($sendEmail)
{
    #$username = "noreply@KPMGUSOBProd.onmicrosoft.com"
    #$password = (Get-AzKeyVaultSecret -vaultName "KVL-PROD-SHARED-KPMG-OB" -name "noreply-user-password").SecretValueText
    $username = "noreply@kpmgusunmg.onmicrosoft.com"
    $password = ""
    $Pswd = $password | ConvertTo-SecureString -AsPlainText -Force  
    $creds = New-Object System.Management.Automation.PSCredential -ArgumentList $username, $Pswd
    $EmailToAddress = @('scottmccormick@kpmg.com')
    #$EmailToAddress = @('go-fmmanagedservices@kpmg.com')
    #$EmailToAddressCC = @('anmolagarwal@kpmg.com','ckkaranam@kpmg.com','dinesharuchamy@kpmg.com','shivashankars1@kpmg.com','ekringen@KPMG.com')
    #Send-MailMessage -SmtpServer "smtp.office365.com" -Credential $creds -Subject "SPN Certificate Expiry Report" -BodyAsHtml $Global:bodyCode -From $username -To $EmailToAddress -Cc $EmailToAddressCC -UseSsl
    Send-MailMessage -SmtpServer "smtp.office365.com" -Credential $creds -Subject "KTC Inactive Users Deleted Report" -Body $Global:bodyCode -BodyAsHtml -From $username -To $EmailToAddress -UseSsl -Port 587
}

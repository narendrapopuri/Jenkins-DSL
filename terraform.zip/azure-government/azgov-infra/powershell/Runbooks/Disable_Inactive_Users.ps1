$testMode = $true ## $true = Report Only, Do Not Delete Users || $false = Delete Users and Send Report
$env = "dv"
$domain_env = "np"  ## Domain suffix
$la_workspace = "e03b99e6-ac71-4ef6-a431-b20f33a86bb1"  ## law-ugv-core-dv
$azureAutomationConnectionName = "AzureRunAsConnection"
$neverDeleteGroupId = "555edb13-b7f4-4167-a6db-edd040ae9d80"

####################Get the connection "AzureRunAsConnection"###################
$servicePrincipalConnection = Get-AutomationConnection -Name $azureAutomationConnectionName         
"Azure Run As Connection established."

#############Adds the Authentication Account###################
Add-AzAccount -Environment 'AzureUSGovernment' -ServicePrincipal -TenantId $servicePrincipalConnection.TenantId -ApplicationId $servicePrincipalConnection.ApplicationId -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint
"Added Authentication Account."

#############Authenticate Service Principal##############
Connect-AzureAD -AzureEnvironmentName 'AzureUSGovernment' -TenantId $servicePrincipalConnection.TenantId -ApplicationId $servicePrincipalConnection.ApplicationId -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint

$logDate = get-date -format "MM-dd-yyyy"
$logName = "$($logDate)_deleted_inactive_users.log"
$log = @()
function Get-HtmlCode($user, $lastLogin)
{
        $Global:bodyCode += "<tr><td style='border:1px solid black;width:200px;background-color:#FFFFFF'>$($user)</td>"
        $Global:bodyCode += "<td style='border:1px solid black;width:150px;background-color:#FFFFFF'>$($lastLogin)</td>"
        $Global:bodyCode += "</tr>"
}

$adusersF = New-Object System.Collections.ArrayList
$inactiveUsers = New-Object System.Collections.ArrayList
$neverDeleteUsers = New-Object System.Collections.ArrayList
$deladusers = New-Object System.Collections.ArrayList

$query = @"
SigninLogs |
summarize arg_max(TimeGenerated, *) by UserPrincipalName |
where TimeGenerated <= ago(60d)
"@
$queryResults = Invoke-AzOperationalInsightsQuery -WorkspaceId $la_workspace -Query $query

###############Extract List of Inactive Users###################
foreach ($u in $queryresults.results.userprincipalname)
{
    if ($u -like "*kusgc*")
    {
        $inactiveUsers += $u.Replace("@kpmg.com","_kpmg.com#EXT#@kusgcadv$($domain_env).onmicrosoft.us")
    }
}

#############Get All AD Users and Format#######################
$adusers= Get-AzureADUser -Top 5000
foreach ($aduser in $adusers.UserPrincipalName)
{
    $adusersF += $aduser
}

#############Exclude Never Disable Group#######################
$neverDelete = Get-AzureAdGroupMember -ObjectId $neverDeleteGroupId  ## all-service-accounts
foreach($member in $neverDelete)
{
    $neverDeleteUsers += $member.UserPrincipalName
}

foreach ($aduser in $inactiveUsers)
{
    if (($neverDeleteUsers -notcontains $aduser) -and ($neverDeleteUsers -notcontains "$($aduser)#EXT#@kusgcadv$($domain_env).onmicrosoft.us"))
    {
        $deladusers += $aduser
    }
}


"Total Number of Users found in Azure AD"
$adusersF.Length
"Total Number of User Accounts that are inactive at least 60 days"
if($inactiveUsers.Length -eq $null){write-output "0"}else{write-output $inactiveUsers.Length}
"Total Number of NeverDelete Accounts"
if($neverDeleteUsers.Length -eq $null){write-output "0"}else{write-output $neverDeleteusers.Length}
"Total Number of User Accounts that have not signed-in during the last 60 days, excluding the NeverDelete Group"
if($deladusers.Length -eq $null){write-output "0"}else{write-output $deladusers.Length}
if ($deladusers -ne $null)
{
    "Accounts Getting Deleted"
    "##################################"
    $deladusers
    "##################################"
}

    $today = get-date -format "MM-dd-yyyy"
    $Global:bodyCode = ""
    $Global:bodyCode += "<html>"
    $Global:bodyCode += "<body>"
    $Global:bodyCode += "<p>Hi Team,</p>"
    $Global:bodyCode += "<p>Listed below are inactive USKGC users that have been deleted.</p>"
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<head><h1 align ='center'> Accounts Deleted Today: $($today) (Inactive > 60 Days) </h1></head>"
    $Global:bodyCode += "<table border='1' style='width:100%'>"
    $Global:bodyCode +="<tr>"
    $Global:bodyCode +="<th>User</th>"
    $Global:bodyCode +="<th>Last Login</th>"
    $Global:bodyCode +="</tr>"

$sendEmail = $false
##########Delete the Users##########
foreach ($du in $deladusers)
{
    #$sendEmail = $true      ###Email not set up yet
    try
    {
        $duFormatted = $du
        #$duFormatted = $du.Replace("#EXT#@KPMGUSunmg.onmicrosoft.com","")
        #$duFormatted = $duFormatted.Replace("_","@")
        $query = @"
SigninLogs |
summarize arg_max(TimeGenerated, *) by UserPrincipalName |
where TimeGenerated <= ago(60d) |
where UserPrincipalName == "$duFormatted"
"@
        $queryResults = Invoke-AzOperationalInsightsQuery -WorkspaceId $la_workspace -Query $query 
        $timestamp = $queryresults.results.TimeGenerated
        $timestamp = $timestamp.Substring(0,$timestamp.Length-1)
        $TZ = [System.TimeZoneInfo]::FindSystemTimeZoneById("Eastern Standard Time")
        $LocalTime = [System.TimeZoneInfo]::ConvertTimeFromUtc($timestamp, $TZ)
        $timestamp = $localtime | get-date -format "MM-dd-yyyy hh:mm:ss tt"
        Get-HtmlCode $du $timestamp
        if (!$testMode)
        {
            Remove-AzureAdUser -ObjectId $du -ErrorAction SilentlyContinue  ### Testing, Don't delete users
        }
    }
    catch {}

}
    $Global:bodyCode += "</table>"

#############SOFT DELETE TABLE##############################
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<h1 align ='center'> All Current Deleted Users (Recoverable for 30 Days) </h1>"
    $Global:bodyCode += "<table border='1' style='width:100%'>"
    $Global:bodyCode +="<tr>"
    $Global:bodyCode +="<th>User</th>"
    $Global:bodyCode +="<th>Time Generated</th>"
    $Global:bodyCode +="</tr>"
    $querySD = @"
AuditLogs
| where TimeGenerated >= ago(31d)
| where OperationName == 'Delete user'
"@
$queryResults = Invoke-AzOperationalInsightsQuery -WorkspaceId $la_workspace -Query $querySD  
foreach ($q in $queryresults.results)
{
    $timestamp = $q.TimeGenerated
    $timestamp = $timestamp.Substring(0,$timestamp.Length-1)
    $TZ = [System.TimeZoneInfo]::FindSystemTimeZoneById("Eastern Standard Time")
    $LocalTime = [System.TimeZoneInfo]::ConvertTimeFromUtc($timestamp, $TZ)
    $timestamp = $localtime | get-date -format "MM-dd-yyyy hh:mm:ss tt"
    $jsonSD = $q.targetresources | ConvertFrom-Json -ErrorAction SilentlyContinue
    $user = $jsonSD.userPrincipalName
    $user = $user.SubString(32,$user.length-32)
    Get-HtmlCode $user $timestamp
}
$Global:bodyCode += "</table>"
#############HARD DELETE TABLE##############################
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<h1 align ='center'> Permanently Deleted Users in the Last Month </h1>"
    $Global:bodyCode += "<table border='1' style='width:100%'>"
    $Global:bodyCode +="<tr>"
    $Global:bodyCode +="<th>User</th>"
    $Global:bodyCode +="<th>Time Generated</th>"
    $Global:bodyCode +="</tr>"
    $queryHD = @"
AuditLogs
| where TimeGenerated >= ago(31d)
| where OperationName == 'Hard Delete user'
"@
$queryResults = Invoke-AzOperationalInsightsQuery -WorkspaceId $la_workspace -Query $queryHD
foreach ($q in $queryresults.results)
{
    $timestamp = $q.TimeGenerated
    $timestamp = $timestamp.Substring(0,$timestamp.Length-1)
    $TZ = [System.TimeZoneInfo]::FindSystemTimeZoneById("Eastern Standard Time")
    $LocalTime = [System.TimeZoneInfo]::ConvertTimeFromUtc($timestamp, $TZ)
    $timestamp = $localtime | get-date -format "MM-dd-yyyy hh:mm:ss tt"
    $jsonHD = $q.targetresources | ConvertFrom-Json -ErrorAction SilentlyContinue
    $user = $jsonHD.userPrincipalName
    $user = $user.SubString(32,$user.length-32)
    Get-HtmlCode $user $timestamp
}

##############################SEND EMAIL##############################
    $Global:bodyCode += "</table>"
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<p></p>"
    $Global:bodyCode += "<p>Regards,<br>noreply@kusgcadv$($domain_env).onmicrosoft.com</p>"
    $Global:bodyCode += "<p style='color:blue;'><i><small>**Please do not reply to this email</small></i></p>"
    $Global:bodyCode += "</body>"
    $Global:bodyCode += "</html>"
    write-output $Global:bodyCode
    if ($sendEmail)
    {
        #$username = "noreply@KPMGUSOBProd.onmicrosoft.com"
        #$password = (Get-AzKeyVaultSecret -vaultName "KVL-PROD-SHARED-KPMG-OB" -name "noreply-user-password").SecretValueText
        $username = "noreply@kpmgusunmg.onmicrosoft.com"
        $password = ""
        $secpassword = $password | ConvertTo-SecureString -AsPlainText -Force  
        $creds = New-Object System.Management.Automation.PSCredential -ArgumentList $username, $secpassword
        $EmailToAddress = @('scottmccormick@kpmg.com')
        #$EmailToAddress = @('go-fmmanagedservices@kpmg.com')
        #$EmailToAddressCC = @('anmolagarwal@kpmg.com','ckkaranam@kpmg.com','dinesharuchamy@kpmg.com','shivashankars1@kpmg.com','ekringen@KPMG.com')
        #Send-MailMessage -SmtpServer "smtp.office365.com" -Credential $creds -Subject "SPN Certificate Expiry Report" -BodyAsHtml $Global:bodyCode -From $username -To $EmailToAddress -Cc $EmailToAddressCC -UseSsl
        Send-MailMessage -SmtpServer "smtp.office365.com" -Credential $creds -Subject "KTC Inactive Users Deleted Report" -Body $Global:bodyCode -BodyAsHtml -From $username -To $EmailToAddress -UseSsl -Port 587
    }



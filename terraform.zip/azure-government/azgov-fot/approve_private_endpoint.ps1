param (
    [Parameter(Mandatory=$True)]
    [string]$PGSVR_ID
)

Write-Host $PGSVR_ID

$RETRIES = 0
$ENDPOINT
while($ENDPOINT -eq $null -and $RETRIES -lt 120) {
    $ENDPOINT = az network private-endpoint-connection list --id $PGSVR_ID --query "[?contains(properties.privateEndpoint.id, 'vnet')].id" -o json | ConvertFrom-Json
    Write-Host "waiting for endpoint..."
    $RETRIES++
    Start-Sleep -Seconds 5
}
Write-Host "Endpoint: ", $ENDPOINT

if ($ENDPOINT -ne $null) {
    Write-Host "approving endpoint..."
    az network private-endpoint-connection approve --id $ENDPOINT --description "Approved in Terraform"
}

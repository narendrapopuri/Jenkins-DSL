*** This is a manual Terraform KTC WVD deployment from a laptop/VM ***

Prerequisites:
    Terrform exe installed on the machine you will be running this on.
    A cloud account:
       username: firstname.lastname@kpmgusunmg.onmicrosoft.com
    Join Domain credentials (can be yours if you have the permission)


Steps:
Download the WVD folder locally located here: https://dev.azure.com/CO-AzureCore/KpmgAdvisoryCloud/_git/terraform?path=%2Fazure-trusted%2Fwvd%2FREADME.txt&version=GBmaster
Log into Azure
DEV: Go to this Key Vault: https://portal.azure.com/#@KPMGUSunmg.onmicrosoft.com/resource/subscriptions/cb58272a-8f65-4b53-b567-019dfb031256/resourceGroups/HCLS-OB-PoC-USE2-RG-DevOps/providers/Microsoft.KeyVault/vaults/hclsobdevopskvdev/secrets     HCLS-OB-VSTS-SPN-Prod-client-id     And HCLS-OB-VSTS-SPN-Prod-client-secret
UAT: Go to this Key Vault: https://portal.azure.com/#@KPMGUSOBProd.onmicrosoft.com/resource/subscriptions/133b88bb-520f-4234-ad02-40d91330fd00/resourceGroups/HCLS-OB-USE2-RG-Core-UAT/providers/Microsoft.KeyVault/vaults/HCLS-OB-USE2-Core-UAT/secrets SPN-UAT-HclsObVstsDeploy-client-id  And SPN-UAT-HclsObVstsDeploy-client-secret
PRD: Go to this Key Vault: https://portal.azure.com/#@KPMGUSOBProd.onmicrosoft.com/resource/subscriptions/49a9b02b-3b71-44d9-a449-1b66646376ae/resourceGroups/EAS-HCLS-OB-RG-Shared/providers/Microsoft.KeyVault/vaults/KVL-PROD-SHARED-KPMG-OB/secrets  SPN-PROD-HclsObVstsDeploy-client-id And SPN-PROD-HclsObVstsDeploy-client-secret
Open the variables.tf file
On line 4 you will see the variable. Go to this Key Vault and get the HCLS-OB-VSTS-SPN-Prod-client-secret and HCLS-OB-VSTS-SPN-Prod-client-id values and update the variables.tf file with the values from the Key Vault
On line 45 you will see the variable "domain_svc_acct_password" Get the password and update the variables.tf file with the value from the Key Vault Secret

Download the .tfstate file from the storage accounts here:
terraform_uat_core_wvd_netapp.tfstate  : https://portal.azure.com/#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/%2Fsubscriptions%2F133b88bb-520f-4234-ad02-40d91330fd00%2FresourceGroups%2FHCLS-OB-USE2-RG-Core-UAT%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fhclsobcoreuat/path/terraformstate/etag/%220x8D8E00C5091B4A8%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride//defaultId//publicAccessVal/None
terraform_prod_core_wvd_netapp.tfstate : https://portal.azure.com/#blade/Microsoft_Azure_Storage/ContainerMenuBlade/overview/storageAccountId/%2Fsubscriptions%2F267660ef-3a13-491f-9db9-4464afd09a81%2FresourceGroups%2FHCLS-OB-USE2-RG-Core-PRD%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fhclsobcoreprd/path/terraformstate/etag/%220x8D8E3E1163F6169%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride//defaultId//publicAccessVal/None

Open a Command/PowerShell prompt:
Navigate/change directory into the wvd/terraform folder
Then run these commands in this order
    terraform init
    terraform plan -var-file="variables_uat.tfvars"   or   terraform plan  -var-file="variables_uat.tfvars"
    terraform apply -var-file="variables_prd.tfvars"  or   terraform apply -var-file="variables_prd.tfvars"

You are done.
Close the Command/PowerShell prompt.
Log out of Azure.